export class ExportService {
  static generateHTML(brandName: string, assets: any, blocks: any[]): string {
    const palette = assets.palette || ['#2563eb', '#1e40af'];
    const font = assets.fonts?.[0] || 'Inter';

    const blocksHTML = blocks.map(block => {
      switch (block.type) {
        case 'hero':
          return `
            <section class="py-20 px-8 text-center bg-white">
              <div class="max-w-4xl mx-auto">
                <h1 class="text-6xl font-black mb-6" style="color: ${palette[1]}">${block.content.title}</h1>
                <p class="text-xl text-gray-600 mb-10">${block.content.subtitle}</p>
                <button class="px-10 py-4 text-white font-bold rounded-xl shadow-lg" style="background-color: ${palette[0]}">
                  Get Started
                </button>
              </div>
            </section>
          `;
        case 'features':
          const items = block.content.items?.map((item: any) => `
            <div class="p-8 bg-gray-50 rounded-3xl text-center">
              <h3 class="text-xl font-bold mb-4">${item}</h3>
              <p class="text-gray-500">Professional feature description tailored for your brand.</p>
            </div>
          `).join('') || '';
          return `<section class="py-20 px-8 bg-gray-50"><div class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">${items}</div></section>`;
        case 'footer':
          return `
            <footer class="py-12 px-8 bg-white border-t border-gray-100 text-center">
              <p class="text-gray-400 font-medium">${block.content.text}</p>
            </footer>
          `;
        default:
          return '';
      }
    }).join('');

    return `
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${brandName}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=${font.replace(/ /g, '+')}:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: '${font}', sans-serif; }
    </style>
</head>
<body class="bg-white text-gray-900">
    <nav class="p-6 flex justify-between items-center max-w-7xl mx-auto">
        <div class="text-2xl font-black" style="color: ${palette[1]}">${brandName}</div>
        <div class="hidden md:flex gap-8 font-bold text-gray-500">
            <a href="#" class="hover:text-gray-900">Products</a>
            <a href="#" class="hover:text-gray-900">About</a>
            <a href="#" class="hover:text-gray-900">Contact</a>
        </div>
    </nav>
    ${blocksHTML}
</body>
</html>`;
  }
}

