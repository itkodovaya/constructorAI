export class AIContentService {
  private static contentLibrary: Record<string, any> = {
    tech: {
      hero: { title: "Будущее IT уже здесь", subtitle: "Масштабируемые решения для вашего стартапа с использованием передовых технологий AI." },
      features: [
        { title: "Быстрый запуск", description: "Развертывание инфраструктуры за считанные минуты." },
        { title: "Безопасность", description: "Сквозное шифрование и защита данных по стандарту Tier-4." },
        { title: "AI-Оптимизация", description: "Наши алгоритмы сами находят узкие места в вашем коде." }
      ]
    },
    beauty: {
      hero: { title: "Естественная красота в каждом движении", subtitle: "Профессиональный уход и инновационные методики преображения." },
      features: [
        { title: "Органический уход", description: "Используем только проверенные натуральные компоненты." },
        { title: "Эксперты", description: "Мастера с международным опытом и сертификацией." },
        { title: "Атмосфера", description: "Уютное пространство для вашего отдыха и релаксации." }
      ]
    },
    education: {
      hero: { title: "Знания, которые меняют жизнь", subtitle: "Онлайн-курсы от ведущих практиков рынка с гарантией трудоустройства." },
      features: [
        { title: "Практика", description: "80% обучения — это реальные кейсы и проекты." },
        { title: "Менторство", description: "Поддержка от опытных наставников на каждом этапе." },
        { title: "Комьюнити", description: "Доступ в закрытый клуб выпускников и работодателей." }
      ]
    }
  };

  static generatePageContent(niche: string, brandName: string) {
    const nicheContent = this.contentLibrary[niche] || this.contentLibrary.tech;
    
    return [
      {
        id: 'hero-' + Date.now(),
        type: 'hero',
        content: {
          title: nicheContent.hero.title.replace('нашего', brandName),
          subtitle: nicheContent.hero.subtitle,
          buttonText: 'Начать сейчас'
        }
      },
      {
        id: 'features-' + (Date.now() + 1),
        type: 'features',
        content: {
          items: nicheContent.features.map((f: any) => f.title)
        }
      },
      {
        id: 'text-' + (Date.now() + 2),
        type: 'text',
        content: {
          title: `О компании ${brandName}`,
          text: `Мы — инновационная команда в нише ${niche}, стремящаяся сделать мир лучше через качественные продукты и сервисы.`
        }
      },
      {
        id: 'footer-' + (Date.now() + 3),
        type: 'footer',
        content: {
          text: `© 2026 ${brandName}. Все права защищены. Сделано с любовью.`
        }
      }
    ];
  }
}

