import express from 'express';
import cors from 'cors';
import { ProjectsService } from './services/projects.service';
import { ExportService } from './services/export.service';

import { TranslateService } from './services/translate.service';

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

// AI Перевод проекта
app.post('/api/projects/:id/translate', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const targetLang = req.body.lang || 'en';
    const translatedPages = project.pages.map(page => ({
      ...page,
      blocks: TranslateService.translateBlocks(page.blocks, targetLang)
    }));

    const updatedProject = await ProjectsService.update(project.id, {
      pages: translatedPages
    });
    
    res.json(updatedProject);
  } catch (error) {
    res.status(500).json({ error: 'Translation failed' });
  }
});

// AI Генерация полного контента страницы
app.post('/api/projects/:id/generate-content', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const newBlocks = AIContentService.generatePageContent(project.niche, project.brandName);
    const updatedProject = await ProjectsService.update(project.id, {
      pages: [{ ...project.pages[0], blocks: newBlocks }]
    });
    
    res.json(updatedProject);
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate content' });
  }
});

// Экспорт сайта в HTML
app.post('/api/projects/:id/export', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const html = ExportService.generateHTML(
      project.brandName,
      project.brandAssets,
      project.pages[0].blocks
    );
    
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Disposition', `attachment; filename="${project.brandName}_website.html"`);
    res.send(html);
  } catch (error) {
    res.status(500).json({ error: 'Failed to export site' });
  }
});

// Генерация ссылки для шеринга
app.post('/api/projects/:id/share', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const shareId = Math.random().toString(36).substr(2, 12);
    // В реальной БД мы бы сохранили этот shareId
    res.json({ shareUrl: `https://constructor.ai/view/${shareId}` });
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate share link' });
  }
});

// ... остальные эндпоинты ...

// Получение одного проекта
app.get('/api/projects/:id', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

// Создание проекта (Onboarding)
app.post('/api/projects', async (req, res) => {
  try {
    const project = await ProjectsService.create(req.body);
    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create project' });
  }
});

// Обновление проекта
app.put('/api/projects/:id', async (req, res) => {
  try {
    const project = await ProjectsService.update(req.params.id, req.body);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update project' });
  }
});

// Удаление проекта
app.delete('/api/projects/:id', async (req, res) => {
  try {
    const success = await ProjectsService.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Project not found' });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete project' });
  }
});

app.listen(port, () => {
  console.log(`Backend running at http://localhost:${port}`);
});
