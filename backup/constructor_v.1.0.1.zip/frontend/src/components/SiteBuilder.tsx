import React, { useState } from 'react';
import { motion, Reorder } from 'framer-motion';
import { 
  Plus, Settings, Save, Smartphone, Tablet, Monitor, 
  Trash2, ChevronUp, ChevronDown, Edit3, X, Eye, Code,
  Globe, Search, Share2, Image as ImageIcon, Languages
} from 'lucide-react';

import { api } from '../services/api';

interface Block {
  id: string;
  type: string;
  content: any;
}

interface SiteBuilderProps {
  brandName: string;
  assets: any;
  onClose: () => void;
  seo?: any;
  onUpdateSEO?: (seo: any) => void;
}

export const SiteBuilder: React.FC<SiteBuilderProps> = ({ brandName, assets, onClose, seo: initialSEO, onUpdateSEO }) => {
  const [blocks, setBlocks] = useState<Block[]>([
    {
      id: 'hero-1',
      type: 'hero',
      content: { title: `Welcome to ${brandName}`, subtitle: 'Your amazing slogan goes here' }
    },
    {
      id: 'features-1',
      type: 'features',
      content: { items: ['Feature 1', 'Feature 2', 'Feature 3'] }
    },
    {
      id: 'footer-1',
      type: 'footer',
      content: { text: `© 2026 ${brandName}` }
    }
  ]);

  const [viewMode, setViewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [editingBlock, setEditingBlock] = useState<string | null>(null);
  const [showSEOSettings, setShowSEOSettings] = useState(false);
  const [seoData, setSeoData] = useState(initialSEO || {
    title: brandName,
    description: 'Создано в Constructor AI',
    keywords: 'ai, web, design'
  });

  const [isGenerating, setIsGenerating] = useState(false);

  const handleTranslate = async () => {
    setIsGenerating(true);
    try {
      const data = await api.translateProject(brandName, 'en'); // Упрощенно переводим на EN
      setBlocks(data.pages[0].blocks);
      alert('Сайт успешно переведен на английский язык с помощью AI!');
    } catch (error) {
      console.error('Translation failed');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleMagicGenerate = async () => {
    setIsGenerating(true);
    try {
      // В реальном приложении передаем profile.id
      const updatedProject = await api.generateFullContent(brandName); 
      setBlocks(updatedProject.pages[0].blocks);
      alert('AI успешно переписал контент под вашу нишу!');
    } catch (error) {
      console.error('Generation failed');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveSEO = () => {
    if (onUpdateSEO) onUpdateSEO(seoData);
    setShowSEOSettings(false);
  };

  const deleteBlock = (id: string) => {
    setBlocks(blocks.filter(b => b.id !== id));
  };

  const updateBlockContent = (id: string, newContent: any) => {
    setBlocks(blocks.map(b => b.id === id ? { ...b, content: { ...b.content, ...newContent } } : b));
  };

  const handleExport = async () => {
    try {
      await api.exportProject(brandName);
      alert('Сайт успешно экспортирован!');
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900 z-50 flex flex-col overflow-hidden">
      {/* Top Toolbar */}
      <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-all">
            <X className="w-5 h-5 text-slate-500" />
          </button>
          <div className="h-6 w-px bg-slate-200" />
          <h2 className="font-bold text-slate-800">{brandName} - Site Editor</h2>
        </div>

        <div className="flex items-center bg-slate-100 p-1 rounded-xl">
          <button 
            onClick={() => setViewMode('mobile')}
            className={`p-2 rounded-lg transition-all ${viewMode === 'mobile' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
          >
            <Smartphone className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setViewMode('tablet')}
            className={`p-2 rounded-lg transition-all ${viewMode === 'tablet' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
          >
            <Tablet className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setViewMode('desktop')}
            className={`p-2 rounded-lg transition-all ${viewMode === 'desktop' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400'}`}
          >
            <Monitor className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={handleTranslate}
            disabled={isGenerating}
            className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-all"
          >
            <Languages className="w-4 h-4" /> EN
          </button>
          <button 
            onClick={handleMagicGenerate}
            disabled={isGenerating}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-bold rounded-lg transition-all ${
              isGenerating 
              ? 'bg-amber-50 text-amber-500 animate-pulse' 
              : 'text-amber-600 hover:bg-amber-50'
            }`}
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} /> 
            {isGenerating ? 'Генерация...' : 'Magic Fill'}
          </button>
          <button 
            onClick={() => setShowSEOSettings(true)}
            className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-all"
          >
            <Globe className="w-4 h-4" /> SEO
          </button>
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-all"
          >
            <Code className="w-4 h-4" /> Export HTML
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-bold rounded-lg hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
            <Save className="w-4 h-4" /> Save
          </button>
        </div>
      </header>

      {/* SEO Settings Modal */}
      <AnimatePresence>
        {showSEOSettings && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-lg rounded-[32px] overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                    <Globe className="w-5 h-5 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-black text-slate-900 tracking-tight">Настройки SEO</h3>
                </div>
                <button onClick={() => setShowSEOSettings(false)} className="p-2 hover:bg-slate-100 rounded-xl transition-all">
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>
              <div className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Заголовок страницы (Title)</label>
                  <input 
                    className="w-full p-4 bg-slate-50 border-none rounded-2xl text-sm font-medium focus:ring-2 ring-blue-500/20"
                    value={seoData.title}
                    onChange={(e) => setSeoData({...seoData, title: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Описание (Description)</label>
                  <textarea 
                    className="w-full p-4 bg-slate-50 border-none rounded-2xl text-sm font-medium focus:ring-2 ring-blue-500/20 h-24"
                    value={seoData.description}
                    onChange={(e) => setSeoData({...seoData, description: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Ключевые слова</label>
                  <input 
                    className="w-full p-4 bg-slate-50 border-none rounded-2xl text-sm font-medium focus:ring-2 ring-blue-500/20"
                    value={seoData.keywords}
                    onChange={(e) => setSeoData({...seoData, keywords: e.target.value})}
                  />
                </div>
                <button 
                  onClick={handleSaveSEO}
                  className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all"
                >
                  Сохранить настройки
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Block Library */}
        <aside className="w-64 bg-white border-r border-slate-200 p-6 flex flex-col gap-6 shrink-0 overflow-y-auto">
          <div>
            <h3 className="text-xs font-black text-slate-300 uppercase tracking-widest mb-4">Add Blocks</h3>
            <div className="grid gap-3">
              {['Hero', 'Features', 'Gallery', 'Text', 'Footer'].map(type => (
                <button 
                  key={type}
                  className="w-full p-4 bg-slate-50 border border-slate-100 rounded-xl text-left hover:border-blue-200 hover:bg-blue-50/50 transition-all group"
                  onClick={() => {
                    const newBlock = { id: Date.now().toString(), type: type.toLowerCase(), content: { title: 'New ' + type, subtitle: 'Description' } };
                    setBlocks([...blocks, newBlock]);
                  }}
                >
                  <div className="text-sm font-bold text-slate-700 group-hover:text-blue-600 transition-colors">{type}</div>
                  <div className="text-[10px] text-slate-400">Drag to canvas</div>
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Canvas Area */}
        <main className="flex-1 bg-slate-100 overflow-y-auto p-12 flex justify-center">
          <div className={`transition-all duration-500 bg-white shadow-2xl rounded-sm overflow-hidden ${
            viewMode === 'mobile' ? 'w-[375px]' : viewMode === 'tablet' ? 'w-[768px]' : 'w-full max-w-5xl'
          }`}>
            <Reorder.Group axis="y" values={blocks} onReorder={setBlocks}>
              {blocks.map((block) => (
                <Reorder.Item 
                  key={block.id} 
                  value={block}
                  className="relative group"
                >
                  <div className={`p-16 border-b border-transparent hover:border-blue-400 transition-colors ${editingBlock === block.id ? 'border-blue-500' : ''}`}>
                    {/* Block Toolbar */}
                    <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                      <button 
                        onClick={() => setEditingBlock(block.id === editingBlock ? null : block.id)}
                        className="p-2 bg-white shadow-lg border border-slate-100 rounded-lg text-slate-600 hover:text-blue-600"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => deleteBlock(block.id)}
                        className="p-2 bg-white shadow-lg border border-slate-100 rounded-lg text-slate-600 hover:text-red-500"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Block Content Rendering */}
                    {block.type === 'hero' && (
                      <div className="text-center space-y-6">
                        <h1 className="text-5xl font-black text-slate-900" style={{ fontFamily: assets.fonts?.[0] }}>
                          {block.content.title}
                        </h1>
                        <p className="text-xl text-slate-500 max-w-2xl mx-auto">
                          {block.content.subtitle}
                        </p>
                        <button className="px-8 py-4 bg-blue-600 text-white font-bold rounded-xl" style={{ backgroundColor: assets.palette?.[1] }}>
                          Get Started
                        </button>
                      </div>
                    )}

                    {block.type === 'features' && (
                      <div className="grid grid-cols-3 gap-8">
                        {block.content.items?.map((item: any, i: number) => (
                          <div key={i} className="text-center space-y-3">
                            <div className="w-12 h-12 bg-blue-50 rounded-2xl mx-auto flex items-center justify-center text-blue-600">
                              <Plus className="w-6 h-6" />
                            </div>
                            <h3 className="font-bold text-slate-800">{item}</h3>
                            <p className="text-sm text-slate-500">Feature description text goes here.</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {block.type === 'pricing' && (
                      <div className="space-y-10">
                        <h2 className="text-3xl font-bold text-center text-slate-800">{block.content.title}</h2>
                        <div className="grid grid-cols-2 gap-8">
                          {block.content.plans?.map((plan: any, i: number) => (
                            <div key={i} className={`p-8 rounded-3xl border-2 transition-all ${plan.popular ? 'border-blue-500 bg-blue-50/20 shadow-xl' : 'border-slate-100'}`}>
                              <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                              <div className="text-4xl font-black mb-6">${plan.price}<span className="text-sm font-bold text-slate-400">/мес</span></div>
                              <ul className="space-y-3 mb-8">
                                {plan.features.map((f: string, j: number) => (
                                  <li key={j} className="flex items-center gap-2 text-sm text-slate-600 font-medium">
                                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" /> {f}
                                  </li>
                                ))}
                              </ul>
                              <button className={`w-full py-3 rounded-xl font-bold transition-all ${plan.popular ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-100 text-slate-600'}`}>
                                Выбрать план
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {block.type === 'footer' && (
                      <div className="text-center text-slate-400 text-sm py-8">
                        {block.content.text}
                      </div>
                    )}

                    {/* Inline Editor */}
                    {editingBlock === block.id && (
                      <div className="absolute inset-0 bg-blue-50/10 backdrop-blur-[2px] z-10 p-12 flex flex-col items-center justify-center">
                        <div className="bg-white p-6 rounded-2xl shadow-2xl border border-blue-100 w-full max-w-md">
                          <h4 className="font-bold mb-4">Edit {block.type}</h4>
                          <input 
                            className="w-full p-3 border rounded-xl mb-4" 
                            value={block.content.title || ''} 
                            placeholder="Title"
                            onChange={(e) => updateBlockContent(block.id, { title: e.target.value })}
                          />
                          <textarea 
                            className="w-full p-3 border rounded-xl mb-4" 
                            value={block.content.subtitle || block.content.text || ''} 
                            placeholder="Subtitle/Text"
                            onChange={(e) => updateBlockContent(block.id, { subtitle: e.target.value, text: e.target.value })}
                          />
                          <button 
                            onClick={() => setEditingBlock(null)}
                            className="w-full py-2 bg-blue-600 text-white rounded-lg font-bold"
                          >
                            Done
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </Reorder.Item>
              ))}
            </Reorder.Group>
            
            <button className="w-full py-8 border-2 border-dashed border-slate-100 hover:border-blue-200 text-slate-300 hover:text-blue-400 transition-all flex flex-col items-center gap-2 group">
              <Plus className="w-8 h-8 group-hover:scale-110 transition-transform" />
              <span className="font-bold">Add new block</span>
            </button>
          </div>
        </main>
      </div>
    </div>
  );
};
