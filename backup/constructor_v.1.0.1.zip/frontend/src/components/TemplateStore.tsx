import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Search, Filter, Star, Zap, X, ChevronRight, Globe, Layout, Palette } from 'lucide-react';

const TEMPLATES = [
  { id: '1', title: 'Neo-SaaS 2026', category: 'Website', price: 'Free', rating: 4.9, author: 'Constructor AI', image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=500' },
  { id: '2', title: 'Cyberpunk Portfolio', category: 'Social', price: '$12', rating: 5.0, author: 'DesignKing', image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=500' },
  { id: '3', title: 'Eco Minimalist', category: 'Presentation', price: 'Free', rating: 4.7, author: 'Studio Green', image: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&q=80&w=500' },
  { id: '4', title: 'Premium E-commerce', category: 'Website', price: '$29', rating: 4.8, author: 'ShopifyExpert', image: 'https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&q=80&w=500' },
];

export const TemplateStore: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [filter, setFilter] = useState('All');

  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col overflow-hidden">
      <header className="h-20 border-b border-slate-100 flex items-center justify-between px-10 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-100">
            <ShoppingBag className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">Marketplace</h2>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Templates & Add-ons</p>
          </div>
        </div>

        <div className="flex-1 max-w-xl mx-12 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Поиск по 5000+ шаблонам..."
            className="w-full pl-12 pr-6 py-3 bg-slate-50 border-none rounded-2xl text-sm font-medium outline-none focus:ring-2 ring-blue-500/20 transition-all"
          />
        </div>

        <button onClick={onClose} className="p-2 hover:bg-slate-50 rounded-xl transition-all">
          <X className="w-6 h-6 text-slate-400" />
        </button>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <aside className="w-64 border-r border-slate-100 p-8 space-y-8 shrink-0">
          <div>
            <h3 className="text-xs font-black text-slate-300 uppercase tracking-widest mb-4">Категории</h3>
            <div className="space-y-1">
              {['All', 'Website', 'Social', 'Presentation', 'Fonts', 'Logos'].map(cat => (
                <button 
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
                    filter === cat ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-8 border-t border-slate-100">
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 rounded-3xl text-white relative overflow-hidden">
              <Zap className="w-8 h-8 text-yellow-400 mb-4" />
              <h4 className="text-lg font-bold mb-2">Стать автором</h4>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">Зарабатывайте на своих дизайнах в нашем магазине.</p>
              <button className="w-full py-2.5 bg-white text-slate-900 rounded-xl text-xs font-black hover:bg-slate-100 transition-all">Подробнее</button>
            </div>
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto p-10 bg-slate-50/30">
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-10">
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">Рекомендуемые шаблоны</h3>
              <div className="flex items-center gap-2">
                <button className="p-2 bg-white border border-slate-200 rounded-lg text-slate-400"><Filter className="w-4 h-4" /></button>
                <select className="bg-white border border-slate-200 rounded-lg px-4 py-2 text-sm font-bold text-slate-600 outline-none">
                  <option>Сначала новые</option>
                  <option>Популярные</option>
                  <option>Бесплатные</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {TEMPLATES.filter(t => filter === 'All' || t.category === filter).map(t => (
                <motion.div 
                  key={t.id}
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-[32px] border border-slate-200 overflow-hidden group shadow-sm hover:shadow-2xl transition-all"
                >
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <img src={t.image} alt={t.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    <div className="absolute top-4 left-4 px-3 py-1 bg-white/90 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest text-slate-900">{t.category}</div>
                    <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/40 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <button className="px-6 py-3 bg-white text-slate-900 rounded-2xl font-bold text-sm shadow-xl flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                        Посмотреть <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="text-lg font-bold text-slate-800">{t.title}</h4>
                      <div className="flex items-center gap-1 text-amber-500">
                        <Star className="w-3 h-3 fill-current" />
                        <span className="text-xs font-bold">{t.rating}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center mt-4">
                      <div className="text-xs font-bold text-slate-400">by <span className="text-slate-900">{t.author}</span></div>
                      <div className="text-lg font-black text-blue-600">{t.price}</div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};
