import axios from 'axios';

const API_URL = 'http://localhost:3001/api';

export const api = {
  async getProjects() {
    const response = await axios.get(`${API_URL}/projects`);
    return response.data;
  },
  async getProject(id: string) {
    const response = await axios.get(`${API_URL}/projects/${id}`);
    return response.data;
  },
  async createProject(data: any) {
    const response = await axios.post(`${API_URL}/projects`, data);
    return response.data;
  },
  async updateProject(id: string, data: any) {
    const response = await axios.put(`${API_URL}/projects/${id}`, data);
    return response.data;
  },
  async deleteProject(id: string) {
    await axios.delete(`${API_URL}/projects/${id}`);
  },
  async exportProject(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/export`, {}, { responseType: 'blob' });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `website.html`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },
  async shareProject(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/share`);
    return response.data;
  },
  async generateFullContent(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/generate-content`);
    return response.data;
  },
  async translateProject(id: string, lang: 'ru' | 'en') {
    const response = await axios.post(`${API_URL}/projects/${id}/translate`, { lang });
    return response.data;
  }
};

