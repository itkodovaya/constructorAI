/**
 * Конфигурация AI для проекта
 * Создайте файл .env в корне backend/ и добавьте:
 * 
 * OPENAI_API_KEY=your_openai_key_here
 * STABLE_DIFFUSION_API_KEY=your_stable_diffusion_key_here
 * AI_USE_MOCK=true  # Установите false для использования реального AI
 */

import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.join(process.cwd(), '.env') });

export const AI_CONFIG = {
  useMock: process.env.AI_USE_MOCK !== 'false',
  openaiApiKey: process.env.OPENAI_API_KEY,
  stableDiffusionApiKey: process.env.STABLE_DIFFUSION_API_KEY,
};

