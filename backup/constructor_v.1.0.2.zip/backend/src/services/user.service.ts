/**
 * User Service для управления пользователями и тарифами
 */

export interface User {
  id: string;
  email: string;
  name: string;
  plan: 'free' | 'pro' | 'brandkit';
  projectsLimit: number;
  createdAt: string;
}

export interface PlanLimits {
  projects: number;
  aiGenerations: number;
  exports: number;
  teamMembers: number;
}

export class UserService {
  private static plans: Record<string, PlanLimits> = {
    free: {
      projects: 1,
      aiGenerations: 10,
      exports: 5,
      teamMembers: 1,
    },
    pro: {
      projects: Infinity,
      aiGenerations: Infinity,
      exports: Infinity,
      teamMembers: 5,
    },
    brandkit: {
      projects: Infinity,
      aiGenerations: Infinity,
      exports: Infinity,
      teamMembers: Infinity,
    },
  };

  static getPlanLimits(plan: string): PlanLimits {
    return this.plans[plan] || this.plans.free;
  }

  static canCreateProject(user: User): boolean {
    const limits = this.getPlanLimits(user.plan);
    return limits.projects === Infinity || user.projectsLimit < limits.projects;
  }

  static canUseAI(user: User): boolean {
    const limits = this.getPlanLimits(user.plan);
    return limits.aiGenerations === Infinity;
  }

  static canExport(user: User): boolean {
    const limits = this.getPlanLimits(user.plan);
    return limits.exports === Infinity;
  }

  static canAddTeamMember(user: User, currentMembers: number): boolean {
    const limits = this.getPlanLimits(user.plan);
    return limits.teamMembers === Infinity || currentMembers < limits.teamMembers;
  }
}

