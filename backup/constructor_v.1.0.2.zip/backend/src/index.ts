import express from 'express';
import cors from 'cors';
import { ProjectsService } from './services/projects.service';
import { ExportService } from './services/export.service';
import { TranslateService } from './services/translate.service';
import { AIContentService } from './services/ai_content.service';
import { AIService } from './services/ai.service';
import { AI_CONFIG } from './config/ai.config';
import { CreateProjectSchema, UpdateProjectSchema, validateProject } from './validation/project.validation';
import { ErrorHandler } from './middleware/errorHandler';
import { HealthService } from './services/health.service';

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

// Health check endpoint
app.get('/health', async (req, res) => {
  try {
    const dbCheck = await HealthService.checkDatabase();
    const diskCheck = await HealthService.checkDiskSpace();
    const systemInfo = await HealthService.getSystemInfo();
    
    const healthy = dbCheck.healthy && diskCheck.healthy;
    
    res.status(healthy ? 200 : 503).json({
      status: healthy ? 'ok' : 'degraded',
      timestamp: new Date().toISOString(),
      version: '1.0.1',
      aiMode: AI_CONFIG.useMock ? 'MOCK' : 'REAL',
      checks: {
        database: dbCheck,
        disk: diskCheck,
      },
      system: systemInfo,
    });
  } catch (error) {
    res.status(503).json({
      status: 'error',
      message: 'Health check failed',
    });
  }
});

// Конфигурация AI
AIService.configure(AI_CONFIG);

// Получение всех проектов
app.get('/api/projects', async (req, res) => {
  try {
    const projects = await ProjectsService.getAll();
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Получение одного проекта
app.get('/api/projects/:id', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

// Создание проекта (Onboarding)
app.post('/api/projects', async (req, res) => {
  try {
    // Валидация входных данных
    const validation = validateProject(req.body, CreateProjectSchema);
    if (!validation.success) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: validation.errors 
      });
    }

    const project = await ProjectsService.create(validation.data);
    res.status(201).json(project);
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ error: 'Failed to create project' });
  }
});

// Обновление проекта
app.put('/api/projects/:id', async (req, res) => {
  try {
    // Валидация входных данных
    const validation = validateProject(req.body, UpdateProjectSchema);
    if (!validation.success) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: validation.errors 
      });
    }

    const project = await ProjectsService.update(req.params.id, validation.data);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({ error: 'Failed to update project' });
  }
});

// Удаление проекта
app.delete('/api/projects/:id', async (req, res) => {
  try {
    const success = await ProjectsService.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Project not found' });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete project' });
  }
});

// AI Перевод проекта (с использованием реального AI или заглушек)
app.post('/api/projects/:id/translate', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const targetLang = req.body.lang || 'en';
    
    // Используем реальный AI для перевода текста в блоках
    const translatedPages = await Promise.all(
      project.pages.map(async (page) => ({
        ...page,
        blocks: await Promise.all(
          page.blocks.map(async (block) => {
            const translatedContent = await translateBlockContent(block.content, targetLang);
            return { ...block, content: translatedContent };
          })
        )
      }))
    );

    const updatedProject = await ProjectsService.update(project.id, {
      pages: translatedPages
    });
    
    res.json(updatedProject);
  } catch (error) {
    console.error('Translation error:', error);
    res.status(500).json({ error: 'Translation failed' });
  }
});

// Вспомогательная функция для перевода контента блока
async function translateBlockContent(content: any, targetLang: 'ru' | 'en'): Promise<any> {
  if (typeof content === 'string') {
    return await AIService.translateText(content, targetLang);
  }
  
  if (Array.isArray(content)) {
    return await Promise.all(content.map(item => translateBlockContent(item, targetLang)));
  }
  
  if (typeof content === 'object' && content !== null) {
    const translated: any = {};
    for (const key in content) {
      translated[key] = await translateBlockContent(content[key], targetLang);
    }
    return translated;
  }
  
  return content;
}

// AI Генерация полного контента страницы (с использованием реального AI)
app.post('/api/projects/:id/generate-content', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    // Используем реальный AI для генерации контента
    const prompt = `Создай контент для сайта бренда "${project.brandName}" в нише "${project.niche}". Нужны блоки: Hero (заголовок и подзаголовок), Features (3-4 особенности), Text (описание), Footer.`;
    
    const aiContent = await AIService.generateText(prompt, 800);
    
    // Парсим ответ AI и создаем блоки (упрощенная версия)
    const newBlocks = AIContentService.generatePageContent(project.niche, project.brandName);
    
    // Если AI вернул контент, обновляем блоки
    if (aiContent && !AI_CONFIG.useMock) {
      // В реальности здесь будет более сложный парсинг ответа AI
      newBlocks[0].content.title = project.brandName;
      newBlocks[0].content.subtitle = aiContent.substring(0, 100);
    }
    
    const updatedProject = await ProjectsService.update(project.id, {
      pages: [{ ...project.pages[0], blocks: newBlocks }]
    });
    
    res.json(updatedProject);
  } catch (error) {
    console.error('Content generation error:', error);
    // Fallback на старый метод
    try {
      const project = await ProjectsService.getById(req.params.id);
      const newBlocks = AIContentService.generatePageContent(project!.niche, project!.brandName);
      const updatedProject = await ProjectsService.update(project!.id, {
        pages: [{ ...project!.pages[0], blocks: newBlocks }]
      });
      res.json(updatedProject);
    } catch (fallbackError) {
      res.status(500).json({ error: 'Failed to generate content' });
    }
  }
});

// Предпросмотр HTML (возвращает HTML для отображения в iframe)
app.get('/api/projects/:id/preview', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const html = ExportService.generateHTML(
      project.brandName,
      project.brandAssets,
      project.pages[0]?.blocks || []
    );
    
    res.setHeader('Content-Type', 'text/html');
    res.send(html);
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate preview' });
  }
});

// Экспорт сайта в HTML
app.post('/api/projects/:id/export', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const html = ExportService.generateHTML(
      project.brandName,
      project.brandAssets,
      project.pages[0]?.blocks || []
    );
    
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Disposition', `attachment; filename="${project.brandName}_website.html"`);
    res.send(html);
  } catch (error) {
    res.status(500).json({ error: 'Failed to export site' });
  }
});

// Экспорт презентации в PDF (заглушка)
app.post('/api/projects/:id/export-presentation', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    // TODO: Реализовать генерацию PDF через библиотеку (например, pdfkit или puppeteer)
    res.json({ message: 'PDF export будет реализован в следующей версии', slides: project.presentation || [] });
  } catch (error) {
    res.status(500).json({ error: 'Failed to export presentation' });
  }
});

// Экспорт бренд-кита в ZIP (заглушка)
app.post('/api/projects/:id/export-brandkit', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    // TODO: Реализовать создание ZIP архива с логотипами, палитрой, шрифтами
    res.json({ 
      message: 'ZIP export будет реализован в следующей версии',
      assets: project.brandAssets 
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to export brand kit' });
  }
});

// Генерация ссылки для шеринга
app.post('/api/projects/:id/share', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const shareId = Math.random().toString(36).substr(2, 12);
    // В реальной БД мы бы сохранили этот shareId
    res.json({ shareUrl: `https://constructor.ai/view/${shareId}` });
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate share link' });
  }
});

// Обработка ошибок (должен быть последним middleware)
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  ErrorHandler.handle(err, req, res, next);
});

app.listen(port, () => {
  console.log(`Backend running at http://localhost:${port}`);
  console.log(`AI Mode: ${AI_CONFIG.useMock ? 'MOCK (заглушки)' : 'REAL (требуются API ключи)'}`);
});
