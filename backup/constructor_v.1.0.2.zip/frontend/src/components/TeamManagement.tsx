import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Mail, Shield, ShieldCheck, ShieldAlert, Plus, MoreHorizontal, UserPlus } from 'lucide-react';

export const TeamManagement: React.FC = () => {
  const [members, setMembers] = useState([
    { id: '1', name: 'Алексей Дизайнеров', email: 'alex@mybrand.com', role: 'Владелец', status: 'Active', avatar: 'https://i.pravatar.cc/100?img=11' },
    { id: '2', name: 'Мария Контентова', email: 'masha@mybrand.com', role: 'Редактор', status: 'Active', avatar: 'https://i.pravatar.cc/100?img=32' },
    { id: '3', name: 'Иван Заказчиков', email: 'ivan@client.ru', role: 'Зритель', status: 'Invited', avatar: 'https://i.pravatar.cc/100?img=15' },
  ]);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">Участники команды</h2>
          <p className="text-slate-500 font-medium">Управляйте доступом и ролями ваших коллег</p>
        </div>
        <button className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-bold flex items-center gap-2 hover:bg-slate-800 transition-all shadow-xl shadow-slate-200">
          <UserPlus className="w-5 h-5" /> Пригласить
        </button>
      </div>

      <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50/50 border-b border-slate-50">
            <tr>
              <th className="px-10 py-5 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Пользователь</th>
              <th className="px-10 py-5 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Роль</th>
              <th className="px-10 py-5 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Статус</th>
              <th className="px-10 py-5 text-right"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {members.map(member => (
              <tr key={member.id} className="group hover:bg-slate-50/30 transition-colors">
                <td className="px-10 py-6 flex items-center gap-4">
                  <img src={member.avatar} alt={member.name} className="w-10 h-10 rounded-xl object-cover" />
                  <div>
                    <div className="text-sm font-bold text-slate-800">{member.name}</div>
                    <div className="text-xs text-slate-400">{member.email}</div>
                  </div>
                </td>
                <td className="px-10 py-6">
                  <div className="flex items-center gap-2">
                    {member.role === 'Владелец' ? <ShieldCheck className="w-4 h-4 text-indigo-600" /> : 
                     member.role === 'Редактор' ? <Shield className="w-4 h-4 text-blue-500" /> : 
                     <ShieldAlert className="w-4 h-4 text-slate-300" />}
                    <span className="text-xs font-bold text-slate-700">{member.role}</span>
                  </div>
                </td>
                <td className="px-10 py-6">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    member.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                  }`}>
                    {member.status}
                  </span>
                </td>
                <td className="px-10 py-6 text-right">
                  <button className="p-2 text-slate-300 hover:text-slate-600 transition-colors">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="p-8 bg-indigo-50 rounded-[40px] border border-indigo-100 flex items-center justify-between gap-10">
        <div className="space-y-2">
          <h4 className="text-lg font-bold text-indigo-900">Нужно больше участников?</h4>
          <p className="text-sm text-indigo-700/70 font-medium">Перейдите на тариф Enterprise, чтобы добавить до 50 сотрудников и настроить SSO.</p>
        </div>
        <button className="whitespace-nowrap px-8 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
          Узнать больше
        </button>
      </div>
    </div>
  );
};

