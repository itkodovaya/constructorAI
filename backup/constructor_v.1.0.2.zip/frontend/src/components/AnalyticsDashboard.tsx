import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, Users, MousePointer2, Globe, ArrowUpRight, Clock } from 'lucide-react';

export const AnalyticsDashboard: React.FC = () => {
  const stats = [
    { label: 'Посетители', value: '1,284', change: '+12%', icon: <Users className="w-5 h-5" />, color: 'text-blue-600' },
    { label: 'Конверсия', value: '3.4%', change: '+0.5%', icon: <MousePointer2 className="w-5 h-5" />, color: 'text-emerald-600' },
    { label: 'Время на сайте', value: '2м 45с', change: '-10с', icon: <Clock className="w-5 h-5" />, color: 'text-purple-600' },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm"
          >
            <div className="flex justify-between items-start mb-4">
              <div className={`p-3 rounded-2xl bg-slate-50 ${stat.color}`}>
                {stat.icon}
              </div>
              <span className={`text-xs font-bold flex items-center gap-1 ${stat.change.startsWith('+') ? 'text-emerald-500' : 'text-red-400'}`}>
                {stat.change} <TrendingUp className={`w-3 h-3 ${stat.change.startsWith('-') ? 'rotate-180' : ''}`} />
              </span>
            </div>
            <div className="text-2xl font-black text-slate-900">{stat.value}</div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Chart Mockup */}
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <h3 className="font-bold text-slate-800">Активность за неделю</h3>
            <select className="text-xs font-bold text-slate-400 bg-slate-50 px-3 py-1 rounded-lg outline-none">
              <option>Последние 7 дней</option>
              <option>Месяц</option>
            </select>
          </div>
          <div className="h-48 flex items-end gap-3 px-2">
            {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
              <motion.div 
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ delay: 0.5 + i * 0.1, type: 'spring' }}
                className="flex-1 bg-blue-600/10 rounded-t-xl relative group"
              >
                <div className="absolute inset-x-0 bottom-0 bg-blue-600 rounded-t-xl transition-all h-1/3 group-hover:h-full" />
              </motion.div>
            ))}
          </div>
          <div className="flex justify-between mt-4 px-2 text-[10px] font-bold text-slate-300 uppercase tracking-widest">
            <span>Пн</span><span>Вт</span><span>Ср</span><span>Чт</span><span>Пт</span><span>Сб</span><span>Вс</span>
          </div>
        </div>

        {/* Top Pages */}
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-6">Популярные страницы</h3>
          <div className="space-y-4">
            {[
              { path: '/', views: '842', rate: '45%' },
              { path: '/products', views: '421', rate: '22%' },
              { path: '/about', views: '154', rate: '12%' }
            ].map((page, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl group hover:bg-blue-50 transition-all cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-slate-400 group-hover:text-blue-600 transition-colors">
                    <Globe className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-bold text-slate-700">{page.path}</span>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <div className="text-xs font-bold text-slate-800">{page.views}</div>
                    <div className="text-[10px] font-bold text-slate-400">Просмотры</div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 transition-colors" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

