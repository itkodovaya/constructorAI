import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Zap, Image as ImageIcon, Download, X, CheckCircle2 } from 'lucide-react';

interface SocialContentGeneratorProps {
  brandName: string;
  assets: any;
  onClose: () => void;
}

export const SocialContentGenerator: React.FC<SocialContentGeneratorProps> = ({ brandName, assets, onClose }) => {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(['instagram', 'vk']);
  const [generatedPosts, setGeneratedPosts] = useState<any[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const platforms = [
    { id: 'instagram', name: 'Instagram', color: 'bg-pink-500' },
    { id: 'vk', name: 'VK', color: 'bg-blue-500' },
    { id: 'telegram', name: 'Telegram', color: 'bg-sky-500' },
    { id: 'youtube', name: 'YouTube', color: 'bg-red-500' },
  ];

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const posts = selectedPlatforms.map(platform => ({
        id: Date.now() + Math.random(),
        platform,
        content: `Новый пост для ${brandName}! 🚀`,
        image: assets.logo,
        format: platform === 'instagram' ? '1080x1080' : '1200x800'
      }));
      setGeneratedPosts(posts);
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full max-w-4xl rounded-[40px] overflow-hidden shadow-2xl"
      >
        <div className="p-10 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">AI Генератор контента</h2>
              <p className="text-slate-500 font-medium">Создайте посты для всех платформ одновременно</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-50 rounded-xl transition-all">
            <X className="w-6 h-6 text-slate-400" />
          </button>
        </div>

        <div className="p-10 space-y-8">
          <div>
            <label className="text-xs font-black text-slate-300 uppercase tracking-widest mb-4 block">Выберите платформы</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {platforms.map(platform => (
                <button
                  key={platform.id}
                  onClick={() => {
                    setSelectedPlatforms(prev => 
                      prev.includes(platform.id) 
                        ? prev.filter(p => p !== platform.id)
                        : [...prev, platform.id]
                    );
                  }}
                  className={`p-6 rounded-2xl border-2 transition-all ${
                    selectedPlatforms.includes(platform.id)
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-md'
                      : 'border-slate-100 hover:border-slate-200'
                  }`}
                >
                  <div className={`w-12 h-12 ${platform.color} rounded-xl mx-auto mb-3 flex items-center justify-center text-white`}>
                    <ImageIcon className="w-6 h-6" />
                  </div>
                  <div className="text-sm font-bold text-slate-800">{platform.name}</div>
                  {selectedPlatforms.includes(platform.id) && (
                    <CheckCircle2 className="w-5 h-5 text-indigo-600 mx-auto mt-2" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <button 
            onClick={handleGenerate}
            disabled={isGenerating || selectedPlatforms.length === 0}
            className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-3"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Генерация контента...
              </>
            ) : (
              <>
                <Zap className="w-5 h-5" />
                Сгенерировать {selectedPlatforms.length} постов
              </>
            )}
          </button>

          {generatedPosts.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-800">Сгенерированные посты</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {generatedPosts.map(post => (
                  <div key={post.id} className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-bold text-slate-400 uppercase">{post.platform}</span>
                      <span className="text-xs font-mono text-slate-300">{post.format}</span>
                    </div>
                    <div className="aspect-square bg-white rounded-xl mb-4 flex items-center justify-center p-4">
                      <img src={post.image} alt="Post" className="max-w-full max-h-full object-contain" />
                    </div>
                    <p className="text-sm text-slate-700 mb-4">{post.content}</p>
                    <button className="w-full py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition-all">
                      <Download className="w-4 h-4 inline mr-2" /> Скачать
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

