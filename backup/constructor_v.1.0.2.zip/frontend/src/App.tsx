import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, Palette, Layout, Rocket, ChevronRight, 
  Settings, User, Bell, Search, Plus, Trash2, 
  ExternalLink, Share2, History, Smartphone, 
  Calendar, ShoppingBag, Grid, HelpCircle, 
  MessageSquare, Smartphone as MobileIcon, Globe,
  CreditCard, ChevronLeft, LogOut, Box, ImageIcon, Users, BarChart3, Download
} from 'lucide-react';
import confetti from 'canvas-confetti';

// Components
import { BrandPanel } from './components/BrandPanel';
import { SiteBuilder } from './components/SiteBuilder';
import { PresentationBuilder } from './components/PresentationBuilder';
import { GraphicsEditor } from './components/GraphicsEditor';
import { AIAssistant } from './components/AIAssistant';
import { PricingModal } from './components/PricingModal';
import { ShareModal } from './components/ShareModal';
import { HistorySidebar } from './components/HistorySidebar';
import { DevicePreview } from './components/DevicePreview';
import { ContentPlanner } from './components/ContentPlanner';
import { TemplateStore } from './components/TemplateStore';
import { Integrations } from './components/Integrations';
import { HelpCenter } from './components/HelpCenter';
import { NotificationCenter } from './components/NotificationCenter';
import { CommandPalette } from './components/CommandPalette';
import { FeedbackModal } from './components/FeedbackModal';
import { MobileAppPromo } from './components/MobileAppPromo';
import { SocialMediaIntegration } from './components/SocialMediaIntegration';
import { WizardForm } from './components/WizardForm';

// Services
import { api } from './services/api';

import { PlanLimits } from './components/PlanLimits';
import { SocialContentGenerator } from './components/SocialContentGenerator';
import { PreviewModal } from './components/PreviewModal';
import { BrandShowcase } from './components/BrandShowcase';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { AssetLibrary } from './components/AssetLibrary';
import { TeamManagement } from './components/TeamManagement';
import { ProjectSettings } from './components/ProjectSettings';
import { HelpWidget } from './components/HelpWidget';
import { Moon, Sun } from 'lucide-react';

function App() {
  const [view, setView] = useState<'onboarding' | 'dashboard' | 'project'>('onboarding');
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'brand' | 'showcase' | 'assets' | 'team' | 'settings'>('overview');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [lang, setLanguage] = useState<'RU' | 'EN'>('RU');
  const [loading, setLoading] = useState(false);
  const [projects, setProjects] = useState<any[]>([]);
  const [showEditor, setShowEditor] = useState(false);
  const [showSiteBuilder, setShowSiteBuilder] = useState(false);
  const [showPresentation, setShowPresentation] = useState(false);
  const [showGraphics, setShowGraphics] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showContentPlanner, setShowContentPlanner] = useState(false);
  const [showTemplateStore, setShowTemplateStore] = useState(false);
  const [showIntegrations, setShowIntegrations] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showMobileApp, setShowMobileApp] = useState(false);
  const [showSocialMedia, setShowSocialMedia] = useState(false);
  const [showSocialGenerator, setShowSocialGenerator] = useState(false);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    fetchProjects();
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowCommandPalette(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const commands = [
    { label: 'Открыть конструктор сайтов', category: 'Редактор', icon: <Layout />, onClick: () => setShowSiteBuilder(true) },
    { label: 'Изменить бренд-кит', category: 'Дизайн', icon: <Palette />, onClick: () => setShowEditor(true) },
    { label: 'Экспортировать в HTML', category: 'Экспорт', icon: <Download />, onClick: () => profile && api.exportProject(profile.id) },
    { label: 'Поделиться проектом', category: 'Совместная работа', icon: <Share2 />, onClick: () => setShowShare(true) },
    { label: 'Настройки SEO', category: 'Маркетинг', icon: <Globe />, onClick: () => setShowSiteBuilder(true) },
    { label: 'Мобильное приложение', category: 'Платформа', icon: <Smartphone />, onClick: () => setShowMobileApp(true) },
    { label: 'Оставить отзыв', category: 'Система', icon: <MessageSquare />, onClick: () => setShowFeedback(true) },
  ];

  const fetchProjects = async () => {
    try {
      setLoading(true);
      const data = await api.getProjects();
      setProjects(data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (wizardData: any) => {
    setLoading(true);
    try {
      const newProject = await api.createProject(wizardData);
      setProfile(newProject);
      await fetchProjects();
      
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#2563eb', '#9333ea', '#db2777']
      });

      setTimeout(() => {
        setView('project');
        setLoading(false);
      }, 1500);
    } catch (error) {
      console.error('Error creating project:', error);
      setLoading(false);
    }
  };

  const deleteProject = async (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!confirm(lang === 'RU' ? 'Удалить этот проект?' : 'Delete this project?')) return;
    try {
      await api.deleteProject(id);
      fetchProjects();
      if (profile?.id === id) {
        setView('dashboard');
        setProfile(null);
      }
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  const updateBrandAssets = async (newAssets: any) => {
    if (!profile) return;
    try {
      const updated = await api.updateProject(profile.id, {
        brandAssets: { ...profile.brandAssets, ...newAssets }
      });
      setProfile(updated);
    } catch (error) {
      console.error('Error updating assets:', error);
    }
  };

  const updateProjectSEO = async (newSEO: any) => {
    if (!profile) return;
    try {
      const updated = await api.updateProject(profile.id, { seo: newSEO });
      setProfile(updated);
    } catch (error) {
      console.error('Error updating SEO:', error);
    }
  };

  const handleAIAction = (action: string) => {
    console.log('AI Action triggered:', action);
    if (action === 'update_palette') {
      const brightPalette = ['#F43F5E', '#FB923C', '#FACC15', '#2DD4BF'];
      updateBrandAssets({ palette: brightPalette });
      alert('AI обновил палитру!');
    }
  };

  if (view === 'dashboard') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <div className="flex-1 p-12">
          <div className="max-w-6xl mx-auto space-y-10">
            <header className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-xl shadow-indigo-100">
                  <Sparkles className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-black text-slate-900 tracking-tight">Мои проекты</h1>
                  <p className="text-slate-500 font-medium">Все ваши сгенерированные бренды</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <button onClick={() => setLanguage(lang === 'RU' ? 'EN' : 'RU')} className="w-10 h-10 rounded-xl border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-500 hover:bg-white hover:shadow-sm transition-all">{lang}</button>
                <button onClick={() => setShowPricing(true)} className="px-6 py-3 text-sm font-bold text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all">{lang === 'RU' ? 'Тарифы' : 'Pricing'}</button>
                <button onClick={() => setView('onboarding')} className="bg-indigo-600 text-white px-8 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"><Plus className="w-5 h-5" /> {lang === 'RU' ? 'Новый проект' : 'New Project'}</button>
              </div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((p) => (
                <div 
                  key={p.id}
                  onClick={() => { setProfile(p); setView('project'); }}
                  className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group cursor-pointer relative overflow-hidden"
                >
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-2xl font-bold text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                      {p.brandName[0]}
                    </div>
                    <button 
                      onClick={(e) => deleteProject(p.id, e)}
                      className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-1">{p.brandName}</h3>
                  <p className="text-slate-400 text-sm font-medium mb-6 capitalize">{p.style} • {p.niche}</p>
                  <div className="flex items-center gap-2 text-sm font-bold text-indigo-600 group-hover:gap-3 transition-all">
                    Открыть проект <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'project' && profile) {
    return (
      <div className="min-h-screen bg-white flex overflow-hidden">
        {/* Sidebar */}
        <aside className="w-72 border-r border-slate-100 flex flex-col bg-slate-50/50">
          <div className="p-8">
            <div className="flex items-center gap-3 mb-10 cursor-pointer" onClick={() => setView('dashboard')}>
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-100">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-lg font-black text-slate-900 tracking-tight">Constructor</span>
            </div>

            <nav className="space-y-1">
              <NavItem icon={<Grid className="w-5 h-5" />} label="Главная" active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} />
              <NavItem icon={<Box className="w-5 h-5" />} label="Showcase" active={activeTab === 'showcase'} onClick={() => setActiveTab('showcase')} />
              <NavItem icon={<ImageIcon className="w-5 h-5" />} label="Медиа" active={activeTab === 'assets'} onClick={() => setActiveTab('assets')} />
              <NavItem icon={<Users className="w-5 h-5" />} label="Команда" active={activeTab === 'team'} onClick={() => setActiveTab('team')} />
              <NavItem icon={<BarChart3 className="w-5 h-5" />} label="Аналитика" active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} />
              <NavItem icon={<Palette className="w-5 h-5" />} label="Бренд-кит" onClick={() => setShowEditor(true)} />
              <NavItem icon={<Layout className="w-5 h-5" />} label="Сайт" onClick={() => setShowSiteBuilder(true)} />
              <NavItem icon={<Smartphone className="w-5 h-5" />} label="Приложение" onClick={() => setShowMobileApp(true)} />
              <NavItem icon={<Calendar className="w-5 h-5" />} label="Контент-план" onClick={() => setShowContentPlanner(true)} />
              <NavItem icon={<Share2 className="w-5 h-5" />} label="Соцсети" onClick={() => setShowSocialMedia(true)} />
              <NavItem icon={<Sparkles className="w-5 h-5" />} label="Генератор постов" onClick={() => setShowSocialGenerator(true)} />
              <NavItem icon={<History className="w-5 h-5" />} label="История" onClick={() => setShowHistory(true)} />
              <NavItem icon={<MessageSquare className="w-5 h-5" />} label="Отзыв" onClick={() => setShowFeedback(true)} />
              <NavItem icon={<Settings className="w-5 h-5" />} label="Настройки" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
            </nav>
          </div>

          <div className="mt-auto p-6 border-t border-slate-100">
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs">AI</div>
                <div className="text-xs font-bold text-slate-800">Constructor Pro</div>
              </div>
              <div className="w-full h-1.5 bg-slate-100 rounded-full mb-3 overflow-hidden">
                <div className="w-3/4 h-full bg-indigo-600" />
              </div>
              <button onClick={() => setShowPricing(true)} className="w-full py-2 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-colors">Улучшить план</button>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="h-20 border-b border-slate-100 flex items-center justify-between px-10 bg-white/80 backdrop-blur-md z-10">
            <div className="flex items-center gap-4">
              <h2 className="text-xl font-bold text-slate-900">{profile.brandName}</h2>
              <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-black uppercase tracking-widest rounded-full">Активен</span>
            </div>
            <div className="flex items-center gap-3">
              <button onClick={() => setShowCommandPalette(true)} className="flex items-center gap-3 px-4 py-2 bg-slate-50 text-slate-400 rounded-xl hover:bg-slate-100 transition-all text-sm font-medium border border-slate-100"><Search className="w-4 h-4" /> <span>Ctrl + K</span></button>
              <button onClick={() => setShowNotifications(true)} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-indigo-600 transition-colors relative"><Bell className="w-5 h-5" /><div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" /></button>
              <button onClick={() => setShowUserMenu(!showUserMenu)} className="w-10 h-10 rounded-xl bg-slate-100 overflow-hidden border border-slate-200"><img src="https://i.pravatar.cc/100?img=33" alt="avatar" /></button>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto p-10 bg-slate-50/30">
            <AnimatePresence mode="wait">
              {activeTab === 'overview' && (
                <motion.div 
                  key="overview"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="max-w-6xl mx-auto space-y-10"
                >
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <MagicCard title="Генератор сайта" description="AI создал структуру вашего лендинга. Настройте блоки и контент." icon={<Layout className="w-8 h-8 text-indigo-600" />} badge="Готово" onClick={() => setShowSiteBuilder(true)} />
                    <MagicCard title="Бренд-бук" description="Логотип, палитра и шрифты, подобранные специально для вас." icon={<Palette className="w-8 h-8 text-pink-600" />} badge="Готово" onClick={() => setShowEditor(true)} />
                  </div>

                  <div className="bg-white p-10 rounded-[40px] border border-slate-200 shadow-sm overflow-hidden relative">
                    <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
                      <Sparkles className="w-64 h-64 text-indigo-600" />
                    </div>
                    <div className="relative z-10">
                      <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3"><Sparkles className="w-6 h-6 text-indigo-600" /> AI Помощник</h3>
                      <AIAssistant onAction={handleAIAction} brandName={profile.brandName} />
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'analytics' && (
                <motion.div 
                  key="analytics"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="max-w-6xl mx-auto"
                >
                  <div className="mb-10">
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">Аналитика сайта</h2>
                    <p className="text-slate-500 font-medium">Следите за ростом вашего бизнеса в реальном времени</p>
                  </div>
                  <AnalyticsDashboard />
                </motion.div>
              )}

              {activeTab === 'showcase' && (
                <motion.div 
                  key="showcase"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="max-w-6xl mx-auto"
                >
                  <div className="mb-10">
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">Brand Identity Showcase</h2>
                    <p className="text-slate-500 font-medium">Посмотрите, как ваш бренд выглядит на реальных носителях</p>
                  </div>
                  <BrandShowcase brandName={profile.brandName} assets={profile.brandAssets} />
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div 
                  key="settings"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="max-w-6xl mx-auto space-y-8"
                >
                  <div className="mb-10">
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">Настройки проекта</h2>
                    <p className="text-slate-500 font-medium">Управление доменом и параметрами бренда</p>
                  </div>
                  <PlanLimits 
                    currentPlan={userPlan} 
                    projectsCount={projects.length}
                    onUpgrade={(plan) => {
                      setShowPricing(true);
                      setUserPlan(plan);
                    }}
                  />
                  <ProjectSettings project={profile} onUpdate={(data) => updateBrandAssets(data)} onDelete={() => deleteProject(profile.id)} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>

        {/* Modals & Overlays */}
        {showEditor && <BrandPanel brandName={profile.brandName} assets={profile.brandAssets} onClose={() => setShowEditor(false)} onUpdate={updateBrandAssets} />}
            {showSiteBuilder && <SiteBuilder brandName={profile.brandName} assets={profile.brandAssets} seo={profile.seo} onUpdateSEO={updateProjectSEO} projectId={profile.id} onPreview={() => setShowPreview(true)} onClose={() => setShowSiteBuilder(false)} />}
            {showPreview && <PreviewModal projectId={profile.id} brandName={profile.brandName} onClose={() => setShowPreview(false)} />}
            {showPricing && <PricingModal isOpen={showPricing} onClose={() => setShowPricing(false)} />}
            {showShare && <ShareModal onClose={() => setShowShare(false)} brandName={profile.brandName} projectId={profile.id} />}
            {showHistory && <HistorySidebar history={profile.history || []} onClose={() => setShowHistory(false)} onRestore={(assets) => updateBrandAssets(assets)} />}
            {showPreview && <DevicePreview onClose={() => setShowPreview(false)} />}
            {showContentPlanner && <ContentPlanner onClose={() => setShowContentPlanner(false)} brandName={profile.brandName} logoUrl={profile.brandAssets?.logo || ''} />}
            {showTemplateStore && <TemplateStore onClose={() => setShowTemplateStore(false)} />}
            {showIntegrations && <Integrations />}
        {showHelp && <HelpCenter onClose={() => setShowHelp(false)} />}
        {showNotifications && <NotificationCenter onClose={() => setShowNotifications(false)} />}
        {showCommandPalette && <CommandPalette actions={commands} onClose={() => setShowCommandPalette(false)} />}
        {showFeedback && <FeedbackModal onClose={() => setShowFeedback(false)} />}
        {showMobileApp && <MobileAppPromo onClose={() => setShowMobileApp(false)} />}
        {showSocialMedia && <SocialMediaIntegration onClose={() => setShowSocialMedia(false)} />}
        {showSocialGenerator && profile && <SocialContentGenerator brandName={profile.brandName} assets={profile.brandAssets} onClose={() => setShowSocialGenerator(false)} />}
      </div>
    );
  }

  if (view === 'onboarding') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        {loading && (
          <div className="fixed inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center z-50">
            <div className="w-20 h-20 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-xl font-bold text-slate-800">Создаем магию вашего бренда...</p>
          </div>
        )}
        <WizardForm onComplete={handleSubmit} />
        <div className="mt-10 flex flex-col items-center gap-6 opacity-40">
          <div className="flex justify-center gap-8">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em]">Secure Payments</span>
            <span className="text-[10px] font-bold uppercase tracking-[0.2em]">Privacy First</span>
            <span className="text-[10px] font-bold uppercase tracking-[0.2em]">24/7 AI Support</span>
          </div>
          <div className="text-[9px] font-medium text-slate-400 max-w-xs text-center leading-relaxed">
            Используя сервис, вы соглашаетесь с Политикой обработки персональных данных и Условиями использования (согласно законодательству РФ).
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Загрузка...</h1>
        <p className="text-slate-500">Инициализация приложения</p>
      </div>
    </div>
  );
}

function NavItem({ icon, label, onClick, active = false }: { icon: React.ReactNode, label: string, onClick: () => void, active?: boolean }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${
      active ? 'bg-indigo-50 text-indigo-600 shadow-sm' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
    }`}>
      {icon}
      <span>{label}</span>
        </button>
  );
}

function MagicCard({ title, description, icon, badge, onClick }: { title: string, description: string, icon: React.ReactNode, badge: string, onClick: () => void }) {
  return (
    <div 
      onClick={onClick}
      className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group cursor-pointer"
    >
      <div className="flex justify-between items-start mb-6">
        <div className="p-4 bg-slate-50 rounded-2xl group-hover:scale-110 transition-transform duration-500">
          {icon}
        </div>
        <span className={`text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full ${
          badge.includes('...') ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'
        }`}>
          {badge}
        </span>
      </div>
      <h4 className="text-xl font-bold text-slate-800 mb-2">{title}</h4>
      <p className="text-slate-500 text-sm leading-relaxed mb-6">{description}</p>
      <div className="flex items-center gap-2 text-sm font-bold text-indigo-600">
        Открыть редактор <ChevronRight className="w-4 h-4" />
      </div>
    </div>
  );
}

export default App;
