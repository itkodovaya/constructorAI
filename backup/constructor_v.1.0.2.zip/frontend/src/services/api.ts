import axios from 'axios';
import { handleApiError, showErrorNotification } from '../utils/errorHandler';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Создаем axios instance с базовой конфигурацией
const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor для обработки ошибок
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = handleApiError(error);
    showErrorNotification(message);
    return Promise.reject(error);
  }
);

export const api = {
  async getProjects() {
    const response = await apiClient.get('/projects');
    return response.data;
  },
  async getProject(id: string) {
    const response = await apiClient.get(`/projects/${id}`);
    return response.data;
  },
  async createProject(data: any) {
    const response = await apiClient.post('/projects', data);
    return response.data;
  },
  async updateProject(id: string, data: any) {
    const response = await apiClient.put(`/projects/${id}`, data);
    return response.data;
  },
  async deleteProject(id: string) {
    await apiClient.delete(`/projects/${id}`);
  },
  async exportProject(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/export`, {}, { responseType: 'blob' });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `website.html`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },
  async shareProject(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/share`);
    return response.data;
  },
  async generateFullContent(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/generate-content`);
    return response.data;
  },
  async translateProject(id: string, lang: 'ru' | 'en') {
    const response = await axios.post(`${API_URL}/projects/${id}/translate`, { lang });
    return response.data;
  },
  getPreviewUrl(id: string): string {
    return `${API_URL}/projects/${id}/preview`;
  },
  async exportPresentation(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/export-presentation`);
    return response.data;
  },
  async exportBrandKit(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/export-brandkit`);
    return response.data;
  }
};

