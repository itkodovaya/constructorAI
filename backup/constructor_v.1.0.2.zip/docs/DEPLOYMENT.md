# 🚀 Constructor AI Platform - Руководство по развертыванию

## 📦 Быстрый старт

### 1. Установка зависимостей

```bash
# Backend
cd backend
npm install

# Frontend (в другом терминале)
cd frontend
npm install
```

### 2. Конфигурация

#### Backend
```bash
cd backend
cp .env.example .env
# Отредактируйте .env и добавьте API ключи (опционально)
```

#### Frontend
```bash
cd frontend
cp .env.example .env
# Отредактируйте .env если нужно изменить API URL
```

### 3. Запуск

```bash
# Терминал 1 - Backend
cd backend
npm run dev

# Терминал 2 - Frontend
cd frontend
npm run dev
```

### 4. Откройте браузер

Перейдите на `http://localhost:5173`

## 🔧 Конфигурация

### Backend (.env)

```env
# AI Configuration
AI_USE_MOCK=true                    # false для реального AI
OPENAI_API_KEY=your_key_here        # Опционально
STABLE_DIFFUSION_API_KEY=your_key   # Опционально

# Server
PORT=3001
DB_PATH=data/projects.json
NODE_ENV=development
```

### Frontend (.env)

```env
VITE_API_URL=http://localhost:3001/api
```

## 📊 Структура проекта

```
constructor/
├── backend/
│   ├── src/
│   │   ├── index.ts              # Express сервер
│   │   ├── config/               # Конфигурация
│   │   ├── services/              # Бизнес-логика
│   │   ├── validation/           # Валидация (Zod)
│   │   └── middleware/           # Middleware
│   ├── data/                     # JSON база данных
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── App.tsx               # Главный компонент
│   │   ├── components/           # React компоненты
│   │   ├── services/             # API клиент
│   │   ├── utils/                # Утилиты
│   │   └── constants/            # Константы
│   └── package.json
│
├── docs/                         # Документация
├── README.md                     # Основная документация
├── CHANGELOG.md                  # История изменений
└── .gitignore                    # Git ignore
```

## 🎯 Основные функции

### ✅ Реализовано

- **Создание брендов** через Wizard
- **Редактор сайтов** с Drag-and-Drop
- **Редактор графики** для соцсетей
- **Генератор презентаций**
- **AI-генерация контента** (OpenAI)
- **Перевод контента** (AI)
- **Экспорт в HTML**
- **Предпросмотр сайтов**
- **Управление тарифами**
- **Аналитика**
- **Командная работа**

### 📋 Типы блоков (12)

1. Hero - Главный экран
2. Features - Особенности
3. Gallery - Галерея
4. Text - Текстовый блок
5. Pricing - Тарифы
6. Testimonials - Отзывы
7. FAQ - Часто задаваемые вопросы
8. Contact - Форма обратной связи
9. Newsletter - Подписка на рассылку
10. CTA - Призыв к действию
11. Stats - Статистика
12. Footer - Подвал

### 🌐 Платформы для соцсетей (6)

- Instagram
- VK
- Telegram
- YouTube
- Facebook
- Twitter

## 🔐 Безопасность

### Рекомендации для продакшена

1. **База данных**: Замените JSON на PostgreSQL
2. **Аутентификация**: Добавьте JWT токены
3. **Rate Limiting**: Ограничьте количество запросов
4. **CORS**: Настройте для конкретных доменов
5. **HTTPS**: Используйте SSL сертификаты
6. **Мониторинг**: Настройте Sentry или аналоги
7. **Логирование**: Используйте Winston или Pino

## 📈 Производительность

### Оптимизации

- Используйте Redis для кеширования
- Настройте CDN для статических файлов
- Оптимизируйте изображения
- Используйте lazy loading для компонентов
- Настройте compression middleware

## 🐛 Отладка

### Логи

- **Backend**: Логи выводятся в консоль
- **Frontend**: Используйте DevTools (F12)

### Частые проблемы

1. **Белый экран**: Проверьте консоль браузера
2. **Ошибки API**: Проверьте логи backend
3. **Не сохраняются данные**: Проверьте права на запись в `backend/data/`

## 📦 Production Build

### Backend

```bash
cd backend
npm run build
npm start
```

### Frontend

```bash
cd frontend
npm run build
# Разместите dist/ на статическом хостинге (Nginx, Vercel, Netlify)
```

## 🚀 Деплой

### Варианты хостинга

1. **Vercel/Netlify** - для frontend
2. **Railway/Render** - для backend
3. **DigitalOcean/AWS** - для полного контроля
4. **Docker** - для контейнеризации

### Docker (опционально)

```dockerfile
# Пример Dockerfile для backend
FROM node:18
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
CMD ["npm", "start"]
```

## 📞 Поддержка

При возникновении проблем:

1. Проверьте консоль браузера (F12)
2. Проверьте логи backend сервера
3. Убедитесь, что все зависимости установлены
4. Проверьте .env файлы
5. Проверьте версию Node.js (требуется 18+)

## 📚 Дополнительная документация

- `README.md` - Основная документация
- `docs/API.md` - API документация
- `CHANGELOG.md` - История изменений

## 🎉 Готово!

Платформа готова к использованию. Удачной работы! 🚀

