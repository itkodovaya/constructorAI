# Troubleshooting Guide

## 🔍 Диагностика проблем

### Проблема: Белый экран в браузере

**Симптомы:**
- Браузер показывает только белый экран
- Нет ошибок в консоли (или есть)

**Решение:**

1. **Проверьте консоль браузера (F12)**
   ```javascript
   // Ищите ошибки типа:
   // - Failed to fetch
   // - Module not found
   // - SyntaxError
   ```

2. **Проверьте, что backend запущен**
   ```bash
   curl http://localhost:3001/health
   # Должен вернуть: {"status":"ok",...}
   ```

3. **Проверьте .env файлы**
   ```bash
   # frontend/.env должен содержать:
   VITE_API_URL=http://localhost:3001/api
   ```

4. **Очистите кеш браузера**
   - Ctrl+Shift+Delete
   - Или Hard Refresh: Ctrl+F5

5. **Перезапустите dev серверы**
   ```bash
   # Остановите (Ctrl+C) и запустите заново
   npm run dev
   ```

---

### Проблема: "Failed to fetch projects"

**Симптомы:**
- Ошибка при загрузке списка проектов
- Пустой дашборд

**Решение:**

1. **Проверьте backend сервер**
   ```bash
   # Backend должен быть запущен
   cd backend
   npm run dev
   ```

2. **Проверьте CORS настройки**
   ```typescript
   // backend/src/index.ts
   app.use(cors()); // Должно быть включено
   ```

3. **Проверьте путь к API**
   ```bash
   # Проверьте, что frontend/.env содержит:
   VITE_API_URL=http://localhost:3001/api
   ```

4. **Проверьте логи backend**
   ```bash
   # Ищите ошибки в консоли backend
   ```

---

### Проблема: Данные не сохраняются

**Симптомы:**
- Изменения не сохраняются после перезагрузки
- Ошибки при сохранении

**Решение:**

1. **Проверьте права на запись**
   ```bash
   # Windows
   icacls backend\data /grant Users:F
   
   # Linux/Mac
   chmod -R 755 backend/data
   ```

2. **Проверьте, что директория существует**
   ```bash
   mkdir -p backend/data
   ```

3. **Проверьте логи на ошибки**
   ```bash
   # Смотрите консоль backend на ошибки записи
   ```

4. **Проверьте формат JSON**
   ```bash
   # Если projects.json поврежден, удалите его
   # Он создастся автоматически при следующем запуске
   ```

---

### Проблема: Docker контейнер не запускается

**Симптомы:**
- `docker-compose up` падает с ошибкой
- Контейнеры не стартуют

**Решение:**

1. **Проверьте логи**
   ```bash
   docker-compose logs
   docker-compose logs backend
   docker-compose logs frontend
   ```

2. **Проверьте порты**
   ```bash
   # Убедитесь, что порты 3001 и 5173 свободны
   netstat -ano | findstr :3001
   netstat -ano | findstr :5173
   ```

3. **Пересоберите образы**
   ```bash
   docker-compose down
   docker-compose build --no-cache
   docker-compose up
   ```

4. **Проверьте .env файлы**
   ```bash
   # Убедитесь, что .env файлы существуют
   ls backend/.env
   ls frontend/.env
   ```

---

### Проблема: AI функции не работают

**Симптомы:**
- Генерация контента не работает
- Переводчик не работает

**Решение:**

1. **Проверьте режим AI**
   ```bash
   # backend/.env
   AI_USE_MOCK=true  # Для заглушек (по умолчанию)
   AI_USE_MOCK=false # Для реального AI
   ```

2. **Если используете реальный AI:**
   ```bash
   # Проверьте API ключи
   OPENAI_API_KEY=your_key_here
   STABLE_DIFFUSION_API_KEY=your_key_here
   ```

3. **Проверьте логи**
   ```bash
   # Ищите ошибки API в логах backend
   ```

---

### Проблема: Медленная работа

**Симптомы:**
- Приложение тормозит
- Долгая загрузка страниц

**Решение:**

1. **Проверьте использование памяти**
   ```bash
   # Windows
   tasklist | findstr node
   
   # Linux/Mac
   ps aux | grep node
   ```

2. **Оптимизируйте сборку**
   ```bash
   npm run build
   # Используйте production build
   ```

3. **Проверьте количество проектов**
   ```bash
   # Если projects.json очень большой, рассмотрите миграцию на БД
   ```

4. **Включите кеширование**
   ```nginx
   # В nginx.conf
   location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
       expires 1y;
   }
   ```

---

### Проблема: Ошибки компиляции TypeScript

**Симптомы:**
- Ошибки типов при сборке
- `tsc` не проходит

**Решение:**

1. **Обновите зависимости**
   ```bash
   npm install
   ```

2. **Проверьте версию TypeScript**
   ```bash
   npx tsc --version
   # Должна быть 5.4+
   ```

3. **Очистите кеш**
   ```bash
   rm -rf node_modules
   rm -rf dist
   npm install
   ```

---

### Проблема: Порт уже занят

**Симптомы:**
- `EADDRINUSE: address already in use`
- Сервер не запускается

**Решение:**

1. **Найдите процесс на порту**
   ```bash
   # Windows
   netstat -ano | findstr :3001
   taskkill /PID <PID> /F
   
   # Linux/Mac
   lsof -ti:3001 | xargs kill -9
   ```

2. **Или измените порт**
   ```bash
   # backend/.env
   PORT=3002
   ```

---

## 🆘 Если ничего не помогло

1. **Соберите информацию:**
   - Версия Node.js: `node --version`
   - Версия npm: `npm --version`
   - ОС и версия
   - Полный текст ошибки
   - Логи backend и frontend

2. **Попробуйте чистая установка:**
   ```bash
   rm -rf node_modules
   rm -rf backend/node_modules
   rm -rf frontend/node_modules
   npm install
   cd backend && npm install
   cd ../frontend && npm install
   ```

3. **Создайте Issue на GitHub** с собранной информацией

