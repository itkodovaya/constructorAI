# Constructor AI Platform - Документация

## 📚 Содержание

1. [Быстрый старт](#быстрый-старт)
2. [Конфигурация](#конфигурация)
3. [API Документация](#api-документация)
4. [Архитектура](#архитектура)
5. [Разработка](#разработка)

## 🚀 Быстрый старт

### Установка

```bash
# Backend
cd backend
npm install
npm run dev

# Frontend (в другом терминале)
cd frontend
npm install
npm run dev
```

### Первый запуск

1. Откройте `http://localhost:5173`
2. Пройдите Wizard для создания первого проекта
3. Начните редактировать свой бренд!

## ⚙️ Конфигурация

### Backend (.env)

Скопируйте `backend/.env.example` в `backend/.env`:

```env
# AI Configuration
AI_USE_MOCK=true  # false для реального AI
OPENAI_API_KEY=your_key_here
STABLE_DIFFUSION_API_KEY=your_key_here

# Server
PORT=3001
DB_PATH=data/projects.json
```

### Frontend (.env)

Скопируйте `frontend/.env.example` в `frontend/.env`:

```env
VITE_API_URL=http://localhost:3001/api
```

## 📡 API Документация

### Проекты

- `GET /api/projects` - Получить все проекты
- `GET /api/projects/:id` - Получить проект
- `POST /api/projects` - Создать проект (требует валидации)
- `PUT /api/projects/:id` - Обновить проект
- `DELETE /api/projects/:id` - Удалить проект

### AI Функции

- `POST /api/projects/:id/translate` - Перевести проект
- `POST /api/projects/:id/generate-content` - Сгенерировать контент
- `GET /api/projects/:id/preview` - Предпросмотр HTML

### Экспорт

- `POST /api/projects/:id/export` - Экспорт в HTML
- `POST /api/projects/:id/export-presentation` - Экспорт презентации (заглушка)
- `POST /api/projects/:id/export-brandkit` - Экспорт бренд-кита (заглушка)

## 🏗️ Архитектура

### Backend

```
backend/
├── src/
│   ├── index.ts              # Express сервер
│   ├── config/               # Конфигурация
│   ├── services/             # Бизнес-логика
│   ├── validation/           # Валидация данных
│   └── middleware/           # Middleware
└── data/                     # JSON база данных
```

### Frontend

```
frontend/
├── src/
│   ├── App.tsx               # Главный компонент
│   ├── components/           # React компоненты
│   ├── services/             # API клиент
│   └── utils/                # Утилиты
```

## 💻 Разработка

### Валидация данных

Все данные валидируются через Zod схемы:

```typescript
import { CreateProjectSchema, validateProject } from './validation/project.validation';

const validation = validateProject(data, CreateProjectSchema);
if (!validation.success) {
  return { error: validation.errors };
}
```

### Обработка ошибок

Backend автоматически обрабатывает ошибки через middleware:

```typescript
app.use(ErrorHandler.handle);
```

Frontend использует axios interceptors для автоматической обработки.

### AI Интеграция

По умолчанию используются заглушки. Для реального AI:

1. Получите API ключи (OpenAI, Stable Diffusion)
2. Добавьте в `.env`
3. Установите `AI_USE_MOCK=false`

## 📝 Типы данных

### Project

```typescript
interface Project {
  id: string;
  userId?: string;
  brandName: string;
  niche: string;
  style: string;
  colors: string[];
  goals: string[];
  brandAssets: {
    logo?: string;
    palette?: string[];
    fonts?: string[];
  };
  pages: any[];
  presentation?: any[];
  collaborators?: { userId: string; role: 'viewer' | 'editor' | 'owner' }[];
}
```

## 🎯 Тарифы

- **Free**: 1 проект, 10 AI генераций, 5 экспортов
- **Pro**: Безлимит проектов, безлимит AI, безлимит экспортов, 5 участников команды
- **Brand Kit**: Все функции Pro + пожизненный доступ

## 🔒 Безопасность

- Валидация всех входных данных
- Защита от XSS (escapeHtml в экспорте)
- CORS настроен для разработки
- API ключи хранятся в .env (не коммитятся)

## 📦 Развертывание

### Production Build

```bash
# Backend
cd backend
npm run build
npm start

# Frontend
cd frontend
npm run build
# Разместите dist/ на статическом хостинге
```

### Рекомендации

- Используйте PostgreSQL вместо JSON для продакшена
- Настройте Redis для кеширования
- Добавьте rate limiting
- Настройте мониторинг (Sentry, LogRocket)

## 🐛 Отладка

### Логи

Backend логи выводятся в консоль. Для продакшена используйте Winston или Pino.

### Ошибки

Все ошибки логируются с полным стеком в development режиме.

## 📞 Поддержка

При возникновении проблем:

1. Проверьте консоль браузера (F12)
2. Проверьте логи backend сервера
3. Убедитесь, что все зависимости установлены
4. Проверьте .env файлы

