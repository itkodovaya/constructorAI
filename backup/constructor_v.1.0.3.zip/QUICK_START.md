# Quick Start Guide

## 🚀 Быстрый старт Constructor AI Platform

### Вариант 1: Автоматическая установка (Рекомендуется)

```bash
npm run setup
```

Этот скрипт автоматически:
- Проверит наличие Node.js и npm
- Установит все зависимости
- Создаст необходимые .env файлы
- Создаст необходимые директории

### Вариант 2: Ручная установка

#### 1. Установка зависимостей

```bash
npm install
cd backend && npm install
cd ../frontend && npm install
```

#### 2. Настройка переменных окружения

Создайте `backend/.env` и `frontend/.env` (см. README.md)

#### 3. Запуск

```bash
npm run dev
```

### Проверка работоспособности

- Health Check: `http://localhost:3001/health`
- Метрики: `http://localhost:3001/api/metrics`
- Frontend: `http://localhost:5173`

### Полезные команды

- `npm run setup` - Полная установка
- `npm run dev` - Запуск разработки
- `npm run test` - Тесты
- `npm run build` - Сборка

Подробнее см. README.md

