# Testing Guide

## 🧪 Тестирование в Constructor AI Platform

### Структура тестов

```
backend/
├── src/
│   ├── services/
│   │   ├── projects.service.ts
│   │   └── __tests__/
│   │       └── projects.service.test.ts
│   └── ...
└── jest.config.js
```

### Запуск тестов

```bash
# Все тесты
cd backend && npm test

# В режиме watch
npm run test:watch

# С покрытием кода
npm run test:coverage
```

### Типы тестов

#### Unit тесты
- Тестирование отдельных сервисов и функций
- Быстрые и изолированные
- Примеры: `projects.service.test.ts`, `user.service.test.ts`

#### Integration тесты
- Тестирование взаимодействия между компонентами
- Тестирование API эндпоинтов
- Примеры: `api.integration.test.ts`

### Примеры тестов

#### Тест сервиса

```typescript
describe('ProjectsService', () => {
  it('should create a new project', async () => {
    const project = await ProjectsService.create({
      brandName: 'Test',
      niche: 'tech'
    });
    
    expect(project).toBeDefined();
    expect(project.brandName).toBe('Test');
  });
});
```

### Покрытие кода

Целевое покрытие: **80%+**

```bash
npm run test:coverage
```

Отчет будет доступен в `backend/coverage/index.html`

### Best Practices

1. **Изоляция тестов** - каждый тест должен быть независимым
2. **Очистка данных** - используйте `beforeEach` для очистки
3. **Моки** - используйте моки для внешних зависимостей
4. **Именование** - используйте описательные имена тестов
5. **AAA паттерн** - Arrange, Act, Assert

### CI/CD интеграция

Тесты автоматически запускаются в GitHub Actions при каждом push.

