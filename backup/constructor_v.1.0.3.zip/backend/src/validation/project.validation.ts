/**
 * Валидация данных проекта с помощью Zod
 */

import { z } from 'zod';

// Схема для создания проекта (Onboarding)
export const CreateProjectSchema = z.object({
  brandName: z.string().min(2, 'Название бренда должно быть не менее 2 символов').max(100),
  niche: z.string().min(1, 'Ниша обязательна'),
  style: z.enum(['minimalist', 'modern', 'classic', 'creative', 'corporate']),
  colors: z.array(z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'Цвет должен быть в формате HEX')).max(10),
  goals: z.array(z.string()).max(10),
});

// Схема для обновления проекта
export const UpdateProjectSchema = z.object({
  brandName: z.string().min(2).max(100).optional(),
  niche: z.string().min(1).optional(),
  style: z.enum(['minimalist', 'modern', 'classic', 'creative', 'corporate']).optional(),
  colors: z.array(z.string().regex(/^#[0-9A-Fa-f]{6}$/)).max(10).optional(),
  goals: z.array(z.string()).max(10).optional(),
  brandAssets: z.object({
    logo: z.string().url().optional(),
    palette: z.array(z.string().regex(/^#[0-9A-Fa-f]{6}$/)).optional(),
    fonts: z.array(z.string()).optional(),
  }).optional(),
  seo: z.object({
    title: z.string().max(60).optional(),
    description: z.string().max(160).optional(),
    keywords: z.string().max(200).optional(),
    ogImage: z.string().url().optional(),
  }).optional(),
  pages: z.array(z.any()).optional(),
  presentation: z.array(z.any()).optional(),
}).partial();

// Схема для блока сайта
export const BlockSchema = z.object({
  id: z.string(),
  type: z.enum(['hero', 'features', 'gallery', 'text', 'footer', 'pricing', 'testimonials', 'faq']),
  content: z.any(),
  style: z.any().optional(),
});

// Схема для SEO данных
export const SEOSchema = z.object({
  title: z.string().max(60, 'Title должен быть не более 60 символов'),
  description: z.string().max(160, 'Description должен быть не более 160 символов'),
  keywords: z.string().max(200).optional(),
  ogImage: z.string().url('OG Image должен быть валидным URL').optional(),
});

// Валидация с обработкой ошибок
export function validateProject(data: any, schema: z.ZodSchema) {
  try {
    return { success: true, data: schema.parse(data) };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        errors: error.errors.map(err => ({
          path: err.path.join('.'),
          message: err.message,
        })),
      };
    }
    return {
      success: false,
      errors: [{ path: 'unknown', message: 'Ошибка валидации' }],
    };
  }
}

