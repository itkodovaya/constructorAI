import fs from 'fs/promises';
import path from 'path';
import { BrandService } from './brand.service';
import { LayoutService } from './layout.service';
import { PresentationService } from './presentation.service';

// Унифицированный путь к БД: backend/data/projects.json
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'projects.json');

export interface Project {
  id: string;
  userId?: string; // Владелец проекта
  brandName: string;
  niche: string;
  style: string;
  colors: string[];
  goals: string[];
  brandAssets: {
    logo?: string;
    palette?: string[];
    fonts?: string[];
  };
  seo?: {
    title: string;
    description: string;
    keywords: string;
    ogImage?: string;
  };
  integrations?: {
    telegramToken?: string;
    yandexMetricaId?: string;
  };
  pages: any[];
  presentation?: any[];
  history: { id: string; timestamp: string; action: string; assets: any }[];
  createdAt: string;
  updatedAt: string;
  collaborators?: { userId: string; role: 'viewer' | 'editor' | 'owner' }[];
}

export class ProjectsService {
  private static async ensureDb() {
    try {
      // Создаём директорию data, если её нет
      await fs.mkdir(DATA_DIR, { recursive: true });
      await fs.access(DB_PATH);
    } catch {
      await fs.writeFile(DB_PATH, JSON.stringify([], null, 2), 'utf-8');
    }
  }

  static async getAll(): Promise<Project[]> {
    await this.ensureDb();
    const data = await fs.readFile(DB_PATH, 'utf-8');
    return JSON.parse(data);
  }

  static async getById(id: string): Promise<Project | undefined> {
    const projects = await this.getAll();
    return projects.find(p => p.id === id);
  }

  static async create(projectData: Partial<Project>): Promise<Project> {
    const projects = await this.getAll();
    
    const assets = await BrandService.generate(
      projectData.brandName || 'Brand', 
      projectData.style || 'minimalist'
    );

    const blocks = LayoutService.generateDefaultLayout(
      projectData.brandName || 'Brand',
      projectData.niche || 'general'
    );

    const slides = PresentationService.generate(
      projectData.brandName || 'Brand',
      projectData.niche || 'general'
    );

    const newProject: Project = {
      id: Math.random().toString(36).substr(2, 9),
      brandName: projectData.brandName || 'Untitled',
      niche: projectData.niche || '',
      style: projectData.style || 'minimalist',
      colors: projectData.colors || [],
      goals: projectData.goals || [],
      brandAssets: assets,
      seo: {
        title: projectData.brandName || 'Untitled Project',
        description: 'Создано с помощью Constructor AI',
        keywords: 'ai, design, website, brand'
      },
      pages: [
        { id: '1', title: 'Home', blocks: blocks }
      ],
      presentation: slides,
      history: [{
        id: Date.now().toString(),
        timestamp: new Date().toLocaleTimeString(),
        action: 'Создание проекта',
        assets: { ...assets }
      }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    projects.push(newProject);
    await fs.writeFile(DB_PATH, JSON.stringify(projects, null, 2));
    return newProject;
  }

  static async update(id: string, updates: Partial<Project>): Promise<Project | null> {
    const projects = await this.getAll();
    const index = projects.findIndex(p => p.id === id);
    if (index === -1) return null;

    const oldProject = projects[index];
    
    // Если обновляются brandAssets, добавляем запись в историю
    let newHistory = oldProject.history || [];
    if (updates.brandAssets) {
      newHistory = [
        ...newHistory,
        {
          id: Date.now().toString(),
          timestamp: new Date().toLocaleTimeString(),
          action: updates.brandAssets.palette ? 'Обновление палитры' : 'Изменение стиля',
          assets: { ...updates.brandAssets }
        }
      ].slice(-10); // Храним последние 10 версий
    }

    projects[index] = {
      ...oldProject,
      ...updates,
      history: newHistory,
      updatedAt: new Date().toISOString()
    };
    await fs.writeFile(DB_PATH, JSON.stringify(projects, null, 2));
    return projects[index];
  }

  static async delete(id: string): Promise<boolean> {
    const projects = await this.getAll();
    const filtered = projects.filter(p => p.id !== id);
    if (filtered.length === projects.length) return false;
    await fs.writeFile(DB_PATH, JSON.stringify(filtered, null, 2));
    return true;
  }
}

