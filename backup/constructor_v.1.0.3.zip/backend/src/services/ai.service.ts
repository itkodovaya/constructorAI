/**
 * AI Service для работы с внешними AI API
 * Поддерживает OpenAI (GPT) и Stable Diffusion для генерации контента
 */

interface AIConfig {
  openaiApiKey?: string;
  stableDiffusionApiKey?: string;
  useMock: boolean; // Использовать заглушки вместо реальных API
}

export class AIService {
  private static config: AIConfig = {
    useMock: true, // По умолчанию используем заглушки
  };

  static configure(config: Partial<AIConfig>) {
    this.config = { ...this.config, ...config };
  }

  /**
   * Генерация текста через OpenAI GPT
   */
  static async generateText(prompt: string, maxTokens: number = 500): Promise<string> {
    if (this.config.useMock || !this.config.openaiApiKey) {
      return this.mockGenerateText(prompt);
    }

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.openaiApiKey}`,
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            { role: 'system', content: 'Ты профессиональный копирайтер и маркетолог. Создавай качественный контент для брендов.' },
            { role: 'user', content: prompt }
          ],
          max_tokens: maxTokens,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.statusText}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || this.mockGenerateText(prompt);
    } catch (error) {
      console.error('AI generation failed, using mock:', error);
      return this.mockGenerateText(prompt);
    }
  }

  /**
   * Генерация изображения через Stable Diffusion
   */
  static async generateImage(prompt: string, width: number = 512, height: number = 512): Promise<string> {
    if (this.config.useMock || !this.config.stableDiffusionApiKey) {
      return this.mockGenerateImage(prompt);
    }

    try {
      // Пример интеграции с Stable Diffusion API (зависит от конкретного провайдера)
      const response = await fetch('https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.stableDiffusionApiKey}`,
        },
        body: JSON.stringify({
          text_prompts: [{ text: prompt }],
          width,
          height,
          cfg_scale: 7,
          steps: 30,
        }),
      });

      if (!response.ok) {
        throw new Error(`Stable Diffusion API error: ${response.statusText}`);
      }

      const data = await response.json();
      return data.artifacts[0]?.base64 || this.mockGenerateImage(prompt);
    } catch (error) {
      console.error('Image generation failed, using mock:', error);
      return this.mockGenerateImage(prompt);
    }
  }

  /**
   * Перевод текста через AI
   */
  static async translateText(text: string, targetLang: 'ru' | 'en'): Promise<string> {
    if (this.config.useMock || !this.config.openaiApiKey) {
      return this.mockTranslate(text, targetLang);
    }

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.openaiApiKey}`,
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            { role: 'system', content: `Ты профессиональный переводчик. Переведи текст на ${targetLang === 'ru' ? 'русский' : 'английский'} язык, сохраняя стиль и смысл.` },
            { role: 'user', content: text }
          ],
          max_tokens: 1000,
          temperature: 0.3,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.statusText}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || this.mockTranslate(text, targetLang);
    } catch (error) {
      console.error('Translation failed, using mock:', error);
      return this.mockTranslate(text, targetLang);
    }
  }

  /**
   * Генерация контента для бренда (текст + изображение)
   */
  static async generateBrandContent(brandName: string, niche: string, style: string): Promise<{
    description: string;
    slogan: string;
    logoPrompt: string;
  }> {
    const prompt = `Создай описание бренда "${brandName}" в нише "${niche}" со стилем "${style}". Включи краткое описание, слоган и промпт для генерации логотипа.`;

    if (this.config.useMock || !this.config.openaiApiKey) {
      return this.mockGenerateBrandContent(brandName, niche, style);
    }

    try {
      const response = await this.generateText(prompt, 300);
      // Парсинг ответа (в реальности нужен более сложный парсинг)
      return this.parseBrandContent(response, brandName, niche, style);
    } catch (error) {
      console.error('Brand content generation failed, using mock:', error);
      return this.mockGenerateBrandContent(brandName, niche, style);
    }
  }

  // Mock методы (заглушки)
  private static mockGenerateText(prompt: string): string {
    return `[AI Generated] ${prompt.substring(0, 100)}... Это автоматически сгенерированный контент на основе вашего запроса. В реальной версии здесь будет результат работы GPT-4.`;
  }

  private static mockGenerateImage(prompt: string): string {
    // Возвращаем SVG placeholder
    const svg = `
      <svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
        <rect width="512" height="512" fill="#f0f0f0"/>
        <text x="256" y="256" font-family="Arial" font-size="20" fill="#666" text-anchor="middle">
          AI Generated Image
        </text>
        <text x="256" y="280" font-family="Arial" font-size="14" fill="#999" text-anchor="middle">
          ${prompt.substring(0, 30).replace(/[<>]/g, '')}
        </text>
      </svg>
    `;
    // В Node.js используем Buffer
    const Buffer = require('buffer').Buffer;
    return `data:image/svg+xml;base64,${Buffer.from(svg.trim()).toString('base64')}`;
  }

  private static mockTranslate(text: string, targetLang: 'ru' | 'en'): string {
    // Простой словарь для демонстрации
    const dictionary: Record<string, Record<string, string>> = {
      'Welcome': { ru: 'Добро пожаловать', en: 'Welcome' },
      'Hello': { ru: 'Привет', en: 'Hello' },
    };

    if (dictionary[text] && dictionary[text][targetLang]) {
      return dictionary[text][targetLang];
    }

    return targetLang === 'en' ? `[EN] ${text}` : `[RU] ${text}`;
  }

  private static mockGenerateBrandContent(brandName: string, niche: string, style: string): {
    description: string;
    slogan: string;
    logoPrompt: string;
  } {
    return {
      description: `${brandName} - это инновационный бренд в нише ${niche}, сочетающий стиль ${style} с современными технологиями.`,
      slogan: `Создаем будущее вместе с ${brandName}`,
      logoPrompt: `Modern ${style} logo for ${brandName}, ${niche} industry, professional, minimalist`,
    };
  }

  private static parseBrandContent(response: string, brandName: string, niche: string, style: string): {
    description: string;
    slogan: string;
    logoPrompt: string;
  } {
    // Упрощенный парсинг (в реальности нужен более сложный)
    return {
      description: response.substring(0, 200),
      slogan: response.split('\n').find(line => line.includes('слоган')) || `Создаем будущее вместе с ${brandName}`,
      logoPrompt: `Modern ${style} logo for ${brandName}, ${niche} industry`,
    };
  }
}
