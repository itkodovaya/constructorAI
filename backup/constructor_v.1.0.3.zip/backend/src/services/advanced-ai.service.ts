/**
 * Расширенный AI сервис с поддержкой очередей и пакетной обработки
 */

import { AI_CONFIG } from '../config/ai.config';

export interface AIGenerationTask {
  id: string;
  type: 'text' | 'image' | 'translate';
  prompt: string;
  options?: any;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  result?: any;
  error?: string;
  createdAt: Date;
  completedAt?: Date;
}

export class AdvancedAIService {
  private static taskQueue: AIGenerationTask[] = [];
  private static isProcessing = false;
  private static maxConcurrentTasks = 3;

  /**
   * Генерирует текст с использованием AI
   */
  static async generateText(prompt: string, options?: {
    maxTokens?: number;
    temperature?: number;
    model?: string;
  }): Promise<string> {
    if (AI_CONFIG.useMock || !AI_CONFIG.openaiApiKey) {
      // Улучшенные заглушки с более реалистичными ответами
      return this.generateMockText(prompt, options);
    }

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AI_CONFIG.openaiApiKey}`,
        },
        body: JSON.stringify({
          model: options?.model || 'gpt-4',
          messages: [
            { role: 'system', content: 'You are a helpful AI assistant for brand content generation.' },
            { role: 'user', content: prompt }
          ],
          max_tokens: options?.maxTokens || 1000,
          temperature: options?.temperature || 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.statusText}`);
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('OpenAI API error:', error);
      return this.generateMockText(prompt, options);
    }
  }

  /**
   * Генерирует изображение с использованием AI
   */
  static async generateImage(prompt: string, options?: {
    size?: '256x256' | '512x512' | '1024x1024';
    style?: 'vivid' | 'natural';
  }): Promise<string> {
    if (AI_CONFIG.useMock || !AI_CONFIG.openaiApiKey) {
      return this.generateMockImage(prompt);
    }

    try {
      const response = await fetch('https://api.openai.com/v1/images/generations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AI_CONFIG.openaiApiKey}`,
        },
        body: JSON.stringify({
          model: 'dall-e-3',
          prompt: prompt,
          n: 1,
          size: options?.size || '1024x1024',
          style: options?.style || 'natural',
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.statusText}`);
      }

      const data = await response.json();
      return data.data[0].url;
    } catch (error) {
      console.error('OpenAI Image API error:', error);
      return this.generateMockImage(prompt);
    }
  }

  /**
   * Переводит текст с использованием AI
   */
  static async translateText(text: string, targetLang: 'ru' | 'en' | 'uk', sourceLang?: string): Promise<string> {
    if (AI_CONFIG.useMock || !AI_CONFIG.openaiApiKey) {
      return this.generateMockTranslation(text, targetLang);
    }

    try {
      const langNames: Record<string, string> = {
        'ru': 'Russian',
        'en': 'English',
        'uk': 'Ukrainian'
      };

      const prompt = `Translate the following text to ${langNames[targetLang]}. 
      ${sourceLang ? `Source language: ${langNames[sourceLang]}` : 'Detect the source language automatically.'}
      
      Text: "${text}"
      
      Provide only the translation, without any additional text.`;

      const response = await this.generateText(prompt, {
        maxTokens: 500,
        temperature: 0.3
      });

      return response.trim();
    } catch (error) {
      console.error('Translation error:', error);
      return this.generateMockTranslation(text, targetLang);
    }
  }

  /**
   * Генерирует контент для блока сайта
   */
  static async generateBlockContent(blockType: string, context: {
    brandName: string;
    niche: string;
    style?: string;
  }): Promise<any> {
    const prompt = `Generate content for a ${blockType} block on a website for a brand called "${context.brandName}" in the "${context.niche}" niche.
    Style: ${context.style || 'modern and professional'}
    
    Provide a JSON object with appropriate fields for this block type.`;

    const response = await this.generateText(prompt, {
      maxTokens: 800,
      temperature: 0.7
    });

    try {
      // Пытаемся извлечь JSON из ответа
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (error) {
      console.error('Failed to parse AI response as JSON:', error);
    }

    // Fallback на структурированный ответ
    return this.generateFallbackContent(blockType, context);
  }

  /**
   * Генерирует серию постов для соцсетей
   */
  static async generateSocialPosts(count: number, context: {
    brandName: string;
    niche: string;
    platforms: string[];
  }): Promise<Array<{ platform: string; title: string; subtitle?: string; cta?: string }>> {
    const prompt = `Generate ${count} social media posts for a brand called "${context.brandName}" in the "${context.niche}" niche.
    Platforms: ${context.platforms.join(', ')}
    
    Provide a JSON array with objects containing: platform, title, subtitle (optional), cta (optional).
    Make each post unique and engaging.`;

    const response = await this.generateText(prompt, {
      maxTokens: 1500,
      temperature: 0.8
    });

    try {
      const jsonMatch = response.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (error) {
      console.error('Failed to parse AI response as JSON:', error);
    }

    // Fallback
    return Array.from({ length: count }, (_, i) => ({
      platform: context.platforms[i % context.platforms.length],
      title: `Post ${i + 1} for ${context.brandName}`,
      subtitle: `Engaging content about ${context.niche}`,
      cta: 'Learn more'
    }));
  }

  /**
   * Добавляет задачу в очередь
   */
  static async queueTask(task: Omit<AIGenerationTask, 'id' | 'status' | 'createdAt'>): Promise<string> {
    const newTask: AIGenerationTask = {
      ...task,
      id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: 'pending',
      createdAt: new Date()
    };

    this.taskQueue.push(newTask);
    this.processQueue();

    return newTask.id;
  }

  /**
   * Получает статус задачи
   */
  static getTaskStatus(taskId: string): AIGenerationTask | null {
    return this.taskQueue.find(t => t.id === taskId) || null;
  }

  /**
   * Обрабатывает очередь задач
   */
  private static async processQueue() {
    if (this.isProcessing) return;

    const pendingTasks = this.taskQueue.filter(t => t.status === 'pending');
    if (pendingTasks.length === 0) return;

    this.isProcessing = true;

    const tasksToProcess = pendingTasks.slice(0, this.maxConcurrentTasks);
    
    await Promise.all(tasksToProcess.map(task => this.processTask(task)));

    this.isProcessing = false;

    // Продолжаем обработку, если есть еще задачи
    if (this.taskQueue.some(t => t.status === 'pending')) {
      setTimeout(() => this.processQueue(), 100);
    }
  }

  /**
   * Обрабатывает одну задачу
   */
  private static async processTask(task: AIGenerationTask) {
    task.status = 'processing';

    try {
      let result: any;

      switch (task.type) {
        case 'text':
          result = await this.generateText(task.prompt, task.options);
          break;
        case 'image':
          result = await this.generateImage(task.prompt, task.options);
          break;
        case 'translate':
          result = await this.translateText(task.prompt, task.options?.targetLang || 'en');
          break;
        default:
          throw new Error(`Unknown task type: ${task.type}`);
      }

      task.result = result;
      task.status = 'completed';
      task.completedAt = new Date();
    } catch (error: any) {
      task.status = 'failed';
      task.error = error.message;
      task.completedAt = new Date();
    }
  }

  // Mock методы для заглушек
  private static generateMockText(prompt: string, options?: any): string {
    const mockResponses: Record<string, string> = {
      'hero': 'Добро пожаловать в наш бренд! Мы предлагаем инновационные решения для вашего бизнеса.',
      'features': 'Наши преимущества: качество, скорость, надежность и инновации.',
      'testimonials': 'Наши клиенты довольны нашими услугами и рекомендуют нас своим друзьям.',
    };

    for (const key in mockResponses) {
      if (prompt.toLowerCase().includes(key)) {
        return mockResponses[key];
      }
    }

    return `[AI Generated] ${prompt.substring(0, 100)}... This is a mock response. Enable real AI in .env to get actual results.`;
  }

  private static generateMockImage(prompt: string): string {
    // Используем placeholder сервис с описанием
    const encodedPrompt = encodeURIComponent(prompt.substring(0, 50));
    return `https://via.placeholder.com/1024x1024/2563eb/ffffff?text=${encodedPrompt}`;
  }

  private static generateMockTranslation(text: string, targetLang: string): string {
    const prefix = targetLang === 'ru' ? '[RU]' : targetLang === 'en' ? '[EN]' : '[UK]';
    return `${prefix} ${text}`;
  }

  private static generateFallbackContent(blockType: string, context: any): any {
    const fallbacks: Record<string, any> = {
      'hero': {
        title: `Добро пожаловать в ${context.brandName}`,
        subtitle: `Лучшие решения в нише ${context.niche}`
      },
      'features': {
        items: ['Качество', 'Скорость', 'Надежность']
      },
      'testimonials': {
        items: [
          { text: 'Отличный сервис!', author: 'Клиент 1' },
          { text: 'Рекомендую!', author: 'Клиент 2' }
        ]
      }
    };

    return fallbacks[blockType] || { title: 'New Block', content: 'Content here' };
  }
}

