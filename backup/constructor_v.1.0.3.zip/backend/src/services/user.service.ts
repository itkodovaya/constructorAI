/**
 * Сервис для управления пользователями и аутентификацией
 */

import * as crypto from 'crypto';

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  plan: 'free' | 'pro' | 'brandkit';
  createdAt: Date;
  lastLogin?: Date;
  projectsCount: number;
  aiGenerationsUsed: number;
  aiGenerationsLimit: number;
}

export interface UserSession {
  userId: string;
  token: string;
  expiresAt: Date;
}

export class UserService {
  private static users: User[] = [];
  private static sessions: UserSession[] = [];

  /**
   * Создает нового пользователя
   */
  static async createUser(email: string, password: string, name: string): Promise<User> {
    // Проверка существования пользователя
    if (this.users.find(u => u.email === email)) {
      throw new Error('User with this email already exists');
    }

    const passwordHash = this.hashPassword(password);
    const plan = 'free'; // По умолчанию бесплатный план

    const user: User = {
      id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      email,
      passwordHash,
      name,
      plan,
      createdAt: new Date(),
      projectsCount: 0,
      aiGenerationsUsed: 0,
      aiGenerationsLimit: this.getPlanLimits(plan).aiGenerationsLimit
    };

    this.users.push(user);
    return user;
  }

  /**
   * Аутентификация пользователя
   */
  static async authenticate(email: string, password: string): Promise<{ user: User; token: string } | null> {
    const user = this.users.find(u => u.email === email);
    if (!user) return null;

    if (!this.verifyPassword(password, user.passwordHash)) {
      return null;
    }

    // Обновляем время последнего входа
    user.lastLogin = new Date();

    // Создаем сессию
    const token = this.generateToken();
    const session: UserSession = {
      userId: user.id,
      token,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 дней
    };

    this.sessions.push(session);

    return { user: { ...user, passwordHash: '' }, token };
  }

  /**
   * Проверка токена и получение пользователя
   */
  static async getUserByToken(token: string): Promise<User | null> {
    const session = this.sessions.find(s => s.token === token && s.expiresAt > new Date());
    if (!session) return null;

    const user = this.users.find(u => u.id === session.userId);
    if (!user) return null;

    return { ...user, passwordHash: '' };
  }

  /**
   * Обновление плана пользователя
   */
  static async updatePlan(userId: string, plan: 'free' | 'pro' | 'brandkit'): Promise<User> {
    const user = this.users.find(u => u.id === userId);
    if (!user) throw new Error('User not found');

    user.plan = plan;
    user.aiGenerationsLimit = this.getPlanLimits(plan).aiGenerationsLimit;

    return { ...user, passwordHash: '' };
  }

  /**
   * Проверка лимитов пользователя
   */
  static checkLimits(userId: string, action: 'project' | 'ai_generation'): boolean {
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;

    const limits = this.getPlanLimits(user.plan);

    switch (action) {
      case 'project':
        return user.projectsCount < limits.projectsLimit;
      case 'ai_generation':
        return user.aiGenerationsUsed < user.aiGenerationsLimit;
      default:
        return false;
    }
  }

  /**
   * Увеличение счетчика использований
   */
  static async incrementUsage(userId: string, action: 'project' | 'ai_generation'): Promise<void> {
    const user = this.users.find(u => u.id === userId);
    if (!user) return;

    switch (action) {
      case 'project':
        user.projectsCount++;
        break;
      case 'ai_generation':
        user.aiGenerationsUsed++;
        break;
    }
  }

  /**
   * Получение лимитов плана
   */
  static getPlanLimits(plan: 'free' | 'pro' | 'brandkit'): {
    projectsLimit: number;
    aiGenerationsLimit: number;
    features: string[];
  } {
    const limits = {
      free: {
        projectsLimit: 3,
        aiGenerationsLimit: 10,
        features: ['Базовые блоки', 'Экспорт HTML', 'Предпросмотр']
      },
      pro: {
        projectsLimit: 50,
        aiGenerationsLimit: 500,
        features: ['Все блоки', 'AI генерация', 'Экспорт PDF/ZIP', 'Приоритетная поддержка']
      },
      brandkit: {
        projectsLimit: -1, // Безлимит
        aiGenerationsLimit: -1, // Безлимит
        features: ['Все функции Pro', 'Безлимит проектов', 'Безлимит AI', 'Персональный менеджер']
      }
    };

    return limits[plan];
  }

  /**
   * Хеширование пароля
   */
  private static hashPassword(password: string): string {
    // В production используйте bcrypt или argon2
    const hash = crypto.createHash('sha256');
    hash.update(password + 'constructor_salt_2024'); // В production используйте случайную соль
    return hash.digest('hex');
  }

  /**
   * Проверка пароля
   */
  private static verifyPassword(password: string, hash: string): boolean {
    const passwordHash = this.hashPassword(password);
    return passwordHash === hash;
  }

  /**
   * Генерация токена
   */
  private static generateToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * Получение всех пользователей (для админки)
   */
  static getAllUsers(): User[] {
    return this.users.map(u => ({ ...u, passwordHash: '' }));
  }

  /**
   * Получение пользователя по ID
   */
  static getUserById(userId: string): User | null {
    const user = this.users.find(u => u.id === userId);
    if (!user) return null;
    return { ...user, passwordHash: '' };
  }
}
