/**
 * Сервис для управления ролями и совместной работой над проектами
 */

export type ProjectRole = 'owner' | 'editor' | 'viewer';

export interface ProjectCollaborator {
  userId: string;
  email: string;
  name: string;
  role: ProjectRole;
  invitedAt: Date;
  joinedAt?: Date;
}

export interface ProjectInvitation {
  id: string;
  projectId: string;
  email: string;
  role: ProjectRole;
  invitedBy: string;
  createdAt: Date;
  expiresAt: Date;
  accepted: boolean;
}

export class CollaborationService {
  private static invitations: ProjectInvitation[] = [];
  private static collaborators: Map<string, ProjectCollaborator[]> = new Map();

  /**
   * Создает приглашение в проект
   */
  static async createInvitation(
    projectId: string,
    email: string,
    role: ProjectRole,
    invitedBy: string
  ): Promise<ProjectInvitation> {
    // Проверка, что роль валидна
    if (!['owner', 'editor', 'viewer'].includes(role)) {
      throw new Error('Invalid role');
    }

    // Проверка, что пользователь не является владельцем (владелец не может быть приглашен)
    // В реальности здесь была бы проверка через UserService

    const invitation: ProjectInvitation = {
      id: `inv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      projectId,
      email,
      role,
      invitedBy,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 дней
      accepted: false
    };

    this.invitations.push(invitation);
    return invitation;
  }

  /**
   * Принимает приглашение
   */
  static async acceptInvitation(
    invitationId: string,
    userId: string,
    userEmail: string,
    userName: string
  ): Promise<ProjectCollaborator> {
    const invitation = this.invitations.find(inv => inv.id === invitationId);
    
    if (!invitation) {
      throw new Error('Invitation not found');
    }

    if (invitation.accepted) {
      throw new Error('Invitation already accepted');
    }

    if (invitation.expiresAt < new Date()) {
      throw new Error('Invitation expired');
    }

    if (invitation.email !== userEmail) {
      throw new Error('Email mismatch');
    }

    // Создаем коллаборатора
    const collaborator: ProjectCollaborator = {
      userId,
      email: userEmail,
      name: userName,
      role: invitation.role,
      invitedAt: invitation.createdAt,
      joinedAt: new Date()
    };

    // Добавляем в список коллабораторов проекта
    const projectCollaborators = this.collaborators.get(invitation.projectId) || [];
    projectCollaborators.push(collaborator);
    this.collaborators.set(invitation.projectId, projectCollaborators);

    // Отмечаем приглашение как принятое
    invitation.accepted = true;

    return collaborator;
  }

  /**
   * Получает список коллабораторов проекта
   */
  static getProjectCollaborators(projectId: string): ProjectCollaborator[] {
    return this.collaborators.get(projectId) || [];
  }

  /**
   * Получает список приглашений проекта
   */
  static getProjectInvitations(projectId: string): ProjectInvitation[] {
    return this.invitations.filter(inv => inv.projectId === projectId);
  }

  /**
   * Удаляет коллаборатора из проекта
   */
  static async removeCollaborator(
    projectId: string,
    userId: string,
    removedBy: string
  ): Promise<boolean> {
    const collaborators = this.collaborators.get(projectId) || [];
    const index = collaborators.findIndex(c => c.userId === userId);
    
    if (index === -1) {
      return false;
    }

    // В реальности здесь была бы проверка прав (только owner может удалять)
    collaborators.splice(index, 1);
    this.collaborators.set(projectId, collaborators);

    return true;
  }

  /**
   * Обновляет роль коллаборатора
   */
  static async updateCollaboratorRole(
    projectId: string,
    userId: string,
    newRole: ProjectRole,
    updatedBy: string
  ): Promise<ProjectCollaborator | null> {
    const collaborators = this.collaborators.get(projectId) || [];
    const collaborator = collaborators.find(c => c.userId === userId);
    
    if (!collaborator) {
      return null;
    }

    // В реальности здесь была бы проверка прав (только owner может менять роли)
    collaborator.role = newRole;

    return collaborator;
  }

  /**
   * Проверяет права доступа пользователя к проекту
   */
  static checkAccess(
    projectId: string,
    userId: string,
    requiredRole?: ProjectRole
  ): boolean {
    const collaborators = this.collaborators.get(projectId) || [];
    const collaborator = collaborators.find(c => c.userId === userId);
    
    if (!collaborator) {
      return false; // Пользователь не является коллаборатором
    }

    if (!requiredRole) {
      return true; // Доступ есть, роль не важна
    }

    // Иерархия ролей: owner > editor > viewer
    const roleHierarchy: Record<ProjectRole, number> = {
      owner: 3,
      editor: 2,
      viewer: 1
    };

    return roleHierarchy[collaborator.role] >= roleHierarchy[requiredRole];
  }

  /**
   * Получает роль пользователя в проекте
   */
  static getUserRole(projectId: string, userId: string): ProjectRole | null {
    const collaborators = this.collaborators.get(projectId) || [];
    const collaborator = collaborators.find(c => c.userId === userId);
    return collaborator?.role || null;
  }

  /**
   * Отменяет приглашение
   */
  static async cancelInvitation(invitationId: string, cancelledBy: string): Promise<boolean> {
    const index = this.invitations.findIndex(inv => inv.id === invitationId);
    
    if (index === -1) {
      return false;
    }

    // В реальности здесь была бы проверка прав
    this.invitations.splice(index, 1);
    return true;
  }
}

