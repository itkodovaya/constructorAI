export class ExportService {
  static generateHTML(brandName: string, assets: any, blocks: any[], seo?: any, lang: string = 'ru'): string {
    const palette = assets.palette || ['#2563eb', '#1e40af'];
    const font = assets.fonts?.[0] || 'Inter';
    
    // SEO мета-теги
    const seoTitle = seo?.title || seo?.ogTitle || brandName;
    const seoDescription = seo?.description || seo?.ogDescription || `Сайт ${brandName}`;
    const seoImage = seo?.ogImage || seo?.image || assets.logoUrl || '';
    const seoKeywords = seo?.keywords || '';

    const blocksHTML = blocks.map(block => {
      switch (block.type) {
        case 'hero':
          return `
            <section class="py-20 px-8 text-center bg-white">
              <div class="max-w-4xl mx-auto">
                <h1 class="text-6xl font-black mb-6" style="color: ${palette[1]}">${this.escapeHtml(block.content.title || '')}</h1>
                <p class="text-xl text-gray-600 mb-10">${this.escapeHtml(block.content.subtitle || '')}</p>
                <button class="px-10 py-4 text-white font-bold rounded-xl shadow-lg" style="background-color: ${palette[0]}">
                  ${this.escapeHtml(block.content.buttonText || 'Get Started')}
                </button>
              </div>
            </section>
          `;
        case 'features':
          const items = Array.isArray(block.content.items) 
            ? block.content.items.map((item: any) => {
                const itemTitle = typeof item === 'string' ? item : (item.title || item);
                const itemDesc = typeof item === 'object' ? (item.description || '') : '';
                return `
                  <div class="p-8 bg-gray-50 rounded-3xl text-center">
                    <h3 class="text-xl font-bold mb-4">${this.escapeHtml(itemTitle)}</h3>
                    ${itemDesc ? `<p class="text-gray-500">${this.escapeHtml(itemDesc)}</p>` : ''}
                  </div>
                `;
              }).join('')
            : '';
          return `<section class="py-20 px-8 bg-gray-50"><div class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">${items}</div></section>`;
        case 'text':
          return `
            <section class="py-16 px-8 bg-white">
              <div class="max-w-4xl mx-auto">
                <h2 class="text-4xl font-bold mb-6" style="color: ${palette[1]}">${this.escapeHtml(block.content.title || '')}</h2>
                <p class="text-lg text-gray-600 leading-relaxed">${this.escapeHtml(block.content.text || '')}</p>
              </div>
            </section>
          `;
        case 'pricing':
          const plans = Array.isArray(block.content.plans) ? block.content.plans : [];
          const plansHTML = plans.map((plan: any) => `
            <div class="p-8 rounded-3xl border-2 ${plan.popular ? 'border-blue-500 bg-blue-50' : 'border-gray-100'}">
              <h3 class="text-xl font-bold mb-2">${this.escapeHtml(plan.name || '')}</h3>
              <div class="text-4xl font-black mb-6">$${this.escapeHtml(plan.price || '0')}<span class="text-sm font-bold text-gray-400">/мес</span></div>
              <ul class="space-y-3 mb-8">
                ${Array.isArray(plan.features) ? plan.features.map((f: string) => `
                  <li class="flex items-center gap-2 text-sm text-gray-600">
                    <div class="w-1.5 h-1.5 bg-blue-500 rounded-full"></div> ${this.escapeHtml(f)}
                  </li>
                `).join('') : ''}
              </ul>
              <button class="w-full py-3 rounded-xl font-bold ${plan.popular ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'}">
                Выбрать план
              </button>
            </div>
          `).join('');
          return `
            <section class="py-20 px-8 bg-white">
              <div class="max-w-6xl mx-auto">
                <h2 class="text-4xl font-bold text-center mb-12" style="color: ${palette[1]}">${this.escapeHtml(block.content.title || 'Тарифные планы')}</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">${plansHTML}</div>
              </div>
            </section>
          `;
        case 'gallery':
          const images = Array.isArray(block.content.images) ? block.content.images : [];
          const galleryHTML = images.map((img: string, i: number) => `
            <div class="aspect-square bg-gray-100 rounded-xl overflow-hidden">
              <img src="${this.escapeHtml(img)}" alt="Gallery ${i + 1}" class="w-full h-full object-cover" />
            </div>
          `).join('');
          return `
            <section class="py-20 px-8 bg-gray-50">
              <div class="max-w-6xl mx-auto">
                <h2 class="text-4xl font-bold text-center mb-12" style="color: ${palette[1]}">${this.escapeHtml(block.content.title || 'Галерея')}</h2>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">${galleryHTML}</div>
              </div>
            </section>
          `;
        case 'faq':
          const faqs = Array.isArray(block.content.items) ? block.content.items : [];
          const faqHTML = faqs.map((faq: any) => `
            <div class="p-6 bg-white rounded-xl border border-gray-100 mb-4">
              <h3 class="text-lg font-bold mb-2">${this.escapeHtml(faq.question || faq.q || '')}</h3>
              <p class="text-gray-600">${this.escapeHtml(faq.answer || faq.a || '')}</p>
            </div>
          `).join('');
          return `
            <section class="py-20 px-8 bg-white">
              <div class="max-w-4xl mx-auto">
                <h2 class="text-4xl font-bold text-center mb-12" style="color: ${palette[1]}">${this.escapeHtml(block.content.title || 'Часто задаваемые вопросы')}</h2>
                ${faqHTML}
              </div>
            </section>
          `;
        case 'testimonials':
          const testimonials = Array.isArray(block.content.items) ? block.content.items : [];
          const testimonialsHTML = testimonials.map((test: any) => `
            <div class="p-8 bg-gray-50 rounded-3xl">
              <p class="text-gray-600 mb-4 italic">"${this.escapeHtml(test.text || test.content || '')}"</p>
              <div class="flex items-center gap-3">
                <div class="w-12 h-12 bg-gray-200 rounded-full"></div>
                <div>
                  <div class="font-bold">${this.escapeHtml(test.author || test.name || '')}</div>
                  <div class="text-sm text-gray-500">${this.escapeHtml(test.role || '')}</div>
                </div>
              </div>
            </div>
          `).join('');
          return `
            <section class="py-20 px-8 bg-white">
              <div class="max-w-6xl mx-auto">
                <h2 class="text-4xl font-bold text-center mb-12" style="color: ${palette[1]}">${this.escapeHtml(block.content.title || 'Отзывы')}</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">${testimonialsHTML}</div>
              </div>
            </section>
          `;
        case 'footer':
          return `
            <footer class="py-12 px-8 bg-white border-t border-gray-100 text-center">
              <p class="text-gray-400 font-medium">${this.escapeHtml(block.content.text || '')}</p>
            </footer>
          `;
        default:
          return '';
      }
    }).join('');

    // Генерируем SEO мета-теги
    const metaTags = `
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${this.escapeHtml(seoTitle)}</title>
    <meta name="description" content="${this.escapeHtml(seoDescription)}">
    ${seoKeywords ? `<meta name="keywords" content="${this.escapeHtml(seoKeywords)}">` : ''}
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="${this.escapeHtml(seoTitle)}">
    <meta property="og:description" content="${this.escapeHtml(seoDescription)}">
    ${seoImage ? `<meta property="og:image" content="${this.escapeHtml(seoImage)}">` : ''}
    <meta property="og:site_name" content="${this.escapeHtml(brandName)}">
    
    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="${this.escapeHtml(seoTitle)}">
    <meta name="twitter:description" content="${this.escapeHtml(seoDescription)}">
    ${seoImage ? `<meta name="twitter:image" content="${this.escapeHtml(seoImage)}">` : ''}
    
    <!-- Language -->
    <meta http-equiv="content-language" content="${lang}">
    `;

    return `
<!DOCTYPE html>
<html lang="${lang}">
<head>
    ${metaTags}
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=${font.replace(/ /g, '+')}:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: '${font}', sans-serif; }
    </style>
</head>
<body class="bg-white text-gray-900">
    <nav class="p-6 flex justify-between items-center max-w-7xl mx-auto">
        <div class="text-2xl font-black" style="color: ${palette[1]}">${this.escapeHtml(brandName)}</div>
        <div class="hidden md:flex gap-8 font-bold text-gray-500">
            <a href="#" class="hover:text-gray-900">Products</a>
            <a href="#" class="hover:text-gray-900">About</a>
            <a href="#" class="hover:text-gray-900">Contact</a>
        </div>
    </nav>
    ${blocksHTML}
</body>
</html>`;
  }

  private static escapeHtml(text: string): string {
    const div = { innerHTML: '' } as any;
    div.textContent = text;
    return div.innerHTML || text.replace(/[&<>"']/g, (m) => {
      const map: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
      return map[m];
    });
  }
}

