/**
 * Сервис для управления шаблонами в маркетплейсе
 */

export interface Template {
  id: string;
  name: string;
  description: string;
  category: 'website' | 'presentation' | 'social' | 'brandkit';
  thumbnail: string;
  previewImages: string[];
  author: {
    id: string;
    name: string;
    avatar?: string;
  };
  price: number; // 0 для бесплатных
  rating: number;
  reviewsCount: number;
  downloadsCount: number;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
  featured: boolean;
  data: any; // Структура шаблона (блоки, слайды и т.д.)
}

export interface TemplateReview {
  id: string;
  templateId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

export class TemplateMarketplaceService {
  private static templates: Template[] = [];
  private static reviews: TemplateReview[] = [];

  /**
   * Создает новый шаблон
   */
  static async createTemplate(templateData: Omit<Template, 'id' | 'createdAt' | 'updatedAt' | 'rating' | 'reviewsCount' | 'downloadsCount'>): Promise<Template> {
    const template: Template = {
      ...templateData,
      id: `template_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      rating: 0,
      reviewsCount: 0,
      downloadsCount: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.templates.push(template);
    return template;
  }

  /**
   * Получает все шаблоны с фильтрацией
   */
  static getTemplates(filters?: {
    category?: string;
    search?: string;
    minRating?: number;
    maxPrice?: number;
    featured?: boolean;
    tags?: string[];
  }): Template[] {
    let filtered = [...this.templates];

    if (filters?.category) {
      filtered = filtered.filter(t => t.category === filters.category);
    }

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(t => 
        t.name.toLowerCase().includes(searchLower) ||
        t.description.toLowerCase().includes(searchLower) ||
        t.tags.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }

    if (filters?.minRating !== undefined) {
      filtered = filtered.filter(t => t.rating >= filters.minRating!);
    }

    if (filters?.maxPrice !== undefined) {
      filtered = filtered.filter(t => t.price <= filters.maxPrice!);
    }

    if (filters?.featured !== undefined) {
      filtered = filtered.filter(t => t.featured === filters.featured);
    }

    if (filters?.tags && filters.tags.length > 0) {
      filtered = filtered.filter(t => 
        filters.tags!.some(tag => t.tags.includes(tag))
      );
    }

    return filtered;
  }

  /**
   * Получает шаблон по ID
   */
  static getTemplateById(templateId: string): Template | null {
    return this.templates.find(t => t.id === templateId) || null;
  }

  /**
   * Скачивает шаблон (увеличивает счетчик)
   */
  static async downloadTemplate(templateId: string, userId: string): Promise<Template | null> {
    const template = this.getTemplateById(templateId);
    if (!template) {
      return null;
    }

    template.downloadsCount++;
    template.updatedAt = new Date();

    return template;
  }

  /**
   * Добавляет отзыв к шаблону
   */
  static async addReview(
    templateId: string,
    userId: string,
    userName: string,
    rating: number,
    comment: string
  ): Promise<TemplateReview> {
    if (rating < 1 || rating > 5) {
      throw new Error('Rating must be between 1 and 5');
    }

    const review: TemplateReview = {
      id: `review_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      templateId,
      userId,
      userName,
      rating,
      comment,
      createdAt: new Date()
    };

    this.reviews.push(review);

    // Обновляем рейтинг шаблона
    const template = this.getTemplateById(templateId);
    if (template) {
      const templateReviews = this.reviews.filter(r => r.templateId === templateId);
      template.rating = templateReviews.reduce((sum, r) => sum + r.rating, 0) / templateReviews.length;
      template.reviewsCount = templateReviews.length;
    }

    return review;
  }

  /**
   * Получает отзывы шаблона
   */
  static getTemplateReviews(templateId: string): TemplateReview[] {
    return this.reviews.filter(r => r.templateId === templateId);
  }

  /**
   * Получает категории шаблонов
   */
  static getCategories(): Array<{ id: string; name: string; count: number }> {
    const categories = ['website', 'presentation', 'social', 'brandkit'];
    return categories.map(cat => ({
      id: cat,
      name: cat.charAt(0).toUpperCase() + cat.slice(1),
      count: this.templates.filter(t => t.category === cat).length
    }));
  }

  /**
   * Получает популярные шаблоны
   */
  static getPopularTemplates(limit: number = 10): Template[] {
    return [...this.templates]
      .sort((a, b) => b.downloadsCount - a.downloadsCount)
      .slice(0, limit);
  }

  /**
   * Получает рекомендуемые шаблоны
   */
  static getRecommendedTemplates(limit: number = 10): Template[] {
    return [...this.templates]
      .filter(t => t.featured || t.rating >= 4)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  /**
   * Инициализирует демо-шаблоны
   */
  static initializeDemoTemplates() {
    if (this.templates.length > 0) return; // Уже инициализировано

    const demoCategories: Array<{ category: Template['category']; name: string; description: string }> = [
      { category: 'website', name: 'Modern Business', description: 'Современный корпоративный сайт' },
      { category: 'website', name: 'E-commerce Store', description: 'Интернет-магазин' },
      { category: 'presentation', name: 'Startup Pitch', description: 'Презентация для стартапа' },
      { category: 'presentation', name: 'Product Launch', description: 'Запуск продукта' },
      { category: 'social', name: 'Instagram Pack', description: 'Набор постов для Instagram' },
      { category: 'social', name: 'LinkedIn Professional', description: 'Профессиональный контент' },
      { category: 'brandkit', name: 'Minimalist Brand', description: 'Минималистичный бренд-кит' },
    ];

    demoCategories.forEach((demo, index) => {
      this.createTemplate({
        name: demo.name,
        description: demo.description,
        category: demo.category,
        thumbnail: `https://via.placeholder.com/400x300?text=${encodeURIComponent(demo.name)}`,
        previewImages: [],
        author: {
          id: 'demo_author',
          name: 'Constructor AI Team'
        },
        price: index < 2 ? 0 : (index < 5 ? 9 : 29), // Первые 2 бесплатные
        tags: [demo.category, 'popular', 'trending'],
        featured: index < 3,
        data: {}
      });
    });
  }
}

