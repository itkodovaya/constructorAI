import express from 'express';
import cors from 'cors';
import { ProjectsService } from './services/projects.service';
import { ExportService } from './services/export.service';
import { PresentationExportService } from './services/presentation-export.service';
import { BrandKitExportService } from './services/brandkit-export.service';
import { BatchPostService } from './services/batch-post.service';
import { TranslateService } from './services/translate.service';
import { AIContentService } from './services/ai_content.service';
import { AdvancedAIService } from './services/advanced-ai.service';
import { AIService } from './services/ai.service';
import { AI_CONFIG } from './config/ai.config';
import { CreateProjectSchema, UpdateProjectSchema, validateProject } from './validation/project.validation';
import { ErrorHandler } from './middleware/errorHandler';
import { authenticate, AuthenticatedRequest, requirePlan, checkLimit } from './middleware/auth.middleware';
import { UserService } from './services/user.service';
import { CollaborationService } from './services/collaboration.service';
import { TemplateMarketplaceService } from './services/template-marketplace.service';
import { swaggerDocument } from './docs/swagger';
import { HealthService } from './services/health.service';
import { logger } from './utils/logger';
import { metricsMiddleware } from './utils/metrics';

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

// Логирование и метрики
app.use(metricsMiddleware);
logger.setContext('Express');

// Swagger документация
app.get('/api-docs/swagger.json', (req, res) => {
  const { swaggerDocument } = require('./docs/swagger');
  res.json(swaggerDocument);
});

// Health check endpoint
app.get('/health', async (req, res) => {
  try {
    const dbCheck = await HealthService.checkDatabase();
    const diskCheck = await HealthService.checkDiskSpace();
    const systemInfo = await HealthService.getSystemInfo();
    
    const healthy = dbCheck.healthy && diskCheck.healthy;
    
    res.status(healthy ? 200 : 503).json({
      status: healthy ? 'ok' : 'degraded',
      timestamp: new Date().toISOString(),
      version: '1.0.1',
      aiMode: AI_CONFIG.useMock ? 'MOCK' : 'REAL',
      checks: {
        database: dbCheck,
        disk: diskCheck,
      },
      system: systemInfo,
    });
  } catch (error) {
    res.status(503).json({
      status: 'error',
      message: 'Health check failed',
    });
  }
});

// Конфигурация AI
AIService.configure(AI_CONFIG);

// Инициализация демо-шаблонов маркетплейса
TemplateMarketplaceService.initializeDemoTemplates();

// ========== АУТЕНТИФИКАЦИЯ ==========

// Регистрация
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, password and name are required' });
    }

    const user = await UserService.createUser(email, password, name);
    res.status(201).json({ 
      user: { ...user, passwordHash: '' },
      message: 'User created successfully'
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Вход
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const result = await UserService.authenticate(email, password);
    
    if (!result) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Получение текущего пользователя
app.get('/api/auth/me', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const user = UserService.getUserById(req.user!.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ user });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Получение информации о планах
app.get('/api/plans', (req, res) => {
  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      limits: UserService.getPlanLimits('free')
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 29,
      limits: UserService.getPlanLimits('pro')
    },
    {
      id: 'brandkit',
      name: 'BrandKit',
      price: 99,
      limits: UserService.getPlanLimits('brandkit')
    }
  ];
  res.json({ plans });
});

// Обновление плана пользователя
app.post('/api/auth/upgrade-plan', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const { plan } = req.body;
    
    if (!['pro', 'brandkit'].includes(plan)) {
      return res.status(400).json({ error: 'Invalid plan' });
    }

    // В реальности здесь была бы интеграция с платежной системой (Stripe и т.д.)
    const user = await UserService.updatePlan(req.user!.id, plan);
    res.json({ user, message: 'Plan upgraded successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ========== ПРОЕКТЫ ==========

// Получение всех проектов (теперь с фильтрацией по пользователю)
// GET /api/projects - публичный для демо-режима
app.get('/api/projects', async (req, res) => {
  try {
    const projects = await ProjectsService.getAll();
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Получение одного проекта
app.get('/api/projects/:id', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

// Создание проекта (Onboarding) - требует аутентификации и проверки лимитов
app.post('/api/projects', authenticate, checkLimit('project'), async (req: AuthenticatedRequest, res) => {
  try {
    // Валидация входных данных
    const validation = validateProject(req.body, CreateProjectSchema);
    if (!validation.success) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: validation.errors 
      });
    }

    // Добавляем userId к проекту
    const projectData = {
      ...validation.data,
      userId: req.user!.id
    };

    const project = await ProjectsService.create(projectData);
    
    // Увеличиваем счетчик проектов пользователя
    await UserService.incrementUsage(req.user!.id, 'project');
    
    res.status(201).json(project);
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ error: 'Failed to create project' });
  }
});

// Обновление проекта
app.put('/api/projects/:id', async (req, res) => {
  try {
    // Валидация входных данных
    const validation = validateProject(req.body, UpdateProjectSchema);
    if (!validation.success) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: validation.errors 
      });
    }

    const project = await ProjectsService.update(req.params.id, validation.data);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json(project);
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({ error: 'Failed to update project' });
  }
});

// Удаление проекта
app.delete('/api/projects/:id', async (req, res) => {
  try {
    const success = await ProjectsService.delete(req.params.id);
    if (!success) return res.status(404).json({ error: 'Project not found' });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete project' });
  }
});

// AI Перевод проекта (с использованием реального AI или заглушек)
app.post('/api/projects/:id/translate', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const targetLang = req.body.lang || 'en';
    
    // Используем реальный AI для перевода текста в блоках
    const translatedPages = await Promise.all(
      project.pages.map(async (page) => ({
        ...page,
        blocks: await Promise.all(
          page.blocks.map(async (block) => {
            const translatedContent = await translateBlockContent(block.content, targetLang);
            return { ...block, content: translatedContent };
          })
        )
      }))
    );

    const updatedProject = await ProjectsService.update(project.id, {
      pages: translatedPages
    });
    
    res.json(updatedProject);
  } catch (error) {
    console.error('Translation error:', error);
    res.status(500).json({ error: 'Translation failed' });
  }
});

// Вспомогательная функция для перевода контента блока
async function translateBlockContent(content: any, targetLang: 'ru' | 'en'): Promise<any> {
  if (typeof content === 'string') {
    return await AIService.translateText(content, targetLang);
  }
  
  if (Array.isArray(content)) {
    return await Promise.all(content.map(item => translateBlockContent(item, targetLang)));
  }
  
  if (typeof content === 'object' && content !== null) {
    const translated: any = {};
    for (const key in content) {
      translated[key] = await translateBlockContent(content[key], targetLang);
    }
    return translated;
  }
  
  return content;
}

// AI Генерация полного контента страницы (с использованием реального AI) - требует проверки лимитов
app.post('/api/projects/:id/generate-content', authenticate, checkLimit('ai_generation'), async (req: AuthenticatedRequest, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    // Используем реальный AI для генерации контента
    const prompt = `Создай контент для сайта бренда "${project.brandName}" в нише "${project.niche}". Нужны блоки: Hero (заголовок и подзаголовок), Features (3-4 особенности), Text (описание), Footer.`;
    
    const aiContent = await AIService.generateText(prompt, 800);
    
    // Парсим ответ AI и создаем блоки (упрощенная версия)
    const newBlocks = AIContentService.generatePageContent(project.niche, project.brandName);
    
    // Если AI вернул контент, обновляем блоки
    if (aiContent && !AI_CONFIG.useMock) {
      // В реальности здесь будет более сложный парсинг ответа AI
      newBlocks[0].content.title = project.brandName;
      newBlocks[0].content.subtitle = aiContent.substring(0, 100);
    }
    
    const updatedProject = await ProjectsService.update(project.id, {
      pages: [{ ...project.pages[0], blocks: newBlocks }]
    });
    
    // Увеличиваем счетчик AI генераций
    if (req.user) {
      await UserService.incrementUsage(req.user.id, 'ai_generation');
    }
    
    res.json(updatedProject);
  } catch (error) {
    console.error('Content generation error:', error);
    // Fallback на старый метод
    try {
      const project = await ProjectsService.getById(req.params.id);
      const newBlocks = AIContentService.generatePageContent(project!.niche, project!.brandName);
      const updatedProject = await ProjectsService.update(project!.id, {
        pages: [{ ...project!.pages[0], blocks: newBlocks }]
      });
      res.json(updatedProject);
    } catch (fallbackError) {
      res.status(500).json({ error: 'Failed to generate content' });
    }
  }
});

// Предпросмотр HTML (возвращает HTML для отображения в iframe)
app.get('/api/projects/:id/preview', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const html = ExportService.generateHTML(
      project.brandName,
      project.brandAssets,
      project.pages[0]?.blocks || [],
      project.seo,
      project.seo?.lang || 'ru'
    );
    
    res.setHeader('Content-Type', 'text/html');
    res.send(html);
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate preview' });
  }
});

// Экспорт сайта в HTML
app.post('/api/projects/:id/export', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const html = ExportService.generateHTML(
      project.brandName,
      project.brandAssets,
      project.pages[0]?.blocks || [],
      project.seo,
      project.seo?.lang || 'ru'
    );
    
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Disposition', `attachment; filename="${project.brandName}_website.html"`);
    res.send(html);
  } catch (error) {
    res.status(500).json({ error: 'Failed to export site' });
  }
});

// Экспорт презентации в PDF
app.post('/api/projects/:id/export-presentation', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const format = req.body.format || '16:9'; // '16:9' или '4:3'
    const slides = project.presentation || [];
    
    const pdfBuffer = await PresentationExportService.exportToPDF({
      format: format as '16:9' | '4:3',
      slides,
      brandName: project.brandName,
      brandAssets: project.brandAssets
    });
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${project.brandName}_presentation.pdf"`);
    res.send(pdfBuffer);
  } catch (error) {
    console.error('Export presentation error:', error);
    res.status(500).json({ error: 'Failed to export presentation' });
  }
});

// Экспорт бренд-кита в ZIP
app.post('/api/projects/:id/export-brandkit', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    // TODO: Реализовать генерацию PDF через библиотеку (например, pdfkit или puppeteer)
    res.json({ message: 'PDF export будет реализован в следующей версии', slides: project.presentation || [] });
  } catch (error) {
    res.status(500).json({ error: 'Failed to export presentation' });
  }
});

// Экспорт бренд-кита в ZIP
app.post('/api/projects/:id/export-brandkit', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const zipBuffer = await BrandKitExportService.exportToZIPBuffer({
      brandName: project.brandName,
      logoUrl: project.brandAssets?.logoUrl,
      logoSvg: project.brandAssets?.logoSvg,
      palette: project.brandAssets?.palette || [],
      fonts: project.brandAssets?.fonts || [],
      socialTemplates: project.brandAssets?.socialTemplates || []
    });
    
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${project.brandName}_brandkit.zip"`);
    res.send(zipBuffer);
  } catch (error) {
    console.error('Export brandkit error:', error);
    res.status(500).json({ error: 'Failed to export brand kit' });
  }
});

// Расширенная AI генерация контента для блока
app.post('/api/projects/:id/generate-block-content', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const { blockType } = req.body;
    
    const content = await AdvancedAIService.generateBlockContent(blockType, {
      brandName: project.brandName,
      niche: project.niche || 'general',
      style: project.style
    });
    
    res.json({ content });
  } catch (error) {
    console.error('Generate block content error:', error);
    res.status(500).json({ error: 'Failed to generate block content' });
  }
});

// Генерация серии постов для соцсетей через AI
app.post('/api/projects/:id/generate-social-posts-ai', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const { count = 5, platforms = ['Instagram', 'VK'] } = req.body;
    
    const posts = await AdvancedAIService.generateSocialPosts(count, {
      brandName: project.brandName,
      niche: project.niche || 'general',
      platforms
    });
    
    res.json({ posts });
  } catch (error) {
    console.error('Generate social posts AI error:', error);
    res.status(500).json({ error: 'Failed to generate social posts' });
  }
});

// Добавление задачи в очередь AI
app.post('/api/ai/queue-task', async (req, res) => {
  try {
    const { type, prompt, options } = req.body;
    
    const taskId = await AdvancedAIService.queueTask({
      type,
      prompt,
      options
    });
    
    res.json({ taskId });
  } catch (error) {
    console.error('Queue task error:', error);
    res.status(500).json({ error: 'Failed to queue task' });
  }
});

// Получение статуса задачи
app.get('/api/ai/task/:taskId', async (req, res) => {
  try {
    const task = AdvancedAIService.getTaskStatus(req.params.taskId);
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    res.json(task);
  } catch (error) {
    console.error('Get task status error:', error);
    res.status(500).json({ error: 'Failed to get task status' });
  }
});

// ========== КОЛЛАБОРАЦИЯ ==========

// Создание приглашения в проект
app.post('/api/projects/:id/invite', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const { email, role } = req.body;
    if (!email || !role) {
      return res.status(400).json({ error: 'Email and role are required' });
    }

    const invitation = await CollaborationService.createInvitation(
      req.params.id,
      email,
      role,
      req.user!.id
    );

    res.status(201).json({ invitation });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Принятие приглашения
app.post('/api/invitations/:id/accept', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const user = UserService.getUserById(req.user!.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const collaborator = await CollaborationService.acceptInvitation(
      req.params.id,
      req.user!.id,
      user.email,
      user.name
    );

    res.json({ collaborator });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Получение коллабораторов проекта
app.get('/api/projects/:id/collaborators', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const collaborators = CollaborationService.getProjectCollaborators(req.params.id);
    res.json({ collaborators });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Удаление коллаборатора
app.delete('/api/projects/:id/collaborators/:userId', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const success = await CollaborationService.removeCollaborator(
      req.params.id,
      req.params.userId,
      req.user!.id
    );

    if (!success) {
      return res.status(404).json({ error: 'Collaborator not found' });
    }

    res.json({ message: 'Collaborator removed' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ========== МАРКЕТПЛЕЙС ШАБЛОНОВ ==========

// Получение всех шаблонов
app.get('/api/templates', (req, res) => {
  try {
    const filters = {
      category: req.query.category as string,
      search: req.query.search as string,
      minRating: req.query.minRating ? parseFloat(req.query.minRating as string) : undefined,
      maxPrice: req.query.maxPrice ? parseFloat(req.query.maxPrice as string) : undefined,
      featured: req.query.featured === 'true',
      tags: req.query.tags ? (req.query.tags as string).split(',') : undefined
    };

    const templates = TemplateMarketplaceService.getTemplates(filters);
    res.json({ templates });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Получение шаблона по ID
app.get('/api/templates/:id', (req, res) => {
  try {
    const template = TemplateMarketplaceService.getTemplateById(req.params.id);
    if (!template) {
      return res.status(404).json({ error: 'Template not found' });
    }
    res.json({ template });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Скачивание шаблона
app.post('/api/templates/:id/download', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const template = await TemplateMarketplaceService.downloadTemplate(
      req.params.id,
      req.user!.id
    );

    if (!template) {
      return res.status(404).json({ error: 'Template not found' });
    }

    res.json({ template });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Добавление отзыва к шаблону
app.post('/api/templates/:id/reviews', authenticate, async (req: AuthenticatedRequest, res) => {
  try {
    const { rating, comment } = req.body;
    const user = UserService.getUserById(req.user!.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const review = await TemplateMarketplaceService.addReview(
      req.params.id,
      req.user!.id,
      user.name,
      rating,
      comment
    );

    res.status(201).json({ review });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Получение отзывов шаблона
app.get('/api/templates/:id/reviews', (req, res) => {
  try {
    const reviews = TemplateMarketplaceService.getTemplateReviews(req.params.id);
    res.json({ reviews });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Получение категорий шаблонов
app.get('/api/templates/categories', (req, res) => {
  try {
    const categories = TemplateMarketplaceService.getCategories();
    res.json({ categories });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Получение популярных шаблонов
app.get('/api/templates/popular', (req, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 10;
    const templates = TemplateMarketplaceService.getPopularTemplates(limit);
    res.json({ templates });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Генерация ссылки для шеринга
app.post('/api/projects/:id/share', async (req, res) => {
  try {
    const project = await ProjectsService.getById(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const shareId = Math.random().toString(36).substr(2, 12);
    // В реальной БД мы бы сохранили этот shareId
    res.json({ shareUrl: `https://constructor.ai/view/${shareId}` });
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate share link' });
  }
});

// Эндпоинт для метрик
app.get('/api/metrics', (req, res) => {
  const { metrics } = require('./utils/metrics');
  const stats = {
    http_requests: metrics.getStats('http_requests_total'),
    request_duration: metrics.getStats('http_request_duration'),
    all_metrics: metrics.getMetrics()
  };
  res.json(stats);
});

// Обработка ошибок (должен быть последним middleware)
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  // Используем улучшенный обработчик ошибок с логированием
  const { ErrorHandler: EnhancedErrorHandler } = require('./utils/enhanced-error-handler');
  EnhancedErrorHandler.handleApiError(err, req, res, next);
});

// Обработка необработанных ошибок
process.on('unhandledRejection', (reason, promise) => {
  EnhancedErrorHandler.handleUnhandledRejection(reason, promise);
});

process.on('uncaughtException', (error) => {
  EnhancedErrorHandler.handleUncaughtException(error);
});

app.listen(port, () => {
  console.log(`Backend running at http://localhost:${port}`);
  console.log(`AI Mode: ${AI_CONFIG.useMock ? 'MOCK (заглушки)' : 'REAL (требуются API ключи)'}`);
});
