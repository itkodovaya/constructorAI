/**
 * Примеры интеграций с внешними сервисами
 */

// Пример интеграции с Telegram Bot
export async function sendTelegramNotification(chatId: string, message: string, token: string) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'HTML',
      }),
    });
    return await response.json();
  } catch (error) {
    console.error('Telegram notification failed:', error);
    throw error;
  }
}

// Пример интеграции с Яндекс.Метрикой
export function trackYandexMetrica(counterId: number, event: string, params?: Record<string, any>) {
  if (typeof window !== 'undefined' && (window as any).ym) {
    (window as any).ym(counterId, 'reachGoal', event, params);
  }
}

// Пример интеграции с amoCRM
export async function createAmoCRMLead(
  domain: string,
  apiKey: string,
  leadData: {
    name: string;
    price: number;
    contacts?: Array<{ name: string; email: string }>;
  }
) {
  try {
    const response = await fetch(`https://${domain}.amocrm.ru/api/v4/leads`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify([leadData]),
    });
    return await response.json();
  } catch (error) {
    console.error('AmoCRM integration failed:', error);
    throw error;
  }
}

// Пример интеграции с UniSender
export async function sendUniSenderEmail(
  apiKey: string,
  email: string,
  subject: string,
  body: string
) {
  try {
    const response = await fetch('https://api.unisender.com/ru/api/sendEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: apiKey,
        email,
        sender_name: 'Constructor AI',
        sender_email: 'noreply@constructor.ai',
        subject,
        body,
        list_id: 1,
      }),
    });
    return await response.json();
  } catch (error) {
    console.error('UniSender integration failed:', error);
    throw error;
  }
}

// Пример webhook для автоматизации
export async function triggerWebhook(url: string, data: any) {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return await response.json();
  } catch (error) {
    console.error('Webhook failed:', error);
    throw error;
  }
}

