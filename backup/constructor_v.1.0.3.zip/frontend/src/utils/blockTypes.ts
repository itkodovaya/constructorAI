/**
 * Дополнительные типы блоков для сайта
 */

export const ADDITIONAL_BLOCK_TYPES = [
  {
    id: 'contact',
    name: 'Contact Form',
    icon: '📧',
    description: 'Форма обратной связи',
    defaultContent: {
      title: 'Свяжитесь с нами',
      subtitle: 'Мы всегда рады помочь',
      fields: [
        { type: 'text', label: 'Имя', required: true },
        { type: 'email', label: 'Email', required: true },
        { type: 'textarea', label: 'Сообщение', required: true },
      ],
      buttonText: 'Отправить',
    },
  },
  {
    id: 'newsletter',
    name: 'Newsletter',
    icon: '📬',
    description: 'Подписка на рассылку',
    defaultContent: {
      title: 'Подпишитесь на новости',
      subtitle: 'Получайте последние обновления',
      placeholder: 'Ваш email',
      buttonText: 'Подписаться',
    },
  },
  {
    id: 'cta',
    name: 'Call to Action',
    icon: '🚀',
    description: 'Призыв к действию',
    defaultContent: {
      title: 'Готовы начать?',
      subtitle: 'Присоединяйтесь к тысячам довольных клиентов',
      buttonText: 'Начать сейчас',
      buttonLink: '#',
    },
  },
  {
    id: 'stats',
    name: 'Statistics',
    icon: '📊',
    description: 'Статистика и цифры',
    defaultContent: {
      title: 'Наши достижения',
      items: [
        { value: '1000+', label: 'Довольных клиентов' },
        { value: '50+', label: 'Проектов' },
        { value: '99%', label: 'Удовлетворенность' },
      ],
    },
  },
];

