import axios from 'axios';
import { handleApiError, showErrorNotification } from '../utils/errorHandler';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Создаем axios instance с базовой конфигурацией
const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor для обработки ошибок
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const url = error.config?.url || '';
    const method = error.config?.method || '';
    const status = error.response?.status;
    
    // Публичные эндпоинты - не показываем ошибки
    const isPublicEndpoint = (
      (url.includes('/projects') && method === 'get') ||
      url.includes('/health') ||
      url.includes('/api-docs')
    );
    
    // В демо-режиме не показываем ошибки аутентификации
    const isAuthError = status === 401;
    
    // Логируем все ошибки в консоль для отладки
    console.log('API Error:', { url, method, status, isPublicEndpoint, isAuthError });
    
    // Показываем ошибки только если это не публичный эндпоинт и не ошибка аутентификации
    if (!isPublicEndpoint && !isAuthError && status !== 401) {
      const message = handleApiError(error);
      showErrorNotification(message);
    }
    
    return Promise.reject(error);
  }
);

export const api = {
  async getProjects() {
    const response = await apiClient.get('/projects');
    return response.data;
  },
  async getProject(id: string) {
    const response = await apiClient.get(`/projects/${id}`);
    return response.data;
  },
  async createProject(data: any) {
    const response = await apiClient.post('/projects', data);
    return response.data;
  },
  async updateProject(id: string, data: any) {
    const response = await apiClient.put(`/projects/${id}`, data);
    return response.data;
  },
  async deleteProject(id: string) {
    await apiClient.delete(`/projects/${id}`);
  },
  async exportProject(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/export`, {}, { responseType: 'blob' });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `website.html`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },
  async shareProject(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/share`);
    return response.data;
  },
  async generateFullContent(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/generate-content`);
    return response.data;
  },
  async translateProject(id: string, lang: 'ru' | 'en') {
    const response = await axios.post(`${API_URL}/projects/${id}/translate`, { lang });
    return response.data;
  },
  getPreviewUrl(id: string): string {
    return `${API_URL}/projects/${id}/preview`;
  },
  async exportPresentation(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/export-presentation`);
    return response.data;
  },
  async exportBrandKit(id: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/export-brandkit`, {}, { responseType: 'blob' });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `brandkit.zip`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },
  async generateBatchSocialPosts(id: string, formats: any[], content: any) {
    const response = await axios.post(
      `${API_URL}/projects/${id}/generate-social-posts`,
      { formats, content },
      { responseType: 'blob' }
    );
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `social_posts.zip`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },
  async generateBlockContent(id: string, blockType: string) {
    const response = await axios.post(`${API_URL}/projects/${id}/generate-block-content`, { blockType });
    return response.data;
  },
  async generateSocialPostsAI(id: string, count: number, platforms: string[]) {
    const response = await axios.post(`${API_URL}/projects/${id}/generate-social-posts-ai`, { count, platforms });
    return response.data;
  },
  async queueAITask(type: 'text' | 'image' | 'translate', prompt: string, options?: any) {
    const response = await axios.post(`${API_URL}/ai/queue-task`, { type, prompt, options });
    return response.data;
  },
  async getAITaskStatus(taskId: string) {
    const response = await axios.get(`${API_URL}/ai/task/${taskId}`);
    return response.data;
  },
  // Аутентификация
  async register(email: string, password: string, name: string) {
    const response = await axios.post(`${API_URL}/auth/register`, { email, password, name });
    return response.data;
  },
  async login(email: string, password: string) {
    const response = await axios.post(`${API_URL}/auth/login`, { email, password });
    return response.data;
  },
  async getCurrentUser() {
    try {
      const response = await axios.get(`${API_URL}/auth/me`);
      return response.data;
    } catch (error: any) {
      // В демо-режиме возвращаем null вместо ошибки
      if (error.response?.status === 401) {
        return null;
      }
      throw error;
    }
  },
  async getPlans() {
    const response = await axios.get(`${API_URL}/plans`);
    return response.data;
  },
  async upgradePlan(plan: 'pro' | 'brandkit') {
    const response = await axios.post(`${API_URL}/auth/upgrade-plan`, { plan });
    return response.data;
  },
  // Коллаборация
  async inviteCollaborator(projectId: string, email: string, role: 'owner' | 'editor' | 'viewer') {
    const response = await axios.post(`${API_URL}/projects/${projectId}/invite`, { email, role });
    return response.data;
  },
  async acceptInvitation(invitationId: string) {
    const response = await axios.post(`${API_URL}/invitations/${invitationId}/accept`);
    return response.data;
  },
  async getCollaborators(projectId: string) {
    const response = await axios.get(`${API_URL}/projects/${projectId}/collaborators`);
    return response.data;
  },
  async removeCollaborator(projectId: string, userId: string) {
    await axios.delete(`${API_URL}/projects/${projectId}/collaborators/${userId}`);
  },
  // Маркетплейс шаблонов
  async getTemplates(filters?: {
    category?: string;
    search?: string;
    minRating?: number;
    maxPrice?: number;
    featured?: boolean;
    tags?: string[];
  }) {
    const params = new URLSearchParams();
    if (filters?.category) params.append('category', filters.category);
    if (filters?.search) params.append('search', filters.search);
    if (filters?.minRating) params.append('minRating', filters.minRating.toString());
    if (filters?.maxPrice) params.append('maxPrice', filters.maxPrice.toString());
    if (filters?.featured) params.append('featured', 'true');
    if (filters?.tags) params.append('tags', filters.tags.join(','));
    
    const response = await axios.get(`${API_URL}/templates?${params.toString()}`);
    return response.data;
  },
  async getTemplate(id: string) {
    const response = await axios.get(`${API_URL}/templates/${id}`);
    return response.data;
  },
  async downloadTemplate(id: string) {
    const response = await axios.post(`${API_URL}/templates/${id}/download`);
    return response.data;
  },
  async addTemplateReview(templateId: string, rating: number, comment: string) {
    const response = await axios.post(`${API_URL}/templates/${templateId}/reviews`, { rating, comment });
    return response.data;
  },
  async getTemplateReviews(templateId: string) {
    const response = await axios.get(`${API_URL}/templates/${templateId}/reviews`);
    return response.data;
  },
  async getTemplateCategories() {
    const response = await axios.get(`${API_URL}/templates/categories`);
    return response.data;
  },
  async getPopularTemplates(limit: number = 10) {
    const response = await axios.get(`${API_URL}/templates/popular?limit=${limit}`);
    return response.data;
  }
};

