import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, Globe, Shield, Lock, Bell, Trash2, Save, ExternalLink, Zap } from 'lucide-react';

interface ProjectSettingsProps {
  project: any;
  onUpdate: (data: any) => void;
  onDelete: () => void;
}

export const ProjectSettings: React.FC<ProjectSettingsProps> = ({ project, onUpdate, onDelete }) => {
  const [domain, setDomain] = useState(`${project.brandName.toLowerCase().replace(/\s+/g, '-')}.constructor.ai`);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      onUpdate({ domain });
      setIsSaving(false);
      alert('Настройки успешно сохранены!');
    }, 1000);
  };

  return (
    <div className="max-w-4xl space-y-10 pb-20">
      {/* General Settings */}
      <section className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm space-y-8">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center">
            <Settings className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900">Основные настройки</h3>
            <p className="text-sm text-slate-500 font-medium">Управление мета-данными проекта</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-3">
            <label className="text-xs font-black text-slate-300 uppercase tracking-widest px-1">Название бренда</label>
            <input 
              type="text" 
              defaultValue={project.brandName}
              className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl outline-none transition-all font-bold text-slate-700"
            />
          </div>
          <div className="space-y-3">
            <label className="text-xs font-black text-slate-300 uppercase tracking-widest px-1">Ниша бизнеса</label>
            <input 
              type="text" 
              defaultValue={project.niche}
              className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl outline-none transition-all font-bold text-slate-700"
            />
          </div>
        </div>
      </section>

      {/* Domain Settings */}
      <section className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm space-y-8">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center">
            <Globe className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900">Домен и публикация</h3>
            <p className="text-sm text-slate-500 font-medium">Настройте адрес вашего сайта</p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-3">
            <label className="text-xs font-black text-slate-300 uppercase tracking-widest px-1">Ваш поддомен</label>
            <div className="flex gap-4">
              <input 
                type="text" 
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                className="flex-1 p-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 rounded-2xl outline-none transition-all font-bold text-slate-700"
              />
              <button className="px-6 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all flex items-center gap-2">
                <ExternalLink className="w-4 h-4" /> Проверить
              </button>
            </div>
          </div>

          <div className="p-6 bg-indigo-50 rounded-3xl border border-indigo-100 flex items-start gap-4">
            <Zap className="w-6 h-6 text-indigo-600 shrink-0 mt-1" />
            <div>
              <div className="text-sm font-bold text-indigo-900 mb-1">Собственный домен</div>
              <p className="text-xs text-indigo-700/70 leading-relaxed font-medium">
                Вы можете подключить собственный домен (например, www.mybrand.com) в рамках тарифа **Pro**. 
                Это повысит доверие клиентов и SEO-показатели.
              </p>
              <button className="mt-4 px-6 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
                Подключить домен
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Danger Zone */}
      <section className="bg-red-50/50 p-10 rounded-[40px] border border-red-100 shadow-sm space-y-8">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center">
            <Trash2 className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-red-900">Опасная зона</h3>
            <p className="text-sm text-red-600/70 font-medium">Действия, которые невозможно отменить</p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <div className="font-bold text-slate-800">Удалить этот проект</div>
            <p className="text-xs text-slate-400 font-medium mt-1">Вся информация, сайты и презентации будут стерты навсегда.</p>
          </div>
          <button 
            onClick={onDelete}
            className="px-8 py-3 bg-white border-2 border-red-100 text-red-500 rounded-2xl font-bold hover:bg-red-500 hover:text-white transition-all"
          >
            Удалить проект
          </button>
        </div>
      </section>

      <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-40">
        <button 
          onClick={handleSave}
          disabled={isSaving}
          className="px-12 py-4 bg-slate-900 text-white rounded-2xl font-black text-lg shadow-2xl hover:bg-slate-800 transition-all flex items-center gap-3 disabled:opacity-50"
        >
          {isSaving ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
          Сохранить изменения
        </button>
      </div>
    </div>
  );
};

const RefreshCw = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 21h5v-5"/></svg>
);

