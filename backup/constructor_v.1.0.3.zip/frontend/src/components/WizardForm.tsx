import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Palette, Target, Layout, Rocket, ChevronRight, ChevronLeft } from 'lucide-react';

interface WizardFormProps {
  onComplete: (data: any) => void;
}

export const WizardForm: React.FC<WizardFormProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({
    brandName: '',
    niche: '',
    style: 'minimalist',
    colors: [] as string[],
    goals: [] as string[],
  });

  const steps = [
    {
      title: 'Как называется ваш бренд?',
      icon: <Sparkles className="w-8 h-8 text-blue-500" />,
      content: (
        <input
          type="text"
          placeholder="Например: Constructor AI"
          className="w-full p-4 text-xl border-2 border-blue-100 rounded-2xl focus:border-blue-500 outline-none transition-all"
          value={formData.brandName}
          onChange={(e) => setFormData({ ...formData, brandName: e.target.value })}
        />
      ),
    },
    {
      title: 'В какой нише вы работаете?',
      icon: <Target className="w-8 h-8 text-purple-500" />,
      content: (
        <select
          className="w-full p-4 text-xl border-2 border-purple-100 rounded-2xl focus:border-purple-500 outline-none transition-all appearance-none"
          value={formData.niche}
          onChange={(e) => setFormData({ ...formData, niche: e.target.value })}
        >
          <option value="">Выберите нишу</option>
          <option value="tech">Технологии / IT</option>
          <option value="beauty">Красота и здоровье</option>
          <option value="education">Образование</option>
          <option value="ecommerce">E-commerce</option>
          <option value="food">Еда и напитки</option>
        </select>
      ),
    },
    {
      title: 'Выберите стиль дизайна',
      icon: <Palette className="w-8 h-8 text-pink-500" />,
      content: (
        <div className="grid grid-cols-2 gap-4">
          {['minimalist', 'tech', 'premium', 'vibrant'].map((s) => (
            <button
              key={s}
              onClick={() => setFormData({ ...formData, style: s })}
              className={`p-4 rounded-2xl border-2 transition-all text-lg capitalize ${
                formData.style === s 
                  ? 'border-pink-500 bg-pink-50 text-pink-700 shadow-lg' 
                  : 'border-gray-100 hover:border-pink-200'
              }`}
            >
              {s === 'minimalist' ? 'Минимализм' : s === 'tech' ? 'Техно' : s === 'premium' ? 'Премиум' : 'Яркий'}
            </button>
          ))}
        </div>
      ),
    },
    {
      title: 'Что нам нужно создать?',
      icon: <Layout className="w-8 h-8 text-green-500" />,
      content: (
        <div className="grid grid-cols-1 gap-3">
          {[
            { id: 'site', label: 'Веб-сайт' },
            { id: 'social', label: 'Контент для соцсетей' },
            { id: 'presentation', label: 'Презентация' },
            { id: 'brandkit', label: 'Бренд-кит и лого' }
          ].map((goal) => (
            <button
              key={goal.id}
              onClick={() => {
                const newGoals = formData.goals.includes(goal.id)
                  ? formData.goals.filter(g => g !== goal.id)
                  : [...formData.goals, goal.id];
                setFormData({ ...formData, goals: newGoals });
              }}
              className={`p-4 rounded-2xl border-2 transition-all text-left flex items-center justify-between ${
                formData.goals.includes(goal.id)
                  ? 'border-green-500 bg-green-50 text-green-700 shadow-md'
                  : 'border-gray-100 hover:border-green-200'
              }`}
            >
              <span className="text-lg">{goal.label}</span>
              {formData.goals.includes(goal.id) && <Rocket className="w-5 h-5" />}
            </button>
          ))}
        </div>
      ),
    }
  ];

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      onComplete(formData);
    }
  };

  return (
    <div className="max-w-xl mx-auto">
      <div className="mb-8 flex justify-between items-center">
        <div className="flex gap-2">
          {steps.map((_, i) => (
            <div 
              key={i} 
              className={`h-2 w-12 rounded-full transition-all ${i <= step ? 'bg-blue-600' : 'bg-gray-200'}`}
            />
          ))}
        </div>
        <span className="text-gray-400 font-medium">Шаг {step + 1} из {steps.length}</span>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-white p-8 rounded-3xl shadow-xl border border-gray-100"
        >
          <div className="flex items-center gap-4 mb-6">
            {steps[step].icon}
            <h2 className="text-2xl font-bold text-gray-800">{steps[step].title}</h2>
          </div>
          
          <div className="mb-8">
            {steps[step].content}
          </div>

          <div className="flex justify-between gap-4">
            <button
              disabled={step === 0}
              onClick={() => setStep(step - 1)}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
                step === 0 ? 'text-gray-300' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <ChevronLeft className="w-5 h-5" /> Назад
            </button>
            <button
              onClick={handleNext}
              className="flex items-center gap-2 bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
            >
              {step === steps.length - 1 ? 'Запустить генерацию' : 'Продолжить'}
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

