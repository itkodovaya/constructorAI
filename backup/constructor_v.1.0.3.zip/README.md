# Constructor AI Platform v3.8

🚀 **Многофункциональная платформа для создания брендов, сайтов и презентаций с помощью AI.**

[![Status](https://img.shields.io/badge/status-production%20ready-green)]()
[![Version](https://img.shields.io/badge/version-3.8-blue)]()
[![License](https://img.shields.io/badge/license-MIT-green)]()

**Полностью готов к использованию и развертыванию!** ✨

## 🆕 Что нового в версии 3.8

- ✅ Расширенные блоки (text, gallery, testimonials, faq)
- ✅ SEO-мета и локализация
- ✅ Экспорт в PDF и ZIP
- ✅ Пресеты форматов для соцсетей (20+ форматов)
- ✅ Генерация соц-постов
- ✅ Расширенный AI с очередями
- ✅ Система аутентификации и тарифов
- ✅ Роли и коллаборация
- ✅ Маркетплейс шаблонов
- ✅ Unit и интеграционные тесты
- ✅ Swagger/OpenAPI документация
- ✅ Система логирования и метрик
- ✅ Полная документация и примеры
- ✅ Скрипты быстрого запуска
- ✅ Улучшенная обработка ошибок

## 🚀 Быстрый старт

### Требования
- Node.js 18+ 
- npm или yarn

### Автоматическая установка (Рекомендуется)

```bash
npm run setup
```

Этот скрипт автоматически:
- Проверит наличие Node.js и npm
- Установит все зависимости
- Создаст необходимые .env файлы
- Создаст необходимые директории

**Альтернативно:**

**Windows:**
```bash
scripts\quick-start.bat
```

**Linux/Mac:**
```bash
chmod +x scripts/quick-start.sh
./scripts/quick-start.sh
```

### Ручная установка

1. **Установите зависимости:**
```bash
# В корне проекта
npm install

# Или отдельно
cd backend && npm install
cd ../frontend && npm install
```

2. **Настройте .env файлы:**
```bash
# Backend
cp backend/.env.example backend/.env

# Frontend
cp frontend/.env.example frontend/.env
```

### Запуск

**Вариант 1: Одной командой (рекомендуется)**
```bash
npm run dev
```
Запускает backend и frontend одновременно.

**Вариант 2: Отдельно**

**Терминал 1 - Backend:**
```bash
cd backend
npm run dev
```
Backend будет доступен на `http://localhost:3001`

**Терминал 2 - Frontend:**
```bash
cd frontend
npm run dev
```
Frontend будет доступен на `http://localhost:5173`

Откройте браузер и перейдите на `http://localhost:5173`

### Проверка работоспособности

Проверьте health endpoint:
```bash
curl http://localhost:3001/health
```

## 📁 Структура проекта

```
constructor/
├── backend/
│   ├── src/
│   │   ├── index.ts              # Express сервер
│   │   └── services/              # Бизнес-логика
│   │       ├── projects.service.ts
│   │       ├── brand.service.ts
│   │       ├── layout.service.ts
│   │       └── ...
│   └── data/
│       └── projects.json         # База данных (JSON)
│
├── frontend/
│   ├── src/
│   │   ├── App.tsx               # Главный компонент
│   │   ├── components/           # React компоненты
│   │   ├── services/
│   │   │   └── api.ts            # API клиент
│   │   └── main.tsx
│   └── package.json
│
└── docs/
    └── DEVELOPMENT_PLAN.md       # План разработки
```

## ✨ Основные функции

- **AI-генерация бренд-кита** (логотип, палитра, шрифты)
- **Конструктор сайтов** с Drag-and-Drop
- **Редактор графики** для соцсетей (Magic Resize)
- **Генератор презентаций** (Cinema Mode)
- **Аналитика сайта** (статистика, графики)
- **Управление командой** и библиотека ассетов
- **Экспорт в HTML** и другие форматы
- **Dark Mode** и AI-помощник

## 🔧 API Endpoints

- `GET /api/projects` - Получить все проекты
- `GET /api/projects/:id` - Получить проект по ID
- `POST /api/projects` - Создать новый проект
- `PUT /api/projects/:id` - Обновить проект
- `DELETE /api/projects/:id` - Удалить проект
- `POST /api/projects/:id/export` - Экспортировать сайт в HTML
- `POST /api/projects/:id/generate-content` - AI генерация контента
- `POST /api/projects/:id/translate` - Перевод проекта

## 📝 Примечания

- Данные хранятся в `backend/data/projects.json`
- При первом запуске файл создастся автоматически
- Все изменения сохраняются автоматически при редактировании

## 🐛 Известные проблемы

- В текущей версии используется JSON для хранения данных (для продакшена рекомендуется PostgreSQL)
- AI-генерация использует заглушки (для реальной работы нужны API ключи OpenAI/Stable Diffusion)
- Нет аутентификации пользователей (планируется в следующих версиях)

## 📚 Дополнительная документация

- [API Documentation](docs/API.md) - Полная документация API
- [Deployment Guide](docs/DEPLOYMENT.md) - Руководство по развертыванию
- [Docker Guide](docs/DOCKER.md) - Работа с Docker
- [Examples](docs/EXAMPLES.md) - Примеры использования
- [Best Practices](docs/BEST_PRACTICES.md) - Best practices
- [FAQ](FAQ.md) - Часто задаваемые вопросы
- [Troubleshooting](docs/TROUBLESHOOTING.md) - Решение проблем
- [Security Checklist](docs/SECURITY.md) - Чеклист безопасности
- [Performance Guide](docs/PERFORMANCE.md) - Оптимизация производительности
- [Migration Guide](docs/MIGRATION.md) - Миграция между версиями

## 🤝 Вклад в проект

См. [CONTRIBUTING.md](CONTRIBUTING.md) для руководства по внесению вклада.

## 📄 Лицензия

MIT

---

**Создано с ❤️ командой Constructor AI**

