import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Rocket, Palette, Layout, Presentation, CheckCircle, 
  ChevronRight, ChevronLeft, Loader2, Download, 
  Sparkles, Layers, Image as ImageIcon, Wand2,
  MousePointer2, Type, Share2, Bell, Plus, Trash2, Folder, History, Eye, Calendar, ShoppingBag, ShieldCheck, Smartphone,
  Link as LinkIcon, HelpCircle, User, Settings, LogOut, CreditCard, ChevronDown, Command, MessageSquare
} from 'lucide-react';
import axios from 'axios';
import confetti from 'canvas-confetti';
import { Editor } from './components/Editor';
import { SiteBuilder } from './components/SiteBuilder';
import { PresentationBuilder } from './components/PresentationBuilder';
import { GraphicsEditor } from './components/GraphicsEditor';
import { AIAssistant } from './components/AIAssistant';
import { PricingModal } from './components/PricingModal';
import { ShareModal } from './components/ShareModal';
import { HistorySidebar } from './components/HistorySidebar';
import { DevicePreview } from './components/DevicePreview';
import { ContentPlanner } from './components/ContentPlanner';
import { TemplateStore } from './components/TemplateStore';
import { Integrations } from './components/Integrations';
import { HelpCenter } from './components/HelpCenter';
import { NotificationCenter } from './components/NotificationCenter';
import { CommandPalette } from './components/CommandPalette';
import { FeedbackModal } from './components/FeedbackModal';
import { MobileAppPromo } from './components/MobileAppPromo';
import { SocialMediaIntegration } from './components/SocialMediaIntegration';

type Step = {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ReactNode;
  color: string;
};

const steps: Step[] = [
  {
    id: 0,
    title: "Имя вашего бренда",
    subtitle: "Как вас будут называть?",
    description: "Введите название, которое мы будем использовать для логотипа и материалов.",
    icon: <Rocket className="w-6 h-6" />,
    color: "from-blue-500 to-indigo-600",
  },
  {
    id: 1,
    title: "Визуальный стиль",
    subtitle: "Какое настроение у бренда?",
    description: "Выберите эстетику, которая лучше всего отражает ваш продукт.",
    icon: <Palette className="w-6 h-6" />,
    color: "from-purple-500 to-violet-600",
  },
  {
    id: 2,
    title: "Приоритетный формат",
    subtitle: "С чего начнем создание?",
    description: "Мы оптимизируем процесс под вашу главную задачу.",
    icon: <Layout className="w-6 h-6" />,
    color: "from-emerald-500 to-teal-600",
  },
  {
    id: 3,
    title: "Магия начинается",
    subtitle: "ИИ анализирует ваши данные",
    description: "Мы готовы сгенерировать полный пакет материалов за считанные секунды.",
    icon: <Sparkles className="w-6 h-6" />,
    color: "from-orange-500 to-rose-600",
  },
];

const API_BASE_URL = 'http://localhost:5000/api';

function App() {
  const [view, setView] = useState<'onboarding' | 'dashboard' | 'project'>('onboarding');
  const [lang, setLanguage] = useState<'RU' | 'EN'>('RU');
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [projects, setProjects] = useState<any[]>([]);
  const [showEditor, setShowEditor] = useState(false);
  const [showSiteBuilder, setShowSiteBuilder] = useState(false);
  const [showPresentationBuilder, setShowPresentationBuilder] = useState(false);
  const [showGraphicsEditor, setShowGraphicsEditor] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showContentPlanner, setShowContentPlanner] = useState(false);
  const [showTemplateStore, setShowTemplateStore] = useState(false);
  const [showIntegrations, setShowIntegrations] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showMobileApp, setShowMobileApp] = useState(false);
  const [showSocialMedia, setShowSocialMedia] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [formData, setFormData] = useState({
    brandName: '',
    style: '',
    primaryGoal: '',
  });

  useEffect(() => {
    fetchProjects();
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowCommandPalette(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/projects`);
      setProjects(response.data);
      if (response.data.length > 0 && view === 'onboarding') {
        setView('dashboard');
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 0) setCurrentStep(currentStep - 1);
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${API_BASE_URL}/onboarding`, formData);
      setProfile(response.data.profile);
      await fetchProjects();
      
      // Launch celebration
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: [response.data.profile.assets.palette[0], response.data.profile.assets.palette[1]]
      });

      setView('project');
    } catch (error) {
      console.error('Error:', error);
      alert('Ошибка при генерации. Попробуйте еще раз.');
    } finally {
      setLoading(false);
    }
  };

  const deleteProject = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Удалить этот проект?')) return;
    try {
      await axios.delete(`${API_BASE_URL}/projects/${id}`);
      fetchProjects();
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  const updateBrandAssets = async (newAssets: any, label?: string) => {
    const updatedAssets = { ...profile.assets, ...newAssets };
    setProfile((prev: any) => ({
      ...prev,
      assets: updatedAssets
    }));

    // Save version to history
    try {
      const response = await axios.post(`${API_BASE_URL}/projects/${profile.id}/version`, {
        assets: updatedAssets,
        label: label || 'Изменено через AI'
      });
      setProfile(response.data);
    } catch (error) {
      console.error('Error saving version:', error);
    }
  };

  const handleAIAction = (action: string) => {
    console.log('AI Action triggered:', action);
    if (action === 'update_palette') {
      const brightPalette = ['#F43F5E', '#FB923C', '#FACC15', '#2DD4BF'];
      updateBrandAssets({ palette: brightPalette }, 'Яркая палитра (AI)');
      alert('AI обновил палитру на "Яркую"!');
    } else if (action === 'minimalist_logo') {
      const minimalistLogo = `https://placehold.co/600x400/FFFFFF/000000/png?text=${encodeURIComponent(profile.brandName)}`;
      updateBrandAssets({ logoUrl: minimalistLogo }, 'Минималистичный логотип (AI)');
      alert('AI упростил ваш логотип!');
    }
  };

  if (view === 'dashboard') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <div className="flex-1 p-12">
          <div className="max-w-6xl mx-auto space-y-10">
            <header className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-xl shadow-indigo-100">
                  <Sparkles className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-black text-slate-900 tracking-tight">Мои проекты</h1>
                  <p className="text-slate-500 font-medium">Все ваши сгенерированные бренды</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setLanguage(lang === 'RU' ? 'EN' : 'RU')}
                  className="w-10 h-10 rounded-xl border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-500 hover:bg-white hover:shadow-sm transition-all"
                >
                  {lang}
                </button>
                <button 
                  onClick={() => setShowPricing(true)}
                  className="px-6 py-3 text-sm font-bold text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all"
                >
                  {lang === 'RU' ? 'Тарифы' : 'Pricing'}
                </button>
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="w-10 h-10 rounded-xl border border-slate-200 flex items-center justify-center text-slate-400 hover:bg-white hover:shadow-sm transition-all relative"
                >
                  <Bell className="w-5 h-5" />
                  <div className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-slate-50" />
                </button>
                <div className="w-px h-6 bg-slate-200 mx-1" />
                <div className="relative">
                  <button 
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center gap-2 p-1.5 rounded-xl border border-slate-200 hover:bg-white transition-all shadow-sm group"
                  >
                    <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white text-xs font-bold">
                      JD
                    </div>
                    <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-slate-600 transition-colors" />
                  </button>

                  <AnimatePresence>
                    {showUserMenu && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setShowUserMenu(false)} />
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 z-50 overflow-hidden"
                        >
                          <div className="p-3 border-b border-slate-50 mb-1">
                            <p className="text-xs font-bold text-slate-900">John Doe</p>
                            <p className="text-[10px] text-slate-400 font-medium">john@example.com</p>
                          </div>
                          <UserMenuItem icon={<User className="w-4 h-4" />} label="Профиль" />
                          <UserMenuItem icon={<CreditCard className="w-4 h-4" />} label="Биллинг" onClick={() => { setShowPricing(true); setShowUserMenu(false); }} />
                          <UserMenuItem icon={<MessageSquare className="w-4 h-4" />} label="Отзыв" onClick={() => { setShowFeedback(true); setShowUserMenu(false); }} />
                          <UserMenuItem icon={<Settings className="w-4 h-4" />} label="Настройки" />
                          <div className="h-px bg-slate-50 my-1" />
                          <UserMenuItem icon={<LogOut className="w-4 h-4" />} label="Выйти" color="text-rose-500" />
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
                <button 
                  onClick={() => {
                    setFormData({ brandName: '', style: '', primaryGoal: '' });
                    setCurrentStep(0);
                    setView('onboarding');
                  }}
                  className="premium-button text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-xl shadow-indigo-100 ml-2"
                >
                  <Plus className="w-5 h-5" /> {lang === 'RU' ? 'Новый бренд' : 'New Brand'}
                </button>
              </div>
            </header>

            {/* Mobile App Banner (Stage 4.1) */}
            <div 
              onClick={() => setShowMobileApp(true)}
              className="bg-indigo-600 rounded-[32px] p-8 text-white flex items-center justify-between relative overflow-hidden shadow-2xl shadow-indigo-200 group cursor-pointer hover:shadow-indigo-300 transition-all"
            >
               <div className="relative z-10 space-y-2">
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 bg-white/20 backdrop-blur-md rounded-lg text-[10px] font-bold uppercase tracking-widest">Скоро: iOS & Android</div>
                  <h2 className="text-2xl font-black">Редактируйте свои проекты на ходу</h2>
                  <p className="text-white/70 text-sm max-w-md">Скачайте мобильное приложение и получите доступ к AI-ассистенту прямо со своего смартфона.</p>
               </div>
               <div className="relative z-10 flex gap-4">
                  <div className="w-12 h-12 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center hover:bg-white/20 transition-all">
                     <Smartphone className="w-6 h-6" />
                  </div>
               </div>
               <Sparkles className="absolute -right-8 -bottom-8 w-48 h-48 text-white/10 group-hover:scale-110 transition-transform duration-700" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {projects.map((project) => (
                <motion.div
                  key={project.id}
                  whileHover={{ y: -5 }}
                  onClick={() => { setProfile(project); setView('project'); }}
                  className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm hover:shadow-2xl transition-all cursor-pointer group relative"
                >
                  <button 
                    onClick={(e) => deleteProject(project.id, e)}
                    className="absolute top-4 right-4 p-2 text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <div className="w-full aspect-square bg-slate-50 rounded-2xl mb-6 flex items-center justify-center p-8 overflow-hidden">
                     <img src={project.assets.logoUrl} alt={project.brandName} className="max-w-full max-h-full object-contain drop-shadow-lg" />
                  </div>
                  
                  <div className="space-y-1 px-2">
                    <h3 className="text-xl font-bold text-slate-900">{project.brandName}</h3>
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest">
                      <span>{project.style}</span>
                      <span className="w-1 h-1 bg-slate-200 rounded-full" />
                      <span>{new Date(project.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </motion.div>
              ))}

              {projects.length === 0 && (
                <div className="col-span-3 py-24 text-center space-y-4">
                  <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Folder className="w-10 h-10 text-slate-300" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-400">У вас пока нет проектов</h3>
                  <p className="text-slate-400">Начните с создания вашего первого бренда</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Dashboard Footer (Stage 4.4 Compliance) */}
        <footer className="h-16 bg-white border-t border-slate-100 px-12 flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">
           <div className="flex gap-8">
              <a href="#" className="hover:text-indigo-600 transition-colors">Правовая информация</a>
              <a href="#" className="hover:text-indigo-600 transition-colors">Условия использования</a>
              <a href="#" className="hover:text-indigo-600 transition-colors">Помощь</a>
           </div>
           <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Данные защищены на серверах в РФ</span>
           </div>
        </footer>
        
        <PricingModal isOpen={showPricing} onClose={() => setShowPricing(false)} />
        <NotificationCenter isOpen={showNotifications} onClose={() => setShowNotifications(false)} />
        <CommandPalette 
          isOpen={showCommandPalette} 
          onClose={() => setShowCommandPalette(false)} 
          onNavigate={(v) => setView(v)} 
        />
        <FeedbackModal isOpen={showFeedback} onClose={() => setShowFeedback(false)} />
        {showMobileApp && <MobileAppPromo onClose={() => setShowMobileApp(false)} />}
        {showSocialMedia && <SocialMediaIntegration onClose={() => setShowSocialMedia(false)} />}
      </div>
    );
  }

  if (view === 'project' && profile) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 hidden lg:flex flex-col p-6 gap-8">
          <div className="flex items-center gap-2 px-2 cursor-pointer" onClick={() => setView('dashboard')}>
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">Constructor</span>
          </div>

          <nav className="flex-1 space-y-1">
            <NavItem 
              icon={<Layers className="w-5 h-5" />} 
              label="Бренд-кит" 
              active={!showEditor && !showSiteBuilder && !showPresentationBuilder && !showGraphicsEditor && !showContentPlanner && !showTemplateStore && !showIntegrations} 
              onClick={() => { setShowEditor(false); setShowSiteBuilder(false); setShowPresentationBuilder(false); setShowGraphicsEditor(false); setShowContentPlanner(false); setShowTemplateStore(false); setShowIntegrations(false); }}
            />
            <NavItem 
              icon={<Layout className="w-5 h-5" />} 
              label="Сайты" 
              active={showSiteBuilder}
              onClick={() => { setShowSiteBuilder(true); setShowEditor(false); setShowPresentationBuilder(false); setShowGraphicsEditor(false); setShowContentPlanner(false); setShowTemplateStore(false); setShowIntegrations(false); }}
            />
            <NavItem 
              icon={<Presentation className="w-5 h-5" />} 
              label="Презентации" 
              active={showPresentationBuilder}
              onClick={() => { setShowPresentationBuilder(true); setShowEditor(false); setShowSiteBuilder(false); setShowGraphicsEditor(false); setShowContentPlanner(false); setShowTemplateStore(false); setShowIntegrations(false); }}
            />
            <NavItem 
              icon={<ImageIcon className="w-5 h-5" />} 
              label="Графика" 
              active={showGraphicsEditor}
              onClick={() => { setShowGraphicsEditor(true); setShowEditor(false); setShowSiteBuilder(false); setShowPresentationBuilder(false); setShowContentPlanner(false); setShowTemplateStore(false); setShowIntegrations(false); }}
            />
            <NavItem 
              icon={<Calendar className="w-5 h-5" />} 
              label="Планировщик" 
              active={showContentPlanner}
              onClick={() => { setShowContentPlanner(true); setShowEditor(false); setShowSiteBuilder(false); setShowPresentationBuilder(false); setShowGraphicsEditor(false); setShowTemplateStore(false); setShowIntegrations(false); }}
            />
            <NavItem 
              icon={<ShoppingBag className="w-5 h-5" />} 
              label="Магазин" 
              active={showTemplateStore}
              onClick={() => { setShowTemplateStore(true); setShowEditor(false); setShowSiteBuilder(false); setShowPresentationBuilder(false); setShowGraphicsEditor(false); setShowContentPlanner(false); setShowIntegrations(false); }}
            />
            <NavItem 
              icon={<LinkIcon className="w-5 h-5" />} 
              label="Интеграции" 
              active={showIntegrations}
              onClick={() => { setShowIntegrations(true); setShowEditor(false); setShowSiteBuilder(false); setShowPresentationBuilder(false); setShowGraphicsEditor(false); setShowContentPlanner(false); setShowTemplateStore(false); }}
            />
          </nav>

          <div className="p-4 bg-slate-50 rounded-xl space-y-3">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Лимит генераций</div>
            <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-600 w-1/5" />
            </div>
            <p className="text-xs text-slate-500">Осталось 4 из 5</p>
            <button 
              onClick={() => setShowPricing(true)}
              className="w-full py-2 text-xs font-bold bg-white border border-slate-200 rounded-lg shadow-sm hover:shadow-md transition-all"
            >
              Перейти на Pro
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          {/* Header */}
          <header className="h-16 bg-white/80 backdrop-blur-md border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <button onClick={() => setView('dashboard')} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <h2 className="font-semibold text-slate-800">Рабочее пространство: {profile.brandName}</h2>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-400 hover:text-slate-600 transition-colors relative"
              >
                <Bell className="w-5 h-5" />
                <div className="absolute top-2 right-2 w-1.5 h-1.5 bg-rose-500 rounded-full border-2 border-white" />
              </button>
              <button 
                onClick={() => setShowPreview(true)}
                className="p-2 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <Eye className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setShowHistory(true)}
                className="p-2 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <History className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setShowShare(true)}
                className="p-2 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <Share2 className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setShowPricing(true)}
                className="ml-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold text-sm flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
              >
                Опубликовать
              </button>
            </div>
          </header>

          <div className="p-8 max-w-6xl mx-auto space-y-12">
            {/* Logo Section */}
            <section className="space-y-6">
              <div className="flex justify-between items-end">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">Ваш новый логотип</h3>
                  <p className="text-slate-500">ИИ разработал уникальный символ для {profile.brandName}</p>
                </div>
                <button 
                  onClick={() => setShowEditor(true)}
                  className="flex items-center gap-2 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition-colors"
                >
                  <Wand2 className="w-4 h-4" /> Варианты генерации
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div 
                  onClick={() => setShowEditor(true)}
                  className="md:col-span-3 aspect-[16/9] bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex items-center justify-center relative group p-12 cursor-pointer hover:border-indigo-200 transition-all"
                >
                  <div className="absolute top-6 left-6 flex gap-2">
                    <button className="p-2 bg-white rounded-lg shadow-sm border border-slate-100 hover:bg-slate-50 transition-colors">
                      <MousePointer2 className="w-4 h-4 text-slate-600" />
                    </button>
                    <button className="p-2 bg-white rounded-lg shadow-sm border border-slate-100 hover:bg-slate-50 transition-colors">
                      <Type className="w-4 h-4 text-slate-600" />
                    </button>
                  </div>
                  <img src={profile.assets.logoUrl} alt="Logo" className="max-w-[80%] max-h-full drop-shadow-2xl transition-transform group-hover:scale-105 duration-700" />
                  <div className="absolute bottom-6 right-6 flex gap-3">
                    <button className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2 hover:bg-slate-800 transition-colors">
                      <Download className="w-3.5 h-3.5" /> SVG
                    </button>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <h4 className="font-bold text-slate-800 flex items-center gap-2">
                      <Palette className="w-4 h-4 text-indigo-500" /> Цвета
                    </h4>
                    <div className="grid grid-cols-2 gap-3">
                      {profile.assets.palette.map((color: string) => (
                        <div key={color} className="space-y-1.5 group cursor-pointer">
                          <div className="h-12 w-full rounded-xl border border-slate-100 shadow-sm transition-transform group-hover:scale-105" style={{ backgroundColor: color }} />
                          <div className="text-[10px] font-mono text-slate-400 text-center uppercase">{color}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <h4 className="font-bold text-slate-800 flex items-center gap-2">
                      <Type className="w-4 h-4 text-purple-500" /> Типографика
                    </h4>
                    <div className="space-y-3">
                      <div className="p-3 bg-slate-50 rounded-xl">
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Заголовок</div>
                        <div className="text-xl font-bold truncate" style={{ fontFamily: profile.assets.fonts.primary }}>
                          {profile.assets.fonts.primary}
                        </div>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-xl">
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Текст</div>
                        <div className="text-base truncate" style={{ fontFamily: profile.assets.fonts.secondary }}>
                          {profile.assets.fonts.secondary}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* AI Magic Grid */}
            {!showIntegrations && (
              <section className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-900">Что мы подготовили для вас</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <MagicCard 
                    title="Веб-сайт" 
                    description="Готовый лендинг с адаптивной версткой и вашим дизайном."
                    icon={<Layout className="w-8 h-8 text-blue-500" />}
                    badge="Готово на 80%"
                    onClick={() => setShowSiteBuilder(true)}
                  />
                  <MagicCard 
                    title="Презентация" 
                    description="12 слайдов с инфографикой и структурой вашего бизнеса."
                    icon={<Presentation className="w-8 h-8 text-purple-500" />}
                    badge="Готово"
                    onClick={() => setShowPresentationBuilder(true)}
                  />
                  <MagicCard 
                    title="Соцсети" 
                    description="Набор обложек и постов для VK, Telegram и Instagram."
                    icon={<ImageIcon className="w-8 h-8 text-rose-500" />}
                    badge="Генерируем..."
                    onClick={() => setShowGraphicsEditor(true)}
                  />
                </div>
              </section>
            )}

            {showIntegrations && <Integrations onOpenSocialMedia={() => setShowSocialMedia(true)} />}
          </div>
        </main>
        
        {showEditor && (
          <Editor 
            brandName={profile.brandName}
            logoUrl={profile.assets.logoUrl}
            palette={profile.assets.palette}
            fonts={profile.assets.fonts}
            onClose={() => setShowEditor(false)}
          />
        )}

        {showSiteBuilder && (
          <SiteBuilder 
            brandName={profile.brandName}
            palette={profile.assets.palette}
            fonts={profile.assets.fonts}
            onClose={() => setShowSiteBuilder(false)}
          />
        )}

        {showPresentationBuilder && (
          <PresentationBuilder 
            brandName={profile.brandName}
            palette={profile.assets.palette}
            fonts={profile.assets.fonts}
            onClose={() => setShowPresentationBuilder(false)}
            onConvertToSite={() => {
              setShowPresentationBuilder(false);
              setShowSiteBuilder(true);
              confetti({ particleCount: 100, spread: 50, origin: { y: 0.8 } });
            }}
          />
        )}

        {showGraphicsEditor && (
          <GraphicsEditor 
            brandName={profile.brandName}
            logoUrl={profile.assets.logoUrl}
            palette={profile.assets.palette}
            fonts={profile.assets.fonts}
            onClose={() => setShowGraphicsEditor(false)}
          />
        )}
        
        <PricingModal isOpen={showPricing} onClose={() => setShowPricing(false)} />
        <ShareModal isOpen={showShare} onClose={() => setShowShare(false)} brandName={profile.brandName} />
        <HistorySidebar 
          isOpen={showHistory} 
          onClose={() => setShowHistory(false)} 
          versions={profile.history || []}
          onRestore={async (v) => {
            setProfile({ ...profile, assets: v.assets });
            setShowHistory(false);
            confetti({ particleCount: 50, spread: 30, origin: { y: 0.5 } });
          }}
        />
        <DevicePreview 
          isOpen={showPreview} 
          onClose={() => setShowPreview(false)} 
          brandName={profile.brandName} 
          palette={profile.assets.palette} 
        />
        {showContentPlanner && (
          <ContentPlanner 
            brandName={profile.brandName}
            logoUrl={profile.assets.logoUrl}
            onClose={() => setShowContentPlanner(false)}
          />
        )}
        {showTemplateStore && (
          <TemplateStore onClose={() => setShowTemplateStore(false)} />
        )}
        {showHelp && (
          <HelpCenter onClose={() => setShowHelp(false)} />
        )}
        <AIAssistant brandName={profile.brandName} onAction={handleAIAction} />
        {showMobileApp && <MobileAppPromo onClose={() => setShowMobileApp(false)} />}
        {showSocialMedia && <SocialMediaIntegration onClose={() => setShowSocialMedia(false)} />}
      </div>
    );
  }

  // Onboarding View (default fallback)
  if (view === 'onboarding') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 selection:bg-indigo-100">
      {/* Background Decor */}
      <div className="fixed inset-0 overflow-hidden -z-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-200/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-200/20 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="w-full max-w-xl">
        <div className="text-center mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white rounded-full border border-slate-200 shadow-sm mb-4">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Constructor AI v1.0</span>
          </div>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Создайте бренд <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">силой мысли</span></h1>
          <p className="text-slate-500 text-lg">Ответьте на 4 вопроса — получите сайт, логотип и бренд-кит.</p>
        </div>

        <div className="glass-card rounded-[32px] overflow-hidden relative shadow-2xl">
          {loading && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 bg-white/60 backdrop-blur-md z-50 flex flex-col items-center justify-center p-12 text-center"
            >
              <div className="relative mb-8">
                <div className="w-24 h-24 border-4 border-indigo-100 rounded-full animate-spin border-t-indigo-600" />
                <Sparkles className="w-8 h-8 text-indigo-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Создаем вашу визуальную вселенную...</h2>
              <p className="text-slate-500">ИИ подбирает цвета, шрифты и рисует логотип.</p>
            </motion.div>
          )}

          {/* Stepper Header */}
          <div className="px-12 pt-12 flex justify-between items-center mb-8">
            <div className="flex gap-1.5">
              {steps.map((_, i) => (
                <div key={i} className={`h-1.5 rounded-full transition-all duration-500 ${i === currentStep ? 'w-8 bg-indigo-600' : 'w-1.5 bg-slate-200'}`} />
              ))}
            </div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Шаг {currentStep + 1} / {steps.length}</div>
          </div>

          <div className="px-12 pb-12">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.4, ease: "circOut" }}
                className="space-y-8"
              >
                <div className="space-y-2">
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${steps[currentStep].color} flex items-center justify-center text-white shadow-lg mb-4`}>
                    {steps[currentStep].icon}
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900">{steps[currentStep].title}</h2>
                  <p className="text-slate-500 text-lg leading-relaxed">{steps[currentStep].description}</p>
                </div>

                <div className="min-h-[200px]">
                  {currentStep === 0 && (
                    <div className="space-y-4">
                      <input
                        autoFocus
                        type="text"
                        value={formData.brandName}
                        onChange={(e) => setFormData({ ...formData, brandName: e.target.value })}
                        className="w-full p-5 bg-slate-50/50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-xl font-medium"
                        placeholder="Название вашей компании"
                      />
                    </div>
                  )}

                  {currentStep === 1 && (
                    <div className="grid grid-cols-2 gap-4">
                      {['Минимализм', 'Яркий', 'Корпоративный', 'Креативный'].map((style) => (
                        <button
                          key={style}
                          onClick={() => setFormData({ ...formData, style })}
                          className={`group p-5 rounded-2xl border-2 transition-all text-left space-y-1 ${
                            formData.style === style 
                            ? 'border-indigo-600 bg-indigo-50 shadow-md shadow-indigo-100' 
                            : 'border-slate-100 hover:border-indigo-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className={`font-bold ${formData.style === style ? 'text-indigo-600' : 'text-slate-700'}`}>{style}</div>
                          <div className="text-xs text-slate-400 leading-snug">Идеально подойдет для современных стартапов.</div>
                        </button>
                      ))}
                    </div>
                  )}

                  {currentStep === 2 && (
                    <div className="space-y-3">
                      {[
                        { id: 'site', label: 'Веб-сайт / Лендинг', desc: 'Публикация в один клик' },
                        { id: 'logo', label: 'Логотип и Бренд-кит', desc: 'Векторные форматы высокого качества' },
                        { id: 'presentation', label: 'Презентация', desc: 'Профессиональная структура и стиль' },
                      ].map((goal) => (
                        <button
                          key={goal.id}
                          onClick={() => setFormData({ ...formData, primaryGoal: goal.id })}
                          className={`w-full p-5 flex items-center justify-between rounded-2xl border-2 transition-all group ${
                            formData.primaryGoal === goal.id 
                            ? 'border-indigo-600 bg-indigo-50 shadow-md shadow-indigo-100' 
                            : 'border-slate-100 hover:border-indigo-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="text-left">
                            <div className={`font-bold ${formData.primaryGoal === goal.id ? 'text-indigo-600' : 'text-slate-700'}`}>{goal.label}</div>
                            <div className="text-xs text-slate-400">{goal.desc}</div>
                          </div>
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${formData.primaryGoal === goal.id ? 'border-indigo-600 bg-indigo-600' : 'border-slate-200'}`}>
                            {formData.primaryGoal === goal.id && <CheckCircle className="w-4 h-4 text-white" />}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}

                  {currentStep === 3 && (
                    <div className="py-6 space-y-6">
                      <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 flex items-center gap-6">
                        <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center text-2xl font-bold text-indigo-600">
                          {formData.brandName.charAt(0)}
                        </div>
      <div>
                          <div className="font-bold text-slate-900 text-xl">{formData.brandName}</div>
                          <div className="text-sm text-slate-500">Стиль: {formData.style} • Цель: {formData.primaryGoal}</div>
                        </div>
                      </div>
                      <p className="text-center text-slate-500 text-sm italic px-8">«Мы используем алгоритмы Looka и Photoroom для достижения наилучшего результата»</p>
                    </div>
                  )}
                </div>

                <div className="flex justify-between items-center pt-8 border-t border-slate-100">
                  <button
                    onClick={prevStep}
                    className={`flex items-center gap-2 text-sm font-bold text-slate-400 hover:text-slate-600 transition-colors ${
                      currentStep === 0 ? 'invisible' : ''
                    }`}
                  >
                    <ChevronLeft className="w-5 h-5" /> Назад
                  </button>
                  <button
                    disabled={
                      (currentStep === 0 && !formData.brandName) ||
                      (currentStep === 1 && !formData.style) ||
                      (currentStep === 2 && !formData.primaryGoal)
                    }
                    onClick={currentStep === steps.length - 1 ? handleSubmit : nextStep}
                    className="premium-button text-white px-10 py-4 rounded-2xl font-bold flex items-center gap-2 shadow-xl shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {currentStep === steps.length - 1 ? 'Запустить магию' : 'Далее'}
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
        
        <div className="mt-10 flex justify-center gap-8 opacity-40">
          <span className="text-[10px] font-bold uppercase tracking-[0.2em]">Secure Payments</span>
          <span className="text-[10px] font-bold uppercase tracking-[0.2em]">Privacy First</span>
          <span className="text-[10px] font-bold uppercase tracking-[0.2em]">24/7 AI Support</span>
        </div>
      </div>
    </div>
    );
  }

  // Ultimate fallback - should never reach here
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Загрузка...</h1>
        <p className="text-slate-500">Инициализация приложения</p>
      </div>
    </div>
  );
}

function UserMenuItem({ icon, label, onClick, color = "text-slate-600" }: { icon: any, label: string, onClick?: () => void, color?: string }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-bold transition-all hover:bg-slate-50 ${color}`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function NavItem({ icon, label, onClick, active = false }: { icon: React.ReactNode, label: string, onClick: () => void, active?: boolean }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${
      active ? 'bg-indigo-50 text-indigo-600 shadow-sm' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
    }`}>
      {icon}
      <span>{label}</span>
        </button>
  );
}

function MagicCard({ title, description, icon, badge, onClick }: { title: string, description: string, icon: React.ReactNode, badge: string, onClick: () => void }) {
  return (
    <div 
      onClick={onClick}
      className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group cursor-pointer"
    >
      <div className="flex justify-between items-start mb-6">
        <div className="p-4 bg-slate-50 rounded-2xl group-hover:scale-110 transition-transform duration-500">
          {icon}
        </div>
        <span className={`text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full ${
          badge.includes('...') ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'
        }`}>
          {badge}
        </span>
      </div>
      <h4 className="text-xl font-bold text-slate-800 mb-2">{title}</h4>
      <p className="text-slate-500 text-sm leading-relaxed mb-6">{description}</p>
      <div className="flex items-center gap-2 text-sm font-bold text-indigo-600">
        Открыть редактор <ChevronRight className="w-4 h-4" />
      </div>
    </div>
  );
}

export default App;
