import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ImageIcon, Scissors, Sun, 
  Maximize, Instagram, Share2, Download, 
  Layers, Plus, Trash2, Wand2, ChevronLeft,
  Smartphone, Hash, Send, LayoutGrid, RefreshCw, Zap, Sparkles
} from 'lucide-react';

interface GraphicTemplate {
  id: string;
  name: string;
  width: number;
  height: number;
  icon: React.ReactNode;
}

const templates: GraphicTemplate[] = [
  { id: 'insta-post', name: 'Instagram Post', width: 1080, height: 1080, icon: <Instagram className="w-4 h-4" /> },
  { id: 'insta-story', name: 'Instagram Story', width: 1080, height: 1920, icon: <Smartphone className="w-4 h-4" /> },
  { id: 'vk-cover', name: 'VK Cover', width: 1590, height: 530, icon: <LayoutGrid className="w-4 h-4" /> },
  { id: 'tg-post', name: 'Telegram Post', width: 1280, height: 720, icon: <Send className="w-4 h-4" /> },
];

interface GraphicsEditorProps {
  brandName: string;
  logoUrl: string;
  palette: string[];
  fonts: { primary: string; secondary: string };
  onClose: () => void;
}

export const GraphicsEditor: React.FC<GraphicsEditorProps> = ({ brandName, logoUrl, palette, fonts, onClose }) => {
  const [selectedTemplate, setSelectedTemplate] = useState(templates[0]);
  const [isBulkMode, setIsBulkMode] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasBackground, setHasBackground] = useState(true);
  const [hasShadow, setHasShadow] = useState(false);
  const [brightness, setBrightness] = useState(100);

  const simulateProcessing = (action: string, callback: () => void) => {
    setIsProcessing(true);
    setTimeout(() => {
      callback();
      setIsProcessing(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-slate-100 z-[100] flex flex-col overflow-hidden select-none">
      {/* Top Bar */}
      <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 z-20">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <ChevronLeft className="w-5 h-5 text-slate-500" />
          </button>
          <div className="h-4 w-px bg-slate-200" />
          <h2 className="font-bold text-slate-800 text-sm">Графический редактор: {brandName}</h2>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsBulkMode(!isBulkMode)}
            className={`flex items-center gap-2 px-3 py-1.5 text-sm font-bold rounded-lg transition-all ${
              isBulkMode ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <LayoutGrid className="w-4 h-4" /> Пакетная обработка
          </button>
          <div className="w-px h-6 bg-slate-200 mx-1" />
          <button className="flex items-center gap-2 px-3 py-1.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
            <Share2 className="w-4 h-4" /> Опубликовать
          </button>
          <button className="flex items-center gap-2 px-4 py-1.5 text-sm font-bold bg-indigo-600 text-white rounded-lg shadow-lg hover:bg-indigo-700 transition-all">
            <Download className="w-4 h-4" /> Скачать
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {isBulkMode ? (
          <main className="flex-1 p-8 bg-slate-50 overflow-y-auto">
             <div className="max-w-6xl mx-auto space-y-8">
                <div className="flex justify-between items-center">
                   <div>
                      <h2 className="text-2xl font-bold text-slate-900">Пакетная генерация материалов</h2>
                      <p className="text-slate-500">Создайте посты для всех соцсетей одновременно в один клик.</p>
                   </div>
                   <button 
                     onClick={() => simulateProcessing('Генерация всех форматов...', () => {})}
                     className="premium-button text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-3 shadow-2xl shadow-indigo-200"
                   >
                      <Zap className="w-5 h-5" /> Генерировать всё
                   </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                   {templates.map(t => (
                      <div key={t.id} className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
                         <div className="aspect-[4/3] bg-slate-50 rounded-2xl mb-6 flex items-center justify-center p-6 relative overflow-hidden">
                            <img src={logoUrl} alt="Preview" className="max-w-[80%] max-h-full object-contain drop-shadow-lg" />
                            <div className="absolute inset-0 bg-indigo-600/0 group-hover:bg-indigo-600/5 transition-colors" />
                         </div>
                         <div className="flex justify-between items-center">
                            <div>
                               <div className="font-bold text-slate-900">{t.name}</div>
                               <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{t.width}x{t.height} px</div>
                            </div>
                            <div className="flex gap-2">
                               <button className="p-2 bg-slate-50 rounded-lg text-slate-400 hover:text-indigo-600">
                                  <RefreshCw className="w-4 h-4" />
                               </button>
                               <button className="p-2 bg-slate-50 rounded-lg text-slate-400 hover:text-emerald-500">
                                  <Download className="w-4 h-4" />
                               </button>
                            </div>
                         </div>
                      </div>
                   ))}
                </div>
             </div>
          </main>
        ) : (
          <>
            {/* Left Toolbar - Photoroom Style */}
        <aside className="w-72 bg-white border-r border-slate-200 flex flex-col z-10">
          <div className="p-4 border-b border-slate-100">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Инструменты AI</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            <div className="space-y-3">
               <ToolCard 
                title="Удалить фон" 
                desc="ИИ автоматически вырежет объект"
                icon={<Scissors className="w-5 h-5 text-indigo-600" />}
                active={!hasBackground}
                onClick={() => simulateProcessing('Removing background...', () => setHasBackground(false))}
               />
               <ToolCard 
                title="Умные тени" 
                desc="Добавить реалистичную глубину"
                icon={<Sun className="w-5 h-5 text-amber-500" />}
                active={hasShadow}
                onClick={() => setHasShadow(!hasShadow)}
               />
               <ToolCard 
                title="Ретушь" 
                desc="Улучшить качество изображения"
                icon={<Wand2 className="w-5 h-5 text-purple-500" />}
                onClick={() => simulateProcessing('Retouching...', () => {})}
               />
            </div>

            <div className="h-px bg-slate-100" />

            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Формат поста</h3>
              <div className="grid grid-cols-1 gap-2">
                {templates.map(t => (
                  <button
                    key={t.id}
                    onClick={() => setSelectedTemplate(t)}
                    className={`flex items-center justify-between p-3 rounded-xl border-2 transition-all ${
                      selectedTemplate.id === t.id ? 'border-indigo-600 bg-indigo-50' : 'border-slate-50 hover:border-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white rounded-lg shadow-sm">{t.icon}</div>
                      <div className="text-left">
                        <div className="text-xs font-bold text-slate-800">{t.name}</div>
                        <div className="text-[10px] text-slate-400">{t.width}x{t.height} px</div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4 pt-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Яркость</h3>
              <input 
                type="range" 
                min="50" max="150" value={brightness} 
                onChange={(e) => setBrightness(parseInt(e.target.value))}
                className="w-full h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600" 
              />
            </div>
          </div>
        </aside>

        {/* Canvas Area */}
        <div className="flex-1 bg-slate-200/50 p-12 flex items-center justify-center relative overflow-hidden">
           {isProcessing && (
              <motion.div 
                initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="absolute inset-0 bg-white/40 backdrop-blur-[2px] z-50 flex flex-col items-center justify-center space-y-4"
              >
                <div className="w-12 h-12 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin" />
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">AI обрабатывает фото...</span>
              </motion.div>
           )}

           <div 
             className="bg-white shadow-2xl relative overflow-hidden transition-all duration-500 flex items-center justify-center"
             style={{ 
               width: selectedTemplate.width > selectedTemplate.height ? '600px' : '400px',
               aspectRatio: `${selectedTemplate.width}/${selectedTemplate.height}`,
               maxHeight: '70vh'
             }}
           >
              {/* Background Color/Pattern */}
              <div className="absolute inset-0 transition-colors duration-500" style={{ backgroundColor: hasBackground ? '#FFFFFF' : palette[2] + '40' }} />
              {!hasBackground && (
                <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `radial-gradient(${palette[0]} 2px, transparent 2px)`, backgroundSize: '20px 20px' }} />
              )}

              {/* Main Subject */}
              <motion.div 
                layout
                className="relative z-10 flex flex-col items-center gap-6"
                style={{ filter: `brightness(${brightness}%)` }}
              >
                 <div className="relative">
                    {hasShadow && (
                      <div className="absolute inset-0 blur-2xl scale-110 translate-y-8 opacity-40 rounded-full" style={{ backgroundColor: palette[0] }} />
                    )}
                    <img 
                      src={logoUrl} 
                      alt="Logo" 
                      className="w-48 h-48 object-contain relative z-10 transition-transform hover:scale-105 duration-500" 
                    />
                 </div>
                 
                 <div className="text-center space-y-2">
                    <h4 className="text-2xl font-black text-slate-900" style={{ fontFamily: fonts.primary }}>{brandName}</h4>
                    <div className="flex items-center gap-2 justify-center">
                       <Hash className="w-3 h-3 text-indigo-500" />
                       <span className="text-xs font-bold text-slate-400 tracking-widest uppercase">New Brand 2026</span>
                    </div>
                 </div>
              </motion.div>

              {/* Design Elements */}
              <div className="absolute top-8 left-8 flex items-center gap-3">
                 <div className="w-2 h-12 rounded-full" style={{ backgroundColor: palette[0] }} />
                 <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest vertical-text">Limited Edition</div>
              </div>
           </div>

           {/* Quick Actions Overlay */}
           <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-white px-6 py-3 rounded-2xl shadow-xl border border-slate-100 flex gap-6 items-center">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest border-r pr-6 border-slate-100">AI Модуль</div>
              <button className="flex items-center gap-2 text-xs font-bold text-slate-700 hover:text-indigo-600 transition-colors">
                 <Maximize className="w-4 h-4" /> Вписать
              </button>
              <button className="flex items-center gap-2 text-xs font-bold text-slate-700 hover:text-indigo-600 transition-colors">
                 <Layers className="w-4 h-4" /> Слои
              </button>
              <button className="flex items-center gap-2 text-xs font-bold text-rose-500 hover:text-rose-600 transition-colors">
                 <Trash2 className="w-4 h-4" /> Сброс
              </button>
           </div>
        </div>
      </>
    )}
    </div>
  </div>
  );
};

// Sub-components
const ToolCard = ({ title, desc, icon, active = false, onClick }: { title: string, desc: string, icon: any, active?: boolean, onClick?: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full p-4 rounded-2xl border-2 text-left transition-all ${
      active ? 'border-indigo-600 bg-indigo-50 shadow-md shadow-indigo-100' : 'border-slate-50 hover:border-slate-100 bg-slate-50/50'
    }`}
  >
    <div className="flex items-center gap-3 mb-1">
      {icon}
      <div className="text-sm font-bold text-slate-800">{title}</div>
    </div>
    <div className="text-[10px] text-slate-500 leading-snug pl-8">{desc}</div>
  </button>
);

