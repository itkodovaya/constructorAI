import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Link as LinkIcon, 
  Settings2, 
  ExternalLink, 
  ShieldCheck, 
  Zap, 
  Database, 
  Globe, 
  Mail, 
  MessageSquare,
  Check,
  ChevronRight,
  Plus,
  Instagram,
  Share2
} from 'lucide-react';

interface Integration {
  id: string;
  name: string;
  category: 'crm' | 'analytics' | 'mailing' | 'chat';
  description: string;
  icon: React.ReactNode;
  isConnected: boolean;
  color: string;
}

interface IntegrationsProps {
  onOpenSocialMedia?: () => void;
}

export const Integrations: React.FC<IntegrationsProps> = ({ onOpenSocialMedia }) => {
  const [integrations, setIntegrations] = useState<Integration[]>([
    {
      id: 'amo',
      name: 'amoCRM',
      category: 'crm',
      description: 'Автоматическая передача заявок с вашего сайта прямо в воронку продаж.',
      icon: <Database className="w-5 h-5" />,
      isConnected: true,
      color: 'bg-blue-600'
    },
    {
      id: 'metrica',
      name: 'Яндекс.Метрика',
      category: 'analytics',
      description: 'Детальная аналитика посещений, тепловые карты и отслеживание целей.',
      icon: <Globe className="w-5 h-5" />,
      isConnected: false,
      color: 'bg-red-500'
    },
    {
      id: 'telegram',
      name: 'Telegram Bot',
      category: 'chat',
      description: 'Мгновенные уведомления о новых заказах и формах в ваш чат.',
      icon: <MessageSquare className="w-5 h-5" />,
      isConnected: true,
      color: 'bg-sky-500'
    },
    {
      id: 'unisender',
      name: 'UniSender',
      category: 'mailing',
      description: 'Рассылки по базе клиентов, собранных через формы на сайте.',
      icon: <Mail className="w-5 h-5" />,
      isConnected: false,
      color: 'bg-yellow-500'
    }
  ]);

  const [activeTab, setActiveTab] = useState<'all' | 'crm' | 'analytics' | 'mailing' | 'chat'>('all');

  const filteredIntegrations = activeTab === 'all' 
    ? integrations 
    : integrations.filter(i => i.category === activeTab);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-12">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Интеграции и API</h2>
          <p className="text-slate-500 font-medium">Свяжите ваш бренд с внешними сервисами и автоматизируйте бизнес.</p>
        </div>
        <div className="flex gap-3">
          {onOpenSocialMedia && (
            <button 
              onClick={onOpenSocialMedia}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-bold text-sm hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg"
            >
              <Share2 className="w-4 h-4" /> Соцсети
            </button>
          )}
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all shadow-lg">
            <Plus className="w-4 h-4" /> Добавить Webhook
          </button>
        </div>
      </div>

      <div className="flex gap-4 border-b border-slate-100 pb-px">
        {['all', 'crm', 'analytics', 'mailing', 'chat'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`px-4 py-3 text-sm font-bold capitalize transition-all relative ${
              activeTab === tab ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            {tab === 'all' ? 'Все' : tab.toUpperCase()}
            {activeTab === tab && (
              <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
            )}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredIntegrations.map((item) => (
          <div 
            key={item.id}
            className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm hover:shadow-xl transition-all group flex flex-col justify-between"
          >
            <div className="flex justify-between items-start mb-6">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-2xl ${item.color} text-white flex items-center justify-center shadow-lg shadow-slate-100`}>
                  {item.icon}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">{item.name}</h3>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.category}</div>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center gap-1.5 ${
                item.isConnected ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'
              }`}>
                {item.isConnected ? (
                  <><Check className="w-3 h-3" /> Подключено</>
                ) : (
                  'Не подключено'
                )}
              </div>
            </div>
            
            <p className="text-sm text-slate-500 leading-relaxed mb-6">
              {item.description}
            </p>

            <div className="flex items-center justify-between pt-6 border-t border-slate-50">
              <button className="text-xs font-bold text-slate-400 hover:text-slate-600 flex items-center gap-1">
                Документация <ExternalLink className="w-3 h-3" />
              </button>
              <button className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${
                item.isConnected 
                ? 'bg-slate-50 text-slate-600 hover:bg-slate-100' 
                : 'bg-indigo-600 text-white shadow-lg shadow-indigo-100 hover:bg-indigo-700'
              }`}>
                {item.isConnected ? 'Настроить' : 'Подключить'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* API Key Section */}
      <div className="bg-slate-900 rounded-[40px] p-10 text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-600 rounded-lg">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="text-2xl font-bold">API для разработчиков</h3>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Используйте наш API для автоматической генерации материалов вашего бренда прямо в ваших собственных приложениях или CMS.
            </p>
            <div className="flex gap-4 pt-4">
              <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center justify-between group cursor-pointer hover:bg-white/10 transition-all">
                <span className="font-mono text-sm text-slate-300">sk_live_51P2u8...</span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity">Копировать</span>
              </div>
              <button className="px-8 py-4 bg-white text-slate-900 rounded-2xl font-bold text-sm hover:bg-slate-100 transition-all">
                Обновить ключ
              </button>
            </div>
          </div>
          <div className="hidden lg:flex flex-col justify-center items-center border-l border-white/10 space-y-4">
             <div className="p-4 bg-white/5 rounded-full">
                <ShieldCheck className="w-8 h-8 text-indigo-400" />
             </div>
             <div className="text-center">
                <div className="font-bold">Безопасный доступ</div>
                <div className="text-xs text-slate-500">OAuth 2.0 & SSL encryption</div>
             </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 blur-[100px] rounded-full" />
      </div>
    </div>
  );
};

