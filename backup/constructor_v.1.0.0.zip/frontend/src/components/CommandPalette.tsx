import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, Command as CommandIcon, Rocket, 
  Layout, ShoppingBag, History, User, 
  Settings, Sparkles, Wand2, Plus,
  ChevronRight, ArrowRight, Zap,
  Globe, LayoutGrid
} from 'lucide-react';

interface Command {
  id: string;
  category: string;
  title: string;
  desc: string;
  icon: React.ReactNode;
  shortcut?: string;
  action: () => void;
}

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: any) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({ isOpen, onClose, onNavigate }) => {
  const [search, setSearch] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        isOpen ? onClose() : null; // Handled by parent but good to keep in mind
      }
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const commands: Command[] = [
    { 
      id: 'new-brand', 
      category: 'Действия', 
      title: 'Создать новый бренд', 
      desc: 'Запустить AI Onboarding', 
      icon: <Plus className="w-4 h-4" />, 
      shortcut: 'N',
      action: () => { onNavigate('onboarding'); onClose(); }
    },
    { 
      id: 'ai-gen-site', 
      category: 'AI Магия', 
      title: 'Сгенерировать сайт', 
      desc: 'Создать полную структуру страницы через ИИ', 
      icon: <Sparkles className="w-4 h-4 text-indigo-500" />, 
      shortcut: 'S',
      action: () => { console.log('AI Site Gen'); onClose(); }
    },
    { 
      id: 'go-dashboard', 
      category: 'Навигация', 
      title: 'В личный кабинет', 
      desc: 'Вернуться к списку проектов', 
      icon: <LayoutGrid className="w-4 h-4" />, 
      shortcut: 'D',
      action: () => { onNavigate('dashboard'); onClose(); }
    },
    { 
      id: 'open-store', 
      category: 'Навигация', 
      title: 'Открыть магазин', 
      desc: 'Поиск шаблонов и дополнений', 
      icon: <ShoppingBag className="w-4 h-4" />, 
      shortcut: 'M',
      action: () => { console.log('Open Store'); onClose(); }
    },
    { 
      id: 'open-history', 
      category: 'Действия', 
      title: 'История изменений', 
      desc: 'Просмотр версий бренда', 
      icon: <History className="w-4 h-4" />, 
      shortcut: 'H',
      action: () => { console.log('Open History'); onClose(); }
    },
    { 
      id: 'user-settings', 
      category: 'Аккаунт', 
      title: 'Настройки профиля', 
      desc: 'Управление данными и подпиской', 
      icon: <User className="w-4 h-4" />, 
      action: () => { console.log('Settings'); onClose(); }
    }
  ];

  const filteredCommands = commands.filter(cmd => 
    cmd.title.toLowerCase().includes(search.toLowerCase()) || 
    cmd.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[1000] flex items-start justify-center pt-32 p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="relative w-full max-w-2xl bg-white rounded-[32px] shadow-2xl overflow-hidden border border-slate-100"
          >
            {/* Search Input */}
            <div className="flex items-center px-6 py-5 border-b border-slate-100">
              <Search className="w-5 h-5 text-slate-400 mr-4" />
              <input 
                autoFocus
                type="text" 
                placeholder="Что вы хотите сделать? Начните вводить команду..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none text-lg text-slate-800 placeholder:text-slate-300"
              />
              <div className="flex items-center gap-1.5 px-2 py-1 bg-slate-50 border border-slate-100 rounded-lg text-[10px] font-black text-slate-400">
                ESC
              </div>
            </div>

            {/* Results */}
            <div className="max-h-[400px] overflow-y-auto p-3">
              {filteredCommands.length > 0 ? (
                <div className="space-y-6 py-2">
                  {Array.from(new Set(filteredCommands.map(c => c.category))).map(cat => (
                    <div key={cat} className="space-y-2">
                      <h3 className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">{cat}</h3>
                      <div className="space-y-1">
                        {filteredCommands.filter(c => c.category === cat).map(cmd => (
                          <button
                            key={cmd.id}
                            onClick={cmd.action}
                            className="w-full flex items-center justify-between px-4 py-3 rounded-2xl hover:bg-indigo-50 transition-all group"
                          >
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-white group-hover:text-indigo-600 transition-all shadow-sm">
                                {cmd.icon}
                              </div>
                              <div className="text-left">
                                <div className="text-sm font-bold text-slate-800 group-hover:text-indigo-900 transition-colors">{cmd.title}</div>
                                <div className="text-[10px] text-slate-400 font-medium">{cmd.desc}</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                               {cmd.shortcut && (
                                 <div className="flex items-center gap-1">
                                    <div className="px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[9px] font-black text-slate-400">⌘</div>
                                    <div className="px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[9px] font-black text-slate-400">{cmd.shortcut}</div>
                                 </div>
                               )}
                               <ChevronRight className="w-4 h-4 text-slate-200 group-hover:text-indigo-300 transition-colors" />
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center space-y-4">
                   <div className="w-16 h-16 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto">
                      <Zap className="w-8 h-8 text-slate-200" />
                   </div>
                   <div>
                      <p className="text-sm font-bold text-slate-800">Ничего не найдено</p>
                      <p className="text-xs text-slate-400">Попробуйте другой запрос или команду.</p>
                   </div>
                </div>
              )}
            </div>

            {/* Footer Tip */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 flex items-center justify-center gap-6">
               <div className="flex items-center gap-2">
                  <div className="px-1.5 py-0.5 bg-white border border-slate-200 rounded-md text-[9px] font-black text-slate-400">↑↓</div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Навигация</span>
               </div>
               <div className="flex items-center gap-2">
                  <div className="px-1.5 py-0.5 bg-white border border-slate-200 rounded-md text-[9px] font-black text-slate-400">ENTER</div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Выбрать</span>
               </div>
               <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest animate-pulse">Совет: Используйте ⌘ + K</span>
               </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

