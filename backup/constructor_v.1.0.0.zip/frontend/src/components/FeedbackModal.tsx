import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, MessageSquare, Star, Bug, Lightbulb, Heart, Send, CheckCircle2 } from 'lucide-react';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [rating, setRating] = useState(0);
  const [type, setType] = useState<'bug' | 'idea' | 'love' | null>(null);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    setSubmitted(true);
    setTimeout(() => {
      onClose();
      setSubmitted(false);
      setRating(0);
      setType(null);
      setComment('');
    }, 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-lg bg-white rounded-[40px] shadow-2xl overflow-hidden"
          >
            {submitted ? (
              <div className="p-16 text-center space-y-6">
                <div className="w-24 h-24 bg-emerald-50 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500" />
                </div>
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-slate-900">Спасибо!</h2>
                  <p className="text-slate-500 leading-relaxed">Ваш отзыв поможет нам сделать Constructor AI еще лучше.</p>
                </div>
              </div>
            ) : (
              <div className="p-10 space-y-10">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-50 rounded-xl">
                      <MessageSquare className="w-5 h-5 text-indigo-600" />
                    </div>
                    <h2 className="text-2xl font-bold text-slate-900">Обратная связь</h2>
                  </div>
                  <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-8">
                  {/* Rating */}
                  <div className="space-y-4 text-center">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Как вам наш сервис?</label>
                    <div className="flex justify-center gap-3">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <button
                          key={s}
                          onMouseEnter={() => setRating(s)}
                          className={`transition-all duration-300 ${s <= rating ? 'text-amber-400 scale-125' : 'text-slate-200 hover:text-amber-200'}`}
                        >
                          <Star className={`w-8 h-8 ${s <= rating ? 'fill-current' : ''}`} />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Feedback Type */}
                  <div className="grid grid-cols-3 gap-3">
                    <FeedbackTypeButton 
                      active={type === 'bug'} 
                      onClick={() => setType('bug')} 
                      icon={<Bug className="w-4 h-4" />} 
                      label="Баг" 
                      color="rose"
                    />
                    <FeedbackTypeButton 
                      active={type === 'idea'} 
                      onClick={() => setType('idea')} 
                      icon={<Lightbulb className="w-4 h-4" />} 
                      label="Идея" 
                      color="amber"
                    />
                    <FeedbackTypeButton 
                      active={type === 'love'} 
                      onClick={() => setType('love')} 
                      icon={<Heart className="w-4 h-4" />} 
                      label="Хвала" 
                      color="emerald"
                    />
                  </div>

                  {/* Comment */}
                  <div className="space-y-3">
                    <textarea 
                      placeholder="Расскажите подробнее..." 
                      className="w-full bg-slate-50 border border-slate-100 rounded-[24px] p-5 text-sm min-h-[120px] outline-none focus:bg-white focus:border-indigo-500 transition-all resize-none"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    />
                  </div>
                </div>

                <button 
                  onClick={handleSubmit}
                  disabled={!type || !rating}
                  className="w-full premium-button text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-indigo-100 disabled:opacity-50 disabled:grayscale transition-all"
                >
                  <Send className="w-4 h-4" /> Отправить отзыв
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const FeedbackTypeButton = ({ active, onClick, icon, label, color }: { active: boolean, onClick: () => void, icon: any, label: string, color: string }) => {
  const colors: any = {
    rose: 'text-rose-600 bg-rose-50 border-rose-100 shadow-rose-100',
    amber: 'text-amber-600 bg-amber-50 border-amber-100 shadow-amber-100',
    emerald: 'text-emerald-600 bg-emerald-50 border-emerald-100 shadow-emerald-100',
  };

  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${
        active 
        ? `${colors[color]} border-current shadow-lg scale-105` 
        : 'border-slate-50 text-slate-400 hover:border-slate-100 hover:bg-slate-50'
      }`}
    >
      {icon}
      <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
    </button>
  );
};

