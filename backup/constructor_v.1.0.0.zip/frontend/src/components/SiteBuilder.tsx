import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Layout, Plus, Trash2, ChevronUp, ChevronDown, 
  Settings, Eye, Save, Globe, Smartphone, Tablet, Monitor,
  Type, Image as ImageIcon, MousePointer2, Wand2,
  Undo2, Redo2, CheckCircle, ChevronLeft, Search, BarChart3, ShieldCheck, Share2,
  MessageSquare, CreditCard, Loader2
} from 'lucide-react';

interface Section {
  id: string;
  type: 'hero' | 'features' | 'about' | 'cta' | 'footer';
  content: any;
}

interface SiteBuilderProps {
  brandName: string;
  palette: string[];
  fonts: { primary: string; secondary: string };
  onClose: () => void;
}

export const SiteBuilder: React.FC<SiteBuilderProps> = ({ brandName, palette, fonts, onClose }) => {
  const [viewport, setViewport] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [showSettings, setShowSettings] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [sections, setSections] = useState<Section[]>([
    {
      id: 'hero-1',
      type: 'hero',
      content: {
        title: `Добро пожаловать в ${brandName}`,
        description: 'Мы создаем будущее вместе с вами. Наш инновационный подход помогает достигать невероятных результатов.',
        buttonText: 'Начать сейчас',
      }
    },
    {
      id: 'features-1',
      type: 'features',
      content: {
        title: 'Наши преимущества',
        items: [
          { title: 'Инновации', desc: 'Используем передовые технологии.' },
          { title: 'Качество', desc: 'Высочайшие стандарты во всем.' },
          { title: 'Скорость', desc: 'Быстрая реализация идей.' },
        ]
      }
    },
    {
      id: 'cta-1',
      type: 'cta',
      content: {
        title: 'Готовы к переменам?',
        buttonText: 'Связаться с нами'
      }
    }
  ]);

  const generateFullSite = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setSections([
        {
          id: 'hero-ai',
          type: 'hero',
          content: {
            title: `${brandName}: Новая эра вашего бизнеса`,
            description: 'Мы объединили лучшие практики дизайна и искусственного интеллекта, чтобы создать идеальное решение для вас.',
            buttonText: 'Начать путь',
          }
        },
        {
          id: 'features-ai',
          type: 'features',
          content: {
            title: 'Почему выбирают нас',
            items: [
              { title: 'Скорость ИИ', desc: 'Генерация контента за секунды.' },
              { title: 'Премиум Дизайн', desc: 'Пиксель-перфект верстка.' },
              { title: 'Аналитика', desc: 'Полный контроль над трафиком.' },
            ]
          }
        },
        {
          id: 'cta-ai',
          type: 'cta',
          content: {
            title: 'Готовы взлететь?',
            buttonText: 'Запустить проект'
          }
        }
      ]);
      setIsGenerating(false);
      alert('AI сгенерировал полную структуру сайта!');
    }, 2500);
  };

  const removeSection = (id: string) => {
    setSections(prev => prev.filter(s => s.id !== id));
  };

  const moveSection = (id: string, direction: 'up' | 'down') => {
    const index = sections.findIndex(s => s.id === id);
    if ((direction === 'up' && index === 0) || (direction === 'down' && index === sections.length - 1)) return;
    
    const newSections = [...sections];
    const offset = direction === 'up' ? -1 : 1;
    [newSections[index], newSections[index + offset]] = [newSections[index + offset], newSections[index]];
    setSections(newSections);
  };

  const exportHTML = () => {
    const htmlContent = `
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${brandName} - Официальный сайт</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-slate-50">
    ${sections.map(s => {
      if (s.type === 'hero') return `
        <section class="py-24 px-12 text-center" style="background-color: ${palette[2]}10">
            <h1 class="text-5xl font-black text-slate-900 mb-8">${s.content.title}</h1>
            <p class="text-xl text-slate-600 max-w-2xl mx-auto mb-10">${s.content.description}</p>
            <button class="px-8 py-4 rounded-full font-bold text-white shadow-xl" style="background: linear-gradient(135deg, ${palette[0]}, ${palette[1]})">
                ${s.content.buttonText}
            </button>
        </section>
      `;
      return '';
    }).join('')}
</body>
</html>`;
    
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    a.click();
    alert('Сайт успешно экспортирован в HTML!');
  };

  return (
    <div className="fixed inset-0 bg-slate-100 z-[100] flex flex-col overflow-hidden select-none">
      {/* Top Bar */}
      <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 z-20">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <ChevronLeft className="w-5 h-5 text-slate-500" />
          </button>
          <div className="h-4 w-px bg-slate-200" />
          <h2 className="font-bold text-slate-800 text-sm">Конструктор сайта: {brandName}</h2>
        </div>

        {/* Viewport Toggles */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl">
          <ViewportButton active={viewport === 'mobile'} onClick={() => setViewport('mobile')} icon={<Smartphone className="w-4 h-4" />} />
          <ViewportButton active={viewport === 'tablet'} onClick={() => setViewport('tablet')} icon={<Tablet className="w-4 h-4" />} />
          <ViewportButton active={viewport === 'desktop'} onClick={() => setViewport('desktop')} icon={<Monitor className="w-4 h-4" />} />
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={generateFullSite}
            disabled={isGenerating}
            className="flex items-center gap-2 px-4 py-1.5 text-xs font-black bg-indigo-600 text-white rounded-lg shadow-lg hover:bg-indigo-700 transition-all disabled:opacity-50"
          >
            {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            AI Генерация
          </button>
          <div className="w-px h-6 bg-slate-100 mx-1" />
          <button 
            onClick={() => setShowSettings(true)}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all"
          >
            <Settings className="w-5 h-5" />
          </button>
          <div className="w-px h-6 bg-slate-100 mx-1" />
          <button className="flex items-center gap-2 px-3 py-1.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
            <Eye className="w-4 h-4" /> Предпросмотр
          </button>
          <button 
            onClick={exportHTML}
            className="flex items-center gap-2 px-4 py-1.5 text-sm font-bold bg-indigo-600 text-white rounded-lg shadow-lg hover:bg-indigo-700 transition-all"
          >
            <Globe className="w-4 h-4" /> Опубликовать
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Library Sidebar */}
        <aside className="w-72 bg-white border-r border-slate-200 flex flex-col z-10">
          <div className="p-4 border-b border-slate-100">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Библиотека блоков</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <BlockTemplate title="Hero" icon={<Layout className="w-4 h-4" />} />
            <BlockTemplate title="О нас" icon={<Type className="w-4 h-4" />} />
            <BlockTemplate title="Услуги" icon={<Wand2 className="w-4 h-4" />} />
            <BlockTemplate title="Галерея" icon={<ImageIcon className="w-4 h-4" />} />
            <BlockTemplate title="Отзывы" icon={<MessageSquare className="w-4 h-4" />} />
            <BlockTemplate title="Тарифы" icon={<CreditCard className="w-4 h-4" />} />
            <BlockTemplate title="Контакты" icon={<MousePointer2 className="w-4 h-4" />} />
          </div>
          <div className="p-4 bg-slate-50 border-t border-slate-200">
            <button className="w-full flex items-center justify-center gap-2 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:shadow-md transition-all">
              <Plus className="w-4 h-4" /> Добавить блок
            </button>
          </div>
        </aside>

        {/* Builder Canvas */}
        <div className="flex-1 overflow-y-auto bg-slate-200/50 p-8 scroll-smooth">
          <div className={`mx-auto transition-all duration-500 bg-white shadow-2xl rounded-sm overflow-hidden flex flex-col ${
            viewport === 'mobile' ? 'w-[375px]' : viewport === 'tablet' ? 'w-[768px]' : 'w-full max-w-[1200px]'
          }`}>
            <AnimatePresence initial={false}>
              {sections.map((section, index) => (
                <motion.div
                  key={section.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="relative group border-b border-slate-50 last:border-0"
                >
                  {/* Section UI Controls */}
                  <div className="absolute left-[-60px] top-1/2 -translate-y-1/2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => moveSection(section.id, 'up')} className="p-2 bg-white rounded-lg shadow-md border border-slate-100 hover:text-indigo-600"><ChevronUp className="w-4 h-4" /></button>
                    <button onClick={() => moveSection(section.id, 'down')} className="p-2 bg-white rounded-lg shadow-md border border-slate-100 hover:text-indigo-600"><ChevronDown className="w-4 h-4" /></button>
                  </div>
                  
                  <div className="absolute right-[-60px] top-1/2 -translate-y-1/2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2 bg-white rounded-lg shadow-md border border-slate-100 hover:text-indigo-600"><Settings className="w-4 h-4" /></button>
                    <button onClick={() => removeSection(section.id)} className="p-2 bg-white rounded-lg shadow-md border border-slate-100 hover:text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </div>

                  {/* Section Content */}
                  <div className="relative">
                    {section.type === 'hero' && (
                      <div className="py-24 px-12 text-center space-y-8" style={{ backgroundColor: palette[2] + '10' }}>
                        <h1 className="text-5xl font-black text-slate-900 leading-tight" style={{ fontFamily: fonts.primary }}>
                          {section.content.title}
                        </h1>
                        <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed" style={{ fontFamily: fonts.secondary }}>
                          {section.content.description}
                        </p>
                        <button className="px-8 py-4 rounded-full font-bold text-white shadow-xl hover:scale-105 transition-transform" style={{ background: `linear-gradient(135deg, ${palette[0]}, ${palette[1]})` }}>
                          {section.content.buttonText}
                        </button>
                      </div>
                    )}

                    {section.type === 'features' && (
                      <div className="py-20 px-12 bg-white">
                        <h2 className="text-3xl font-bold text-center mb-12 text-slate-900" style={{ fontFamily: fonts.primary }}>{section.content.title}</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                          {section.content.items.map((item: any, i: number) => (
                            <div key={i} className="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:shadow-xl transition-all">
                              <div className="w-12 h-12 rounded-2xl mb-4 flex items-center justify-center text-white" style={{ backgroundColor: palette[i % palette.length] }}>
                                <CheckCircle className="w-6 h-6" />
                              </div>
                              <h4 className="text-xl font-bold mb-2 text-slate-800">{item.title}</h4>
                              <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {section.type === 'cta' && (
                      <div className="py-16 px-12 text-center bg-slate-900 text-white">
                        <h2 className="text-3xl font-bold mb-6" style={{ fontFamily: fonts.primary }}>{section.content.title}</h2>
                        <button className="px-8 py-3 rounded-xl font-bold bg-white text-slate-900 hover:bg-slate-100 transition-colors">
                          {section.content.buttonText}
                        </button>
                      </div>
                    )}
                    
                    {/* Add Section Button between blocks */}
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all z-10">
                      <button className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110">
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* Right Settings Sidebar */}
        <aside className="w-72 bg-white border-l border-slate-200 flex flex-col p-4 gap-6 z-10 overflow-y-auto">
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Настройки сайта</h3>
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-3">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Тема бренда</div>
                <div className="flex gap-2">
                  {palette.map(color => (
                    <div key={color} className="w-6 h-6 rounded-full border border-white shadow-sm" style={{ backgroundColor: color }} />
                  ))}
                </div>
                <p className="text-xs text-slate-500">Шрифт: {fonts.primary}</p>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase">SEO Название</label>
                <input type="text" className="w-full p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs" value={`${brandName} - Официальный сайт`} readOnly />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Фавикон</label>
                <div className="w-12 h-12 bg-slate-100 border-2 border-dashed border-slate-200 rounded-xl flex items-center justify-center">
                  <ImageIcon className="w-6 h-6 text-slate-300" />
                </div>
              </div>
            </div>
          </div>

          <div className="h-px bg-slate-100" />

          <div className="space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Интеграции</h3>
            <button className="w-full flex items-center justify-between p-3 bg-slate-50 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors">
              <span>Google Analytics</span>
              <Plus className="w-3 h-3" />
            </button>
            <button className="w-full flex items-center justify-between p-3 bg-slate-50 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors">
              <span>Яндекс Метрика</span>
              <Plus className="w-3 h-3" />
            </button>
          </div>
        </aside>
      </div>
      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <div className="fixed inset-0 z-[600] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="p-10">
                <div className="flex justify-between items-center mb-10">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Настройки сайта</h2>
                    <p className="text-sm text-slate-500">SEO, аналитика и технические параметры</p>
                  </div>
                  <button onClick={() => setShowSettings(false)} className="p-2 hover:bg-slate-100 rounded-full">
                    <X className="w-6 h-6 text-slate-400" />
                  </button>
                </div>

                <div className="space-y-8">
                  <div className="space-y-4">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                      <Search className="w-3 h-3" /> SEO Оптимизация
                    </label>
                    <div className="space-y-4">
                      <input 
                        type="text" 
                        placeholder="Заголовок страницы (Title)" 
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm focus:bg-white focus:border-indigo-500 outline-none transition-all"
                        defaultValue={brandName}
                      />
                      <textarea 
                        placeholder="Описание (Description)" 
                        rows={3}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm focus:bg-white focus:border-indigo-500 outline-none transition-all resize-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                      <BarChart3 className="w-3 h-3" /> Аналитика
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-indigo-200 transition-all cursor-pointer">
                        <div className="font-bold text-sm mb-1">Яндекс.Метрика</div>
                        <div className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">ID: Не указано</div>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-indigo-200 transition-all cursor-pointer">
                        <div className="font-bold text-sm mb-1">Google Analytics</div>
                        <div className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">ID: Не указано</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 bg-indigo-50 rounded-3xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-indigo-600 rounded-2xl text-white">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-bold text-indigo-900 text-sm">SSL Сертификат</div>
                        <div className="text-xs text-indigo-600/70">Ваш сайт защищен по протоколу HTTPS</div>
                      </div>
                    </div>
                    <div className="w-12 h-6 bg-indigo-600 rounded-full relative">
                       <div className="absolute right-1 top-1 bottom-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                    </div>
                  </div>
                </div>

                <div className="mt-10 pt-8 border-t border-slate-100 flex justify-end gap-3">
                   <button onClick={() => setShowSettings(false)} className="px-6 py-3 text-sm font-bold text-slate-400 hover:text-slate-600 transition-colors">Отмена</button>
                   <button className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all">Сохранить</button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

// Internal Sub-components
const ViewportButton = ({ active, onClick, icon }: { active: boolean, onClick: () => void, icon: any }) => (
  <button 
    onClick={onClick}
    className={`p-2 rounded-lg transition-all ${active ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
  >
    {icon}
  </button>
);

const BlockTemplate = ({ title, icon }: { title: string, icon: any }) => (
  <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex items-center gap-3 cursor-grab active:cursor-grabbing hover:border-indigo-200 hover:bg-white transition-all group">
    <div className="p-2 bg-white rounded-lg border border-slate-100 group-hover:text-indigo-600">
      {icon}
    </div>
    <span className="text-sm font-bold text-slate-700">{title}</span>
  </div>
);

