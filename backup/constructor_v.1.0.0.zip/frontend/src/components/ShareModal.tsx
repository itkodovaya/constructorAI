import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Copy, Mail, Users, Shield, Globe, Link as LinkIcon, Check } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  brandName: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, brandName }) => {
  const [copied, setCopied] = useState(false);
  const [email, setEmail] = useState('');

  const handleCopy = () => {
    navigator.clipboard.writeText(`https://constructor.ai/share/project-${Date.now()}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const collaborators = [
    { name: 'Вы (Владелец)', role: 'Admin', initial: 'В' },
    { name: 'Алексей Дизайнер', role: 'Editor', initial: 'А' },
    { name: 'Мария Маркетолог', role: 'Viewer', initial: 'М' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-lg bg-white rounded-[32px] shadow-2xl overflow-hidden"
          >
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900">Поделиться проектом</h2>
                  <p className="text-sm text-slate-500">{brandName}</p>
                </div>
                <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              {/* Invite Link */}
              <div className="space-y-4 mb-10">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Ссылка для доступа</label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm text-slate-600 truncate flex items-center gap-2">
                    <Globe className="w-4 h-4 text-slate-400" />
                    <span>constructor.ai/share/prj-842...</span>
                  </div>
                  <button 
                    onClick={handleCopy}
                    className="bg-slate-900 text-white px-4 rounded-xl font-bold text-sm hover:bg-slate-800 transition-all flex items-center gap-2"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    {copied ? 'Готово' : 'Копировать'}
                  </button>
                </div>
              </div>

              {/* Invite by Email */}
              <div className="space-y-4 mb-10">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Пригласить по почте</label>
                <div className="flex gap-2">
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@example.com"
                    className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 transition-colors"
                  />
                  <button className="bg-indigo-600 text-white px-6 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all">
                    Отправить
                  </button>
                </div>
              </div>

              {/* Collaborators List */}
              <div className="space-y-4">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Кто имеет доступ</label>
                <div className="space-y-3">
                  {collaborators.map((user) => (
                    <div key={user.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100/50">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center font-bold text-slate-400 text-xs">
                          {user.initial}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-800">{user.name}</p>
                          <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">{user.role}</p>
                        </div>
                      </div>
                      <Shield className="w-4 h-4 text-slate-300" />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-50 p-6 border-t border-slate-100 flex items-center justify-center gap-2">
              <Users className="w-4 h-4 text-slate-400" />
              <span className="text-xs font-medium text-slate-500">Управление ролями доступно в версии Pro</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

