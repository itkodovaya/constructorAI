import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, Search, ShoppingBag, Star, Download, 
  TrendingUp, Clock, Heart, ArrowUpRight, 
  ChevronRight, Layout, Palette, Type, 
  Image as ImageIcon, Sparkles, Award, ShoppingCart,
  Filter, Tag, ShieldCheck
} from 'lucide-react';

interface Template {
  id: string;
  title: string;
  author: string;
  price: string;
  rating: number;
  category: string;
  image: string;
  isPremium: boolean;
  isNew?: boolean;
}

const templates: Template[] = [
  {
    id: '1',
    title: 'Modern SaaS Landing Page',
    author: 'DesignPro',
    price: '29',
    rating: 4.9,
    category: 'Сайты',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=400',
    isPremium: true,
    isNew: true
  },
  {
    id: '2',
    title: 'Minimalist Portfolio Kit',
    author: 'ArtStudio',
    price: '0',
    rating: 4.7,
    category: 'Бренд-кит',
    image: 'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&q=80&w=400',
    isPremium: false
  },
  {
    id: '3',
    title: 'E-commerce UI Elements',
    author: 'ShopUI',
    price: '45',
    rating: 5.0,
    category: 'Графика',
    image: 'https://images.unsplash.com/photo-1551288049-bbbda536339a?auto=format&fit=crop&q=80&w=400',
    isPremium: true
  },
  {
    id: '4',
    title: 'Instagram Post Pack: Neon',
    author: 'SocialKing',
    price: '0',
    rating: 4.5,
    category: 'Соцсети',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=400',
    isPremium: false,
    isNew: true
  },
  {
    id: '5',
    title: 'Pitch Deck: Tech Startups',
    author: 'SlideMaster',
    price: '19',
    rating: 4.8,
    category: 'Презентации',
    image: 'https://images.unsplash.com/photo-1542744094-24638eff58bb?auto=format&fit=crop&q=80&w=400',
    isPremium: true
  }
];

const categories = [
  { id: 'all', icon: <ShoppingBag className="w-4 h-4" />, label: 'Все' },
  { id: 'sites', icon: <Layout className="w-4 h-4" />, label: 'Сайты' },
  { id: 'brands', icon: <Palette className="w-4 h-4" />, label: 'Бренд-киты' },
  { id: 'presentation', icon: <Type className="w-4 h-4" />, label: 'Презентации' },
  { id: 'graphics', icon: <ImageIcon className="w-4 h-4" />, label: 'Графика' },
];

export const TemplateStore: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [search, setSearch] = useState('');

  return (
    <div className="fixed inset-0 z-[500] bg-white flex flex-col overflow-hidden">
      {/* Header */}
      <header className="h-20 bg-white border-b border-slate-100 flex items-center justify-between px-8 flex-shrink-0">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-100">
            <ShoppingBag className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Магазин шаблонов</h2>
            <p className="text-sm text-slate-500">Дополните свой проект профессиональными наработками</p>
          </div>
        </div>

        <div className="flex-1 max-w-xl mx-12">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
            <input 
              type="text" 
              placeholder="Поиск шаблонов, блоков, шрифтов..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-4 py-3 text-sm focus:bg-white focus:border-indigo-500 outline-none transition-all"
            />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 rounded-xl">
            <Award className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-bold text-amber-700">Стать автором</span>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Categories Sidebar */}
        <aside className="w-72 border-r border-slate-100 p-8 flex flex-col flex-shrink-0 bg-slate-50/20">
          <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6 px-2">Категории</h3>
          <nav className="space-y-1 mb-12">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                  selectedCategory === cat.id 
                  ? 'bg-white shadow-sm border border-slate-100 text-indigo-600' 
                  : 'text-slate-500 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`${selectedCategory === cat.id ? 'text-indigo-600' : 'text-slate-400'}`}>
                    {cat.icon}
                  </div>
                  <span className="text-sm font-bold">{cat.label}</span>
                </div>
                <ChevronRight className={`w-4 h-4 transition-transform ${selectedCategory === cat.id ? 'rotate-0 opacity-100' : 'rotate-0 opacity-0'}`} />
              </button>
            ))}
          </nav>

          <div className="mt-auto p-6 bg-indigo-600 rounded-[32px] text-white relative overflow-hidden group cursor-pointer shadow-xl shadow-indigo-200">
             <div className="relative z-10">
                <h4 className="font-bold mb-1">Constructor Pro</h4>
                <p className="text-[10px] text-white/80 leading-relaxed mb-4">Разблокируйте все премиум шаблоны по подписке.</p>
                <button className="w-full py-2 bg-white text-indigo-600 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-50 transition-colors">
                  Узнать больше
                </button>
             </div>
             <Sparkles className="absolute -right-4 -bottom-4 w-24 h-24 text-white/10 group-hover:scale-125 transition-transform duration-700" />
          </div>
        </aside>

        {/* Main Store Area */}
        <main className="flex-1 overflow-y-auto p-8 bg-white">
          <div className="max-w-6xl mx-auto space-y-10">
            {/* Featured Banner */}
            <div className="relative h-64 rounded-[40px] overflow-hidden bg-slate-900 group cursor-pointer shadow-2xl">
               <img 
                 src="https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&q=80&w=1200" 
                 alt="Featured" 
                 className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
               <div className="absolute bottom-10 left-10 text-white max-w-md">
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 bg-indigo-600 rounded-lg text-[10px] font-bold uppercase tracking-widest mb-4">
                     Подборка недели
                  </div>
                  <h2 className="text-3xl font-black mb-2">Наборы для маркетплейсов</h2>
                  <p className="text-white/70 text-sm">Сгенерируйте сотни карточек товаров в едином стиле вашего бренда.</p>
               </div>
               <div className="absolute top-10 right-10">
                  <button className="p-4 bg-white/10 backdrop-blur-md rounded-2xl text-white hover:bg-white/20 transition-all">
                     <ArrowUpRight className="w-6 h-6" />
                  </button>
               </div>
            </div>

            {/* Template Grid */}
            <div className="space-y-6">
               <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                     <TrendingUp className="w-5 h-5 text-indigo-600" />
                     <h3 className="text-xl font-bold text-slate-900">Популярное</h3>
                  </div>
                  <button className="flex items-center gap-2 text-sm font-bold text-slate-400 hover:text-indigo-600 transition-colors">
                     Все <ChevronRight className="w-4 h-4" />
                  </button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {templates.map((tpl) => (
                    <motion.div 
                      key={tpl.id}
                      whileHover={{ y: -5 }}
                      className="bg-white rounded-[32px] border border-slate-100 shadow-sm hover:shadow-2xl transition-all group overflow-hidden"
                    >
                       <div className="aspect-[4/3] relative overflow-hidden">
                          <img src={tpl.image} alt={tpl.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                          <div className="absolute inset-0 bg-slate-900/10 group-hover:bg-slate-900/0 transition-colors" />
                          
                          <div className="absolute top-4 left-4 flex gap-2">
                             {tpl.isPremium && (
                                <div className="p-2 bg-amber-400 text-white rounded-lg shadow-lg">
                                   <Star className="w-3 h-3 fill-current" />
                                </div>
                             )}
                             {tpl.isNew && (
                                <div className="px-2 py-1 bg-indigo-600 text-white text-[8px] font-bold rounded-md uppercase tracking-widest shadow-lg">
                                   New
                                </div>
                             )}
                          </div>

                          <button className="absolute bottom-4 right-4 p-3 bg-white text-slate-900 rounded-xl shadow-xl translate-y-12 group-hover:translate-y-0 transition-transform duration-300 hover:bg-indigo-600 hover:text-white">
                             <ShoppingCart className="w-5 h-5" />
                          </button>
                       </div>

                       <div className="p-6">
                          <div className="flex justify-between items-start mb-2">
                             <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{tpl.category}</div>
                             <div className="flex items-center gap-1 text-[10px] font-bold text-amber-500">
                                <Star className="w-3 h-3 fill-current" /> {tpl.rating}
                             </div>
                          </div>
                          <h4 className="text-lg font-bold text-slate-900 mb-1 leading-tight group-hover:text-indigo-600 transition-colors">{tpl.title}</h4>
                          <p className="text-xs text-slate-400 mb-4">Автор: {tpl.author}</p>
                          
                          <div className="flex items-center justify-between border-t border-slate-50 pt-4">
                             <div className="text-xl font-black text-slate-900">
                                {tpl.price === '0' ? 'Free' : `$${tpl.price}`}
                             </div>
                             <button className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                               tpl.price === '0' 
                               ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' 
                               : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white'
                             }`}>
                                {tpl.price === '0' ? 'Установить' : 'Купить'}
                             </button>
                          </div>
                       </div>
                    </motion.div>
                  ))}
               </div>
            </div>
          </div>
        </main>
      </div>

      {/* Footer Legal/Compliance (Stage 4.4) */}
      <footer className="h-12 bg-slate-50 border-t border-slate-100 px-8 flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] flex-shrink-0">
         <div className="flex gap-6">
            <a href="#" className="hover:text-indigo-600 transition-colors">Пользовательское соглашение</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Политика конфиденциальности</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Лицензионный договор</a>
         </div>
         <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Соответствует ФЗ-152 о персональных данных</span>
         </div>
      </footer>
    </div>
  );
};

