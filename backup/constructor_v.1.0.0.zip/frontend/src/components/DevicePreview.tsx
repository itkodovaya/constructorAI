import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Monitor, Smartphone, Tablet, X, Globe, ShieldCheck, Zap } from 'lucide-react';

interface DevicePreviewProps {
  isOpen: boolean;
  onClose: () => void;
  brandName: string;
  palette: string[];
}

export const DevicePreview: React.FC<DevicePreviewProps> = ({ isOpen, onClose, brandName, palette }) => {
  const [device, setDevice] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');

  const devices = [
    { id: 'mobile', icon: <Smartphone className="w-4 h-4" />, label: 'Мобильный' },
    { id: 'tablet', icon: <Tablet className="w-4 h-4" />, label: 'Планшет' },
    { id: 'desktop', icon: <Monitor className="w-4 h-4" />, label: 'Десктоп' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[400] bg-slate-900 flex flex-col">
          {/* Header */}
          <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-8">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-full text-[10px] font-bold uppercase tracking-widest border border-emerald-500/20">
                <Globe className="w-3 h-3" /> Preview Mode
              </div>
              <h2 className="text-white font-bold text-sm">{brandName} - Предпросмотр</h2>
            </div>

            <div className="flex items-center bg-slate-900 rounded-xl p-1 border border-slate-700">
              {devices.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setDevice(d.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                    device === d.id 
                    ? 'bg-slate-700 text-white shadow-lg' 
                    : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {d.icon}
                  <span className="hidden md:inline">{d.label}</span>
                </button>
              ))}
            </div>

            <button onClick={onClose} className="p-2 text-slate-400 hover:text-white transition-colors">
              <X className="w-6 h-6" />
            </button>
          </header>

          {/* Canvas Area */}
          <main className="flex-1 bg-slate-900 p-8 flex items-center justify-center overflow-hidden">
            <motion.div
              layout
              className={`bg-white shadow-2xl overflow-hidden relative transition-all duration-500 ease-in-out ${
                device === 'mobile' ? 'w-[375px] h-[667px] rounded-[40px] border-[12px] border-slate-800' :
                device === 'tablet' ? 'w-[768px] h-[1024px] rounded-[30px] border-[12px] border-slate-800' :
                'w-full h-full rounded-xl border border-slate-700'
              }`}
            >
              {/* Fake Content */}
              <div className="h-full overflow-y-auto bg-slate-50">
                <div className="p-12 space-y-12">
                   <div className="flex justify-between items-center">
                      <div className="font-black text-2xl tracking-tighter" style={{ color: palette[0] }}>{brandName}</div>
                      <div className="flex gap-4">
                         <div className="w-8 h-1 bg-slate-200 rounded" />
                         <div className="w-8 h-1 bg-slate-200 rounded" />
                      </div>
                   </div>

                   <div className="py-12 space-y-6">
                      <h1 className="text-4xl md:text-6xl font-black text-slate-900 leading-tight">Будущее вашего бизнеса начинается здесь</h1>
                      <p className="text-slate-500 text-lg max-w-xl">Используйте силу искусственного интеллекта для создания бренда за считанные секунды.</p>
                      <button className="px-8 py-4 rounded-full font-bold text-white shadow-2xl" style={{ background: `linear-gradient(135deg, ${palette[0]}, ${palette[1]})` }}>
                        Начать бесплатно
                      </button>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-12">
                      <div className="p-8 bg-white rounded-[32px] border border-slate-100 shadow-sm space-y-4">
                        <Zap className="w-8 h-8 text-amber-500" />
                        <h3 className="text-xl font-bold">Быстрый старт</h3>
                        <p className="text-slate-400 text-sm">Генерация полного пакета материалов за 30 секунд.</p>
                      </div>
                      <div className="p-8 bg-white rounded-[32px] border border-slate-100 shadow-sm space-y-4">
                        <ShieldCheck className="w-8 h-8 text-emerald-500" />
                        <h3 className="text-xl font-bold">Профессионально</h3>
                        <p className="text-slate-400 text-sm">Дизайн на уровне топовых агентств мира.</p>
                      </div>
                   </div>
                </div>
              </div>

              {/* Device Specific Elements */}
              {device === 'mobile' && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-800 rounded-b-2xl" />
              )}
            </motion.div>
          </main>

          {/* Footer Controls */}
          <footer className="h-20 bg-slate-800 border-t border-slate-700 flex items-center justify-center gap-8 px-8">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-500 uppercase">Оптимизация:</span>
              <div className="flex gap-1">
                {[1,2,3,4,5].map(i => <div key={i} className="w-4 h-1 bg-emerald-500 rounded-full" />)}
              </div>
              <span className="text-xs font-bold text-emerald-400">100/100 SEO</span>
            </div>
            <button className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20">
              Опубликовать в облако
            </button>
          </footer>
        </div>
      )}
    </AnimatePresence>
  );
};

