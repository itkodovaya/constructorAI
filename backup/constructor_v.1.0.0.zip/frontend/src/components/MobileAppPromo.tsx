import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Smartphone, Apple, Play, QrCode, Download, Sparkles, Zap, Globe } from 'lucide-react';

interface MobileAppPromoProps {
  onClose: () => void;
}

export const MobileAppPromo: React.FC<MobileAppPromoProps> = ({ onClose }) => {
  const [selectedPlatform, setSelectedPlatform] = useState<'ios' | 'android' | null>(null);

  return (
    <div className="fixed inset-0 z-[1200] bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-4xl bg-white rounded-[40px] shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-12 text-white">
          <button
            onClick={onClose}
            className="absolute top-6 right-6 w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center hover:bg-white/30 transition-all"
          >
            <span className="text-2xl">×</span>
          </button>
          
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-widest mb-6">
              <Sparkles className="w-3 h-3" /> Скоро в App Store и Google Play
            </div>
            <h2 className="text-4xl font-black mb-4">Constructor AI в вашем кармане</h2>
            <p className="text-lg text-white/90 leading-relaxed">
              Создавайте бренды, редактируйте графику и публикуйте контент прямо со смартфона. 
              Полный доступ ко всем функциям платформы в мобильном формате.
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="p-12 grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left: Features */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">Возможности мобильного приложения</h3>
              
              <div className="space-y-4">
                {[
                  { icon: <Zap className="w-5 h-5 text-amber-500" />, title: 'Мгновенная генерация', desc: 'AI создает логотипы и материалы за секунды' },
                  { icon: <Sparkles className="w-5 h-5 text-indigo-500" />, title: 'Редактор на ходу', desc: 'Полнофункциональный графический редактор' },
                  { icon: <Globe className="w-5 h-5 text-emerald-500" />, title: 'Публикация в один клик', desc: 'Публикуйте в соцсети прямо из приложения' },
                  { icon: <Download className="w-5 h-5 text-rose-500" />, title: 'Офлайн режим', desc: 'Работайте без интернета с синхронизацией' },
                ].map((feature, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-start gap-4 p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-colors"
                  >
                    <div className="p-2 bg-white rounded-xl shadow-sm">{feature.icon}</div>
                    <div>
                      <div className="font-bold text-slate-900 mb-1">{feature.title}</div>
                      <div className="text-sm text-slate-500">{feature.desc}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Notify Me Button */}
            <div className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-3xl border border-indigo-100">
              <h4 className="font-bold text-slate-900 mb-2">Уведомить о запуске</h4>
              <p className="text-sm text-slate-600 mb-4">Получите уведомление, когда приложение будет доступно</p>
              <div className="flex gap-3">
                <input
                  type="email"
                  placeholder="Ваш email"
                  className="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg">
                  Подписаться
                </button>
              </div>
            </div>
          </div>

          {/* Right: Download Options */}
          <div className="space-y-6">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-32 h-32 bg-slate-50 rounded-3xl mb-6 relative">
                <QrCode className="w-16 h-16 text-slate-300" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-24 h-24 bg-white border-2 border-slate-200 rounded-xl" />
                </div>
              </div>
              <p className="text-sm text-slate-500 mb-8">Отсканируйте QR-код для скачивания</p>
            </div>

            {/* Platform Buttons */}
            <div className="space-y-4">
              <button
                onClick={() => setSelectedPlatform('ios')}
                className={`w-full p-6 rounded-2xl border-2 transition-all flex items-center justify-between ${
                  selectedPlatform === 'ios' 
                    ? 'border-indigo-600 bg-indigo-50 shadow-lg' 
                    : 'border-slate-200 hover:border-indigo-200 bg-white'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center">
                    <Apple className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-slate-900">iOS App Store</div>
                    <div className="text-sm text-slate-500">Для iPhone и iPad</div>
                  </div>
                </div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Скоро</div>
              </button>

              <button
                onClick={() => setSelectedPlatform('android')}
                className={`w-full p-6 rounded-2xl border-2 transition-all flex items-center justify-between ${
                  selectedPlatform === 'android' 
                    ? 'border-indigo-600 bg-indigo-50 shadow-lg' 
                    : 'border-slate-200 hover:border-indigo-200 bg-white'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center">
                    <Play className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-slate-900">Google Play</div>
                    <div className="text-sm text-slate-500">Для Android устройств</div>
                  </div>
                </div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Скоро</div>
              </button>
            </div>

            {/* Beta Program */}
            <div className="p-6 bg-amber-50 rounded-2xl border border-amber-100">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-amber-100 rounded-lg">
                  <Sparkles className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <div className="font-bold text-amber-900 mb-1">Бета-программа</div>
                  <p className="text-sm text-amber-700 mb-3">
                    Станьте одним из первых пользователей мобильного приложения
                  </p>
                  <button className="text-xs font-bold text-amber-600 uppercase tracking-widest hover:text-amber-700">
                    Подать заявку →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

