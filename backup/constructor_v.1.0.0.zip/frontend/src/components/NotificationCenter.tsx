import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, Sparkles, CheckCircle2, AlertCircle, Clock, X } from 'lucide-react';

interface Notification {
  id: string;
  type: 'ai' | 'success' | 'warning';
  title: string;
  desc: string;
  time: string;
  isRead: boolean;
}

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({ isOpen, onClose }) => {
  const notifications: Notification[] = [
    {
      id: '1',
      type: 'ai',
      title: 'AI Генерация завершена',
      desc: 'Ваш лендинг оптимизирован для мобильных устройств.',
      time: '2 мин назад',
      isRead: false
    },
    {
      id: '2',
      type: 'success',
      title: 'Экспорт успешен',
      desc: 'Файл презентации готов к скачиванию в PDF.',
      time: '1 час назад',
      isRead: true
    },
    {
      id: '3',
      type: 'warning',
      title: 'Лимит генераций',
      desc: 'У вас осталось 2 генерации на этом тарифе.',
      time: '3 часа назад',
      isRead: true
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed top-20 right-12 z-[550] w-96">
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="bg-white rounded-[32px] shadow-2xl border border-slate-100 overflow-hidden"
          >
            <div className="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-100">
                  <Bell className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-bold text-slate-900">Уведомления</h3>
              </div>
              <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded-full transition-colors text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-[400px] overflow-y-auto">
              {notifications.map((n) => (
                <div 
                  key={n.id}
                  className={`p-5 flex gap-4 border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors cursor-pointer relative ${!n.isRead ? 'bg-indigo-50/20' : ''}`}
                >
                  {!n.isRead && (
                    <div className="absolute top-6 right-6 w-2 h-2 bg-indigo-600 rounded-full" />
                  )}
                  <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${
                    n.type === 'ai' ? 'bg-purple-100 text-purple-600' :
                    n.type === 'success' ? 'bg-emerald-100 text-emerald-600' :
                    'bg-amber-100 text-amber-600'
                  }`}>
                    {n.type === 'ai' ? <Sparkles className="w-5 h-5" /> :
                     n.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> :
                     <AlertCircle className="w-5 h-5" />}
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-slate-800">{n.title}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">{n.desc}</p>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                      <Clock className="w-3 h-3" /> {n.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <button className="w-full py-4 text-xs font-bold text-indigo-600 hover:bg-indigo-50 transition-colors border-t border-slate-50">
              Показать все уведомления
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

