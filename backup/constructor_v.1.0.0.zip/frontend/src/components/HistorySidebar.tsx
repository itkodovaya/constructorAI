import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { History, RotateCcw, Clock, Check, ChevronRight } from 'lucide-react';

interface Version {
  id: string;
  label: string;
  createdAt: string;
  assets: any;
}

interface HistorySidebarProps {
  isOpen: boolean;
  onClose: () => void;
  versions: Version[];
  currentVersionId?: string;
  onRestore: (version: Version) => void;
}

export const HistorySidebar: React.FC<HistorySidebarProps> = ({ 
  isOpen, 
  onClose, 
  versions = [], 
  currentVersionId,
  onRestore 
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/20 backdrop-blur-[2px] z-[150]"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-80 bg-white shadow-2xl z-[160] border-l border-slate-200 flex flex-col"
          >
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-50 rounded-lg">
                  <History className="w-5 h-5 text-indigo-600" />
                </div>
                <h3 className="font-bold text-slate-900">История версий</h3>
              </div>
              <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {versions.length === 0 && (
                <div className="text-center py-12 space-y-2">
                  <Clock className="w-8 h-8 text-slate-200 mx-auto" />
                  <p className="text-xs text-slate-400 font-medium">История изменений пуста</p>
                </div>
              )}
              
              {versions.map((v, i) => (
                <button
                  key={v.id}
                  onClick={() => onRestore(v)}
                  className={`w-full text-left p-4 rounded-2xl border-2 transition-all group ${
                    i === 0 
                    ? 'border-indigo-600 bg-indigo-50/50' 
                    : 'border-slate-50 hover:border-slate-100 bg-slate-50/30'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      {new Date(v.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {i === 0 && (
                      <span className="bg-indigo-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-tighter">
                        Текущая
                      </span>
                    )}
                  </div>
                  <h4 className="text-sm font-bold text-slate-800 mb-1 group-hover:text-indigo-600 transition-colors">
                    {v.label}
                  </h4>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 font-medium">
                    <RotateCcw className="w-3 h-3" />
                    Нажмите, чтобы восстановить
                  </div>
                </button>
              ))}
            </div>

            <div className="p-6 bg-slate-50 border-t border-slate-100">
              <p className="text-[10px] text-slate-400 font-medium leading-relaxed text-center">
                Мы храним до 50 последних изменений вашего бренда. Версии старше 30 дней удаляются автоматически.
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

