import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Presentation, ChevronLeft, ChevronRight, 
  Download, FileText, Layout, Play, 
  Plus, Trash2, Wand2, Type, 
  Maximize2, Share2, X
} from 'lucide-react';

interface Slide {
  id: string;
  title: string;
  content: string;
  type: 'title' | 'content' | 'image' | 'closing';
  layout: 'centered' | 'split' | 'full';
}

interface PresentationBuilderProps {
  brandName: string;
  palette: string[];
  fonts: { primary: string; secondary: string };
  onClose: () => void;
  onConvertToSite: () => void;
}

export const PresentationBuilder: React.FC<PresentationBuilderProps> = ({ brandName, palette, fonts, onClose, onConvertToSite }) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [slides, setSlides] = useState<Slide[]>([
    {
      id: '1',
      type: 'title',
      layout: 'centered',
      title: brandName,
      content: 'Инновационная стратегия развития бренда на 2026 год'
    },
    {
      id: '2',
      type: 'content',
      layout: 'split',
      title: 'Наша Миссия',
      content: 'Мы стремимся переосмыслить подход к дизайну, используя возможности искусственного интеллекта для создания уникальных визуальных решений.'
    },
    {
      id: '3',
      type: 'content',
      layout: 'full',
      title: 'Ключевые Ценности',
      content: '• Технологичность\n• Эстетика\n• Эффективность\n• Доступность'
    },
    {
      id: '4',
      type: 'closing',
      layout: 'centered',
      title: 'Спасибо за внимание!',
      content: `Связаться с командой ${brandName}`
    }
  ]);

  const nextSlide = () => {
    if (currentSlideIndex < slides.length - 1) setCurrentSlideIndex(currentSlideIndex + 1);
  };

  const prevSlide = () => {
    if (currentSlideIndex > 0) setCurrentSlideIndex(currentSlideIndex - 1);
  };

  const currentSlide = slides[currentSlideIndex];

  return (
    <div className="fixed inset-0 bg-slate-900 z-[100] flex flex-col overflow-hidden">
      {/* Top Bar */}
      <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-6 z-20">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-slate-700 rounded-lg transition-colors text-slate-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
          <div className="h-6 w-px bg-slate-700" />
          <div className="flex flex-col">
            <h2 className="font-bold text-white text-sm">Презентация: {brandName}</h2>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Gamma-Style AI Engine</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-slate-300 hover:bg-slate-700 rounded-xl transition-all">
            <Play className="w-4 h-4" /> Презентовать
          </button>
          <button className="flex items-center gap-2 px-5 py-2 text-sm font-bold bg-indigo-600 text-white rounded-xl shadow-lg hover:bg-indigo-700 transition-all">
            <Download className="w-4 h-4" /> Экспорт PDF
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Thumbnails */}
        <aside className="w-64 bg-slate-800 border-r border-slate-700 flex flex-col p-4 gap-4 overflow-y-auto">
          <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-2 px-2">Слайды</h3>
          {slides.map((slide, index) => (
            <button
              key={slide.id}
              onClick={() => setCurrentSlideIndex(index)}
              className={`relative group w-full aspect-[16/9] rounded-xl border-2 transition-all overflow-hidden ${
                currentSlideIndex === index ? 'border-indigo-500 ring-4 ring-indigo-500/20' : 'border-slate-700 hover:border-slate-600'
              }`}
            >
              <div className="absolute inset-0 bg-white/5 flex flex-col p-3 text-left">
                <span className="text-[8px] font-bold text-slate-400 mb-1">0{index + 1}</span>
                <span className="text-[10px] font-bold text-slate-200 line-clamp-1">{slide.title}</span>
                <div className="mt-auto flex gap-1">
                  <div className="h-1 w-4 bg-slate-600 rounded-full" />
                  <div className="h-1 w-2 bg-slate-700 rounded-full" />
                </div>
              </div>
            </button>
          ))}
          <button className="w-full py-4 border-2 border-dashed border-slate-700 rounded-xl flex items-center justify-center text-slate-500 hover:text-slate-300 hover:border-slate-600 transition-all">
            <Plus className="w-5 h-5" />
          </button>
        </aside>

        {/* Main Preview */}
        <main className="flex-1 bg-slate-900 p-12 flex flex-col items-center justify-center relative">
          <div className="absolute top-8 left-1/2 -translate-x-1/2 flex items-center gap-4 px-6 py-2 bg-slate-800/50 backdrop-blur-md rounded-full border border-slate-700">
             <button className="p-1 text-slate-400 hover:text-white transition-colors" onClick={prevSlide} disabled={currentSlideIndex === 0}>
               <ChevronLeft className="w-5 h-5" />
             </button>
             <span className="text-xs font-bold text-slate-400 tabular-nums">
               {currentSlideIndex + 1} / {slides.length}
             </span>
             <button className="p-1 text-slate-400 hover:text-white transition-colors" onClick={nextSlide} disabled={currentSlideIndex === slides.length - 1}>
               <ChevronRight className="w-5 h-5" />
             </button>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 1.05, y: -20 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="w-full max-w-5xl aspect-[16/9] bg-white rounded-3xl shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col p-20 relative group"
            >
              {/* Slide Layouts */}
              <div className="flex-1 flex flex-col justify-center">
                {currentSlide.layout === 'centered' ? (
                  <div className="text-center space-y-8">
                    <h2 className="text-6xl font-black text-slate-900 leading-tight" style={{ fontFamily: fonts.primary }}>
                      {currentSlide.title}
                    </h2>
                    <p className="text-2xl text-slate-500 max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: fonts.secondary }}>
                      {currentSlide.content}
                    </p>
                  </div>
                ) : currentSlide.layout === 'split' ? (
                  <div className="grid grid-cols-2 gap-20 items-center">
                    <div className="space-y-6">
                      <h2 className="text-5xl font-black text-slate-900 leading-tight" style={{ fontFamily: fonts.primary }}>
                        {currentSlide.title}
                      </h2>
                      <p className="text-xl text-slate-500 leading-relaxed" style={{ fontFamily: fonts.secondary }}>
                        {currentSlide.content}
                      </p>
                    </div>
                    <div className="aspect-square bg-slate-50 rounded-[40px] border border-slate-100 flex items-center justify-center overflow-hidden relative">
                      <div className="absolute inset-0 bg-gradient-to-br opacity-20" style={{ backgroundImage: `linear-gradient(to bottom right, ${palette[0]}, ${palette[1]})` }} />
                      <Presentation className="w-20 h-20 text-indigo-600 opacity-20" />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-12">
                     <h2 className="text-4xl font-black text-slate-900 border-l-8 pl-8" style={{ fontFamily: fonts.primary, borderColor: palette[0] }}>
                        {currentSlide.title}
                      </h2>
                      <div className="grid grid-cols-2 gap-8">
                        <p className="text-xl text-slate-500 leading-relaxed whitespace-pre-line" style={{ fontFamily: fonts.secondary }}>
                          {currentSlide.content}
                        </p>
                        <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100">
                           <div className="text-xs font-bold text-slate-400 uppercase mb-4 tracking-widest">AI Insights</div>
                           <p className="text-sm text-slate-400 italic">"Этот слайд был структурирован на основе анализа стиля {brandName}. Мы рекомендуем использовать больше визуальных акцентов."</p>
                        </div>
                      </div>
                  </div>
                )}
              </div>

              {/* Brand Footer on Slide */}
              <div className="absolute bottom-10 left-20 right-20 flex justify-between items-center pt-10 border-t border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: palette[0] }}>
                    {brandName.charAt(0)}
                  </div>
                  <span className="text-sm font-bold text-slate-400 tracking-tight">{brandName}</span>
                </div>
                <span className="text-[10px] font-bold text-slate-300 uppercase tracking-[0.3em]">Confidential • 2026</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Right Toolbar */}
        <aside className="w-16 bg-slate-800 border-l border-slate-700 flex flex-col items-center py-6 gap-6 z-10">
           <div className="group relative">
             <ToolbarButton icon={<Globe className="w-5 h-5 text-emerald-400" />} onClick={onConvertToSite} />
             <div className="absolute right-full mr-4 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-slate-900 text-white text-[10px] font-bold rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-xl border border-slate-700">
               В веб-сайт
             </div>
           </div>
           <div className="h-px w-8 bg-slate-700" />
           <ToolbarButton icon={<Type className="w-5 h-5" />} onClick={() => {}} />
           <ToolbarButton icon={<Layout className="w-5 h-5" />} onClick={() => {}} />
           <ToolbarButton icon={<FileText className="w-5 h-5" />} onClick={() => {}} />
           <div className="h-px w-8 bg-slate-700" />
           <ToolbarButton icon={<Wand2 className="w-5 h-5 text-indigo-400" />} onClick={() => {}} />
           <ToolbarButton icon={<Maximize2 className="w-5 h-5" />} onClick={() => {}} />
           <ToolbarButton icon={<Share2 className="w-5 h-5" />} onClick={() => {}} />
        </aside>
      </div>
    </div>
  );
};

const ToolbarButton = ({ icon, onClick }: { icon: any, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className="p-3 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-all"
  >
    {icon}
  </button>
);

