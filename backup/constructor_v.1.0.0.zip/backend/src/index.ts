import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { AIService } from './services/ai.service';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const DATA_FILE = path.join(__dirname, '../data/projects.json');

app.use(cors());
app.use(helmet());
app.use(morgan('dev'));
app.use(express.json());

// Helper for file persistence
const readData = () => {
  try {
    const data = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
};

const writeData = (data: any) => {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
};

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Constructor API is running' });
});

// Get all projects
app.get('/api/projects', (req, res) => {
  const projects = readData();
  res.json(projects);
});

app.post('/api/onboarding', async (req, res) => {
  const { brandName, style, primaryGoal } = req.body;
  
  if (!brandName || !style || !primaryGoal) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const brandAssets = await AIService.generateLogo(brandName, style);
    const projects = readData();
    
    const newProject = {
      id: Date.now().toString(),
      brandName,
      style,
      primaryGoal,
      assets: brandAssets,
      history: [{
        id: Date.now().toString(),
        assets: brandAssets,
        createdAt: new Date(),
        label: 'Первая генерация'
      }],
      createdAt: new Date(),
    };

    projects.push(newProject);
    writeData(projects);

    res.status(201).json({ 
      message: 'Onboarding and generation successful', 
      profileId: newProject.id,
      profile: newProject 
    });
  } catch (error) {
    console.error('AI Generation error:', error);
    res.status(500).json({ error: 'Failed to generate brand assets' });
  }
});

app.get('/api/profile/:id', (req, res) => {
  const projects = readData();
  const project = projects.find((p: any) => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }
  res.json(project);
});

app.post('/api/projects/:id/version', (req, res) => {
  const { assets, label } = req.body;
  const projects = readData();
  const projectIndex = projects.findIndex((p: any) => p.id === req.params.id);
  
  if (projectIndex === -1) {
    return res.status(404).json({ error: 'Project not found' });
  }

  const newVersion = {
    id: Date.now().toString(),
    assets,
    createdAt: new Date(),
    label: label || `Версия от ${new Date().toLocaleTimeString()}`
  };

  projects[projectIndex].assets = assets;
  if (!projects[projectIndex].history) projects[projectIndex].history = [];
  projects[projectIndex].history.unshift(newVersion);
  
  writeData(projects);
  res.status(201).json(projects[projectIndex]);
});

app.delete('/api/projects/:id', (req, res) => {
  let projects = readData();
  projects = projects.filter((p: any) => p.id !== req.params.id);
  writeData(projects);
  res.json({ message: 'Project deleted' });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
